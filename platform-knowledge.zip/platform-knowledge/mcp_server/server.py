"""MCP server exposing the knowledge graph to Copilot agent mode.

This is tier 4. It exists so the deep context does not have to be crammed into
the context window: Copilot queries it on demand, and Confluence edits are
visible without regenerating any files.

Register in .vscode/mcp.json:

    {"servers": {"platform-knowledge": {
       "command": "python",
       "args": ["-m", "mcp_server.server"],
       "env": {"PK_ROOT": "${workspaceFolder}/platform-knowledge"}}}}

Read-only by design. It never writes, and it never calls Confluence with a
token, so it can be handed to any developer without granting wiki credentials.
"""

from __future__ import annotations

import json
import os
import re
import threading
from datetime import datetime
from pathlib import Path

try:  # mcp >= 2.0 renamed FastMCP to MCPServer
    from mcp.server.mcpserver import MCPServer as _Server
except ImportError:  # mcp 1.x
    from mcp.server.fastmcp import FastMCP as _Server

ROOT = Path(os.environ.get("PK_ROOT", ".")).resolve()
BASE_URL = os.environ.get("CONFLUENCE_BASE_URL", "")

mcp = _Server("platform-knowledge")

# Files that make up the graph. The weekly refresh rewrites these underneath a
# running server, so they are reloaded on mtime change rather than cached at
# import. Without this, every developer serves stale rules until they restart
# their editor, which is the failure mode most likely to go unnoticed: the
# answers stay plausible, they are just out of date.
_GRAPH_FILES = {
    "nodes": "graph/nodes.json",
    "edges": "graph/edges.json",
    "guardrails": "graph/guardrails.json",
    "ontology": "graph/ontology.json",
    "manifest": "analysis/manifest.json",
    "mapping": "graph/spring_quarkus_mapping.json",
    "scan": "analysis/spring_scan.json",
}

_cache: dict[str, object] = {}
_mtimes: dict[str, float] = {}
_lock = threading.Lock()


def _load(name: str, default):
    """Load a graph file, re-reading it if it changed on disk."""
    rel = _GRAPH_FILES.get(name, name)
    p = ROOT / rel
    with _lock:
        try:
            mtime = p.stat().st_mtime
        except OSError:
            return _cache.get(name, default)
        if _mtimes.get(name) != mtime or name not in _cache:
            try:
                _cache[name] = json.loads(p.read_text())
                _mtimes[name] = mtime
            except (OSError, json.JSONDecodeError):
                # A refresh may be mid-write. Serve the previous good copy.
                return _cache.get(name, default)
        return _cache[name]


def _nodes():
    return _load("nodes", [])


def _edges():
    return _load("edges", [])


def _by_id():
    return {n["id"]: n for n in _nodes()}


def _titles():
    return {m["page_id"]: m["title"] for m in _load("manifest", [])}


def _cite(page_ids) -> list[dict]:
    titles = _titles()
    return [{"title": titles.get(p, p),
             "url": f"{BASE_URL}/pages/viewpage.action?pageId={p}"}
            for p in list(dict.fromkeys(page_ids))[:6]]


def _match(node: dict, q: str) -> bool:
    ql = q.lower()
    return ql in node["label"].lower() or any(ql in a.lower() for a in node.get("aliases", []))


@mcp.tool()
def graph_status() -> str:
    """Report how fresh the knowledge graph is: ontology version, entity counts,
    and when the underlying files were last regenerated. Call this if an answer
    looks out of date, or before relying on the graph for a significant decision."""
    onto = _load("ontology", {})
    stamps = {}
    for name, rel in _GRAPH_FILES.items():
        p = ROOT / rel
        if p.exists():
            stamps[name] = datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds")
    return json.dumps({
        "ontology_version": onto.get("version"),
        "ontology_status": onto.get("status"),
        "nodes": len(_nodes()), "edges": len(_edges()),
        "guardrails": len(_load("guardrails", [])),
        "pages_indexed": len(_load("manifest", [])),
        "last_regenerated": stamps,
        "root": str(ROOT),
    }, indent=2)


@mcp.tool()
def list_types() -> str:
    """List the platform's own vocabulary: every node type in the ontology with
    its definition and aliases. Call this first when unsure what to ask for."""
    return json.dumps({
        "ontology_version": _load("ontology", {}).get("version"),
        "lifecycle_stages": _load("ontology", {}).get("lifecycle_stages", []),
        "node_types": [{"name": n["name"], "label": n["canonical_label"],
                        "definition": n.get("definition", ""),
                        "aliases": n.get("aliases", [])}
                       for n in _load("ontology", {}).get("node_types", [])],
        "edge_types": [{"name": e["name"], "domain": e["domain"], "range": e["range"]}
                       for e in _load("ontology", {}).get("edge_types", [])],
    }, indent=2)


@mcp.tool()
def find_entity(query: str, type_filter: str = "") -> str:
    """Find a platform entity by name or alias. Use this to resolve an informal
    name (an acronym, a repo name, an internal code name) to its canonical form
    before relying on it in generated code."""
    hits = [n for n in _nodes() if _match(n, query)
            and (not type_filter or type_filter.lower() in n["type"].lower())]
    hits.sort(key=lambda n: -n["mention_count"])
    return json.dumps([{
        "id": n["id"], "label": n["label"], "type": n["type"],
        "aliases": n["aliases"], "attributes": n.get("attributes", {}),
        "confidence": n["mean_confidence"], "sources": _cite(n["source_page_ids"]),
    } for n in hits[:10]], indent=2)


@mcp.tool()
def traverse(entity: str, predicate: str = "", depth: int = 1) -> str:
    """Follow relationships out from an entity. Use this to answer questions like
    which Process APIs a Plugin ultimately calls, or which Common Services an
    Experience API depends on."""
    start = next((n for n in _nodes() if _match(n, entity)), None)
    if not start:
        return json.dumps({"error": f"no entity matching {entity!r}. Try find_entity."})
    frontier, seen, paths = {start["id"]}, {start["id"]}, []
    for _ in range(max(1, min(depth, 4))):
        nxt = set()
        for e in _edges():
            if predicate and e["predicate"] != predicate.upper():
                continue
            if e["subject"] in frontier and e["object"] not in seen:
                paths.append({"from": e["subject_label"], "predicate": e["predicate"],
                              "to": e["object_label"],
                              "evidence": e["source_quote"],
                              "source": _cite([e["source_page_id"]])[0]})
                nxt.add(e["object"])
                seen.add(e["object"])
        frontier = nxt
        if not frontier:
            break
    return json.dumps({"start": start["label"], "paths": paths}, indent=2)


@mcp.tool()
def get_rules(subject: str = "", stage: str = "", severity: str = "") -> str:
    """Get the platform's normative rules, filtered by what they apply to, which
    lifecycle stage they belong to, or how binding they are. Call this before
    writing code for an unfamiliar area rather than guessing a convention."""
    out = []
    for g in _load("guardrails", []):
        if subject and subject.lower() not in str(g.get("subject_label", "")).lower():
            continue
        if stage and stage.lower() != str(g.get("stage", "")).lower():
            continue
        if severity and severity.upper() != str(g.get("severity", "")).upper():
            continue
        out.append({"severity": g.get("severity"), "rule": g.get("rule"),
                    "applies_to": g.get("subject_label"), "stage": g.get("stage"),
                    "scope": g.get("scope"), "evidence": g.get("source_quote"),
                    "source": _cite([g["page_id"]])[0]})
    order = {"MUST": 0, "MUST_NOT": 0, "SHOULD": 1, "SHOULD_NOT": 1, "MAY": 2}
    out.sort(key=lambda r: order.get(r["severity"], 3))
    return json.dumps(out[:40], indent=2)


@mcp.tool()
def search_docs(query: str, limit: int = 5) -> str:
    """Full-text search the normalised platform documentation. Returns matching
    excerpts with source links. Use when the graph has no answer and you need the
    original wording."""
    terms = [t for t in re.split(r"\W+", query.lower()) if len(t) > 2]
    if not terms:
        return json.dumps([])
    scored = []
    for m in _load("manifest", []):
        p = ROOT / "normalized" / f"{m['page_id']}.md"
        if not p.exists():
            continue
        text = p.read_text()
        low = text.lower()
        score = sum(low.count(t) for t in terms) + 3 * sum(t in m["title"].lower() for t in terms)
        if score:
            idx = min((low.find(t) for t in terms if low.find(t) != -1), default=0)
            scored.append((score, m, text[max(0, idx - 200): idx + 600]))
    scored.sort(key=lambda x: -x[0])
    return json.dumps([{
        "title": m["title"], "excerpt": excerpt, "last_updated": m["last_updated"],
        "flagged_dead": m.get("flagged_dead", False),
        "url": f"{BASE_URL}/pages/viewpage.action?pageId={m['page_id']}",
    } for _, m, excerpt in scored[:limit]], indent=2)


@mcp.tool()
def check_migration(spring_construct: str) -> str:
    """Look up the Quarkus target for a Spring Boot construct, plus the gotcha
    that breaks a mechanical port. Call this for every Spring annotation, starter
    or API encountered during migration."""
    rows = _load("mapping", [])
    q = spring_construct.lower().lstrip("@")
    hits = [r for r in rows if q in r["spring"].lower().lstrip("@")]
    scan = _load("scan", {})
    return json.dumps({
        "matches": hits,
        "general_gotchas": scan.get("gotchas", []),
        "note": ("If there is no match, do not invent one. The absence usually "
                 "means the construct was not found in your codebase scan, or "
                 "needs a human decision. Check unmapped_spring_annotations."),
        "unmapped": scan.get("unmapped_spring_annotations", []),
    }, indent=2)


if __name__ == "__main__":
    mcp.run()
