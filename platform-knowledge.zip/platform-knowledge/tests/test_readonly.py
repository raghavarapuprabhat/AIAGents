"""Proof that this pipeline cannot modify Confluence.

The point of these tests is that "we never wrote any POST calls" is not a
guarantee. It holds only until someone adds one, and this repository is
explicitly meant to be extended by an AI coding assistant. So the constraint is
enforced at the transport and asserted here, including for callers who reach
past the client's public surface.
"""
import pathlib
import sys

import pytest
import requests

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from pipeline.confluence import (  # noqa: E402
    ConfluenceClient, ReadOnlySession, ReadOnlyViolation,
)

BASE = "https://wiki.example.com/confluence"


def _client() -> ConfluenceClient:
    return ConfluenceClient(BASE, "fake-token")


@pytest.mark.parametrize("verb", ["post", "put", "delete", "patch"])
def test_mutating_verbs_are_blocked_on_the_client_session(verb):
    """Reaching past the client into _session must not create a write path."""
    c = _client()
    with pytest.raises(ReadOnlyViolation):
        getattr(c._session, verb)(f"{BASE}/rest/api/content/123")


@pytest.mark.parametrize("verb", ["POST", "PUT", "DELETE", "PATCH", "TRACE"])
def test_mutating_verbs_are_blocked_at_the_transport(verb):
    with pytest.raises(ReadOnlyViolation):
        ReadOnlySession().request(verb, f"{BASE}/rest/api/content")


def test_legacy_action_urls_that_mutate_on_get_are_blocked():
    """Confluence Server/DC still exposes actions that mutate via GET, so
    restricting the HTTP verb alone would not be enough."""
    s = ReadOnlySession()
    for path in ("/pages/removepage.action?pageId=1",
                 "/pages/doeditpage.action?pageId=1",
                 "/pages/removeattachment.action?pageId=1",
                 "/spaces/dodeletespace.action?key=PLATFORM"):
        with pytest.raises(ReadOnlyViolation):
            s.request("GET", BASE + path)


def test_client_rejects_a_plain_session_substitution():
    with pytest.raises(ReadOnlyViolation):
        ConfluenceClient(BASE, "t", _session=requests.Session())


def test_no_csrf_bypass_header_is_sent():
    """X-Atlassian-Token exists to satisfy Confluence's CSRF check on
    state-changing requests. A read-only client has no use for it, and sending
    it would only help an accidental write succeed."""
    assert "X-Atlassian-Token" not in _client()._session.headers


def test_client_surface_is_read_only_by_construction():
    """Allowlist rather than denylist.

    A denylist on substrings like "attach" produces false positives on read
    methods (`download_attachment`) and, worse, false negatives on anything the
    list did not anticipate. Requiring every public method to carry a read-verb
    prefix means a newly added `create_page` fails this test on its name alone,
    before anyone has to notice what it does.
    """
    read_prefixes = ("get", "search", "walk", "find", "download",
                     "paginate", "whoami", "permission")
    surface = {n for n in dir(ConfluenceClient)
               if not n.startswith("_") and callable(getattr(ConfluenceClient, n, None))}
    offenders = {n for n in surface if not n.startswith(read_prefixes)}
    assert not offenders, f"non-read method on the Confluence client: {offenders}"


def test_read_verbs_are_permitted():
    """The block must not be so broad that the crawler stops working."""
    s = ReadOnlySession()
    for verb in ("GET", "HEAD", "OPTIONS"):
        assert verb in s.ALLOWED_METHODS


def test_mcp_server_has_no_network_access_at_all():
    src = (pathlib.Path(__file__).resolve().parents[1]
           / "mcp_server" / "server.py").read_text()
    for banned in ("import requests", "from pipeline.confluence",
                   "CONFLUENCE_PAT", "urllib.request", "httpx"):
        assert banned not in src, f"MCP server must stay offline; found {banned!r}"
