"""Regression tests for the storage-format converter.

These exist because storage format is the part of this pipeline most likely to
break silently: a macro handler that stops firing produces plausible-looking
markdown with the guardrails quietly missing.
"""
import pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from pipeline.storage_format import convert

FIX = pathlib.Path(__file__).parent / "fixtures" / "develop_process_api.xml"


def test_code_macro_cdata_and_language():
    r = convert(FIX.read_text())
    assert len(r.code_blocks) == 1
    assert r.code_blocks[0]["language"] == "java"
    assert '@Path("/payments")' in r.code_blocks[0]["code"]
    assert "```java" in r.markdown


def test_warning_panel_becomes_a_marked_blockquote():
    r = convert(FIX.read_text())
    assert any(p["type"] == "WARNING" for p in r.panels)
    assert "> **WARNING**" in r.markdown
    assert "must not" in r.markdown


def test_page_and_attachment_links_become_edges():
    r = convert(FIX.read_text())
    assert "PLATFORM:Name My Plugin" in r.page_links
    assert "process-api-openapi.yaml" in r.attachment_links
    assert "call-flow.png" in r.attachment_links


def test_table_headers_are_captured_for_fingerprinting():
    r = convert(FIX.read_text())
    assert r.tables[0]["headers"] == ["Field", "Type", "Required", "Description"]
    assert r.tables[0]["row_count"] == 2


def test_pipe_in_cell_is_escaped():
    r = convert(FIX.read_text())
    assert "plugin \\| widget" in r.markdown


def test_status_lozenge_is_extracted():
    assert "APPROVED" in convert(FIX.read_text()).statuses


def test_noise_macro_is_dropped():
    assert "maxLevel" not in convert(FIX.read_text()).markdown


def test_nested_lists_keep_indentation():
    assert "  - Use the common auth service." in convert(FIX.read_text()).markdown


def test_tasks_are_captured():
    r = convert(FIX.read_text())
    assert {t["status"] for t in r.task_items} == {"complete", "incomplete"}


def test_empty_input_does_not_explode():
    assert convert("").markdown.strip() == ""
