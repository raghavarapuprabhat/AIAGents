"""Tests for running with no LLM API key.

Two supported paths: `handoff` (GitHub Copilot answers queued prompts in the
IDE) and `deterministic` (no model at all). Both must work with no key in the
environment, which is the whole point.
"""
import json
import os
import pathlib
import sys

import pytest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))

JSON = '{"node_types": [{"type_name": "Plugin", "confidence": 0.9}]}'


@pytest.fixture
def cfg(tmp_path, monkeypatch):
    for k, v in {
        "CONFLUENCE_BASE_URL": "https://wiki.example.com",
        "CONFLUENCE_PAT": "t", "CONFLUENCE_SPACE_KEY": "PLATFORM",
        "CONFLUENCE_ROOT_PAGE_ID": "1", "PK_ROOT": str(tmp_path),
        "PK_LLM_MODE": "handoff",
    }.items():
        monkeypatch.setenv(k, v)
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    from pipeline.config import Config
    return Config()


@pytest.mark.parametrize("wrapper", [
    "{j}",
    "```json\n{j}\n```",
    "```\n{j}\n```",
    "Here is the JSON:\n\n```json\n{j}\n```\n\nAnything else?",
    "  \n{j}\n  ",
])
def test_copilot_response_formats_are_all_parsed(wrapper):
    """Copilot adds fences and prose. Rejecting those would make the operator
    hand-clean every file, which defeats the point of the handoff."""
    from pipeline.handoff import _parse
    assert _parse(wrapper.format(j=JSON))["node_types"][0]["type_name"] == "Plugin"


def test_malformed_response_is_rejected_not_silently_cached(cfg):
    from pipeline import handoff
    handoff.queue_prompt(cfg, "abc123", "sys", "usr", "03-induce")
    resp = cfg.p("llm_queue", "responses")
    resp.mkdir(parents=True, exist_ok=True)
    (resp / "abc123.json").write_text("I could not complete this task, sorry.")
    result = handoff.import_responses(cfg)
    assert result["imported"] == 0 and result["rejected"] == 1
    assert not list(cfg.p(".state", "llm_cache").glob("*.json"))


def test_import_populates_the_cache_so_the_stage_runs_offline(cfg):
    """The handoff reuses the existing response cache, so stages need no
    special-casing: once imported, they run exactly as if a model had answered."""
    from pipeline import handoff
    from pipeline.config import content_hash
    from pipeline.llm import LLM
    handoff.queue_prompt(cfg, "k1", "SYSTEM", "USER", "03-induce")
    resp = cfg.p("llm_queue", "responses")
    resp.mkdir(parents=True, exist_ok=True)
    (resp / "k1.json").write_text(f"```json\n{JSON}\n```")
    assert handoff.import_responses(cfg)["imported"] == 1

    expected = content_hash(f"{cfg.llm_model}|SYSTEM|USER")
    assert (cfg.p(".state", "llm_cache") / f"{expected}.json").exists()
    # And the LLM layer now returns it without any network access.
    assert LLM(cfg).complete_json("SYSTEM", "USER")["node_types"][0]["type_name"] == "Plugin"


def test_handoff_queues_rather_than_calling_out(cfg):
    from pipeline.llm import LLM, PromptQueued
    llm = LLM(cfg).for_stage("03-induce")
    with pytest.raises(PromptQueued):
        llm.complete_json("s", "u")
    assert llm.queued == 1
    assert json.loads((cfg.p("llm_queue", "index.json")).read_text())


def test_export_creates_work_items_and_a_runner_prompt(cfg):
    from pipeline import handoff
    handoff.queue_prompt(cfg, "k1", "SYSTEM", "USER", "03-induce")
    out = handoff.export(cfg)
    assert out["pending"] == 1
    item = (cfg.p("llm_queue", "pending", "k1.md")).read_text()
    assert "answer_file: responses/k1.json" in item and "SYSTEM" in item
    runner = cfg.root / ".github" / "prompts" / "process-knowledge-queue.prompt.md"
    assert runner.exists()
    # The runner must warn Copilot that wiki content is untrusted.
    assert "untrusted" in runner.read_text().lower()


def test_already_answered_items_are_not_re_exported(cfg):
    from pipeline import handoff
    handoff.queue_prompt(cfg, "k1", "s", "u", "03-induce")
    handoff.queue_prompt(cfg, "k2", "s2", "u2", "03-induce")
    resp = cfg.p("llm_queue", "responses")
    resp.mkdir(parents=True, exist_ok=True)
    (resp / "k1.json").write_text(JSON)
    out = handoff.export(cfg)
    assert out["pending"] == 1 and out["already_answered"] == 1


def test_no_api_key_needed_in_either_offline_mode(monkeypatch, tmp_path):
    from pipeline.config import Config
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    for k, v in {"CONFLUENCE_BASE_URL": "https://x", "CONFLUENCE_PAT": "t",
                 "CONFLUENCE_SPACE_KEY": "S", "CONFLUENCE_ROOT_PAGE_ID": "1",
                 "PK_ROOT": str(tmp_path)}.items():
        monkeypatch.setenv(k, v)
    for mode in ("handoff", "deterministic"):
        monkeypatch.setenv("PK_LLM_MODE", mode)
        assert Config().llm_mode == mode


def test_invalid_mode_is_rejected_early(monkeypatch, tmp_path):
    from pipeline.config import Config
    for k, v in {"CONFLUENCE_BASE_URL": "https://x", "CONFLUENCE_PAT": "t",
                 "CONFLUENCE_SPACE_KEY": "S", "CONFLUENCE_ROOT_PAGE_ID": "1",
                 "PK_ROOT": str(tmp_path), "PK_LLM_MODE": "gpt-please"}.items():
        monkeypatch.setenv(k, v)
    with pytest.raises(SystemExit):
        Config()


def test_deterministic_severity_classification():
    from pipeline.deterministic import _severity
    assert _severity("The plugin must not be renamed.") == "MUST_NOT"
    assert _severity("The name must be registered.") == "MUST"
    assert _severity("You should avoid inline styles.") == "SHOULD_NOT"
    assert _severity("Teams should prefer the shared component.") == "SHOULD"
    assert _severity("This is a description of the flow.") is None


def test_deterministic_prefers_the_longest_matching_label():
    """'Process API' must win over 'API', or every rule attaches to the wrong
    subject and the tier-2 files become nonsense."""
    from pipeline.deterministic import _mentions
    idx = sorted([("process api", "platform.ProcessApi"), ("api", "platform.Api")],
                 key=lambda kv: -len(kv[0]))
    assert _mentions("The Process API must expose health probes.", idx) == \
        [("platform.ProcessApi", "process api")]


# ---------------------------------------------------------------- MCP extraction

@pytest.fixture
def mcp_env(tmp_path, monkeypatch):
    """The extraction server reads PK_ROOT at import, so set it before importing."""
    monkeypatch.setenv("PK_ROOT", str(tmp_path))
    monkeypatch.setenv("PK_LLM_MODEL", "test-model")
    for mod in [m for m in sys.modules if m.startswith("mcp_server")]:
        del sys.modules[mod]
    from mcp_server import extraction
    doc = ("The Process API must expose health probes on the platform standard "
           "paths. Teams must not change the plugin name after registration.")
    q = tmp_path / "llm_queue"
    q.mkdir(parents=True)
    (q / "index.json").write_text(json.dumps(
        {"t1": {"stage": "05-extract", "system": "Extract guardrails.", "user": doc}}))
    return extraction, tmp_path, doc


def _fn(tool):
    return getattr(tool, "fn", tool)


def test_mcp_rejects_a_paraphrased_quote_with_an_actionable_reason(mcp_env):
    """The whole point of the MCP path: a bad quote is caught while it can still
    be fixed, instead of being silently discarded during stage 05 validation."""
    ex, _, _ = mcp_env
    r = json.loads(_fn(ex.submit_answer)("t1", json.dumps(
        {"guardrails": [{"severity": "MUST", "rule": "x",
                         "source_quote": "the API needs health endpoints"}]})))
    assert r["accepted"] is False
    assert "verbatim" in r["problems"][0]
    assert "same task_id" in r["action"]


def test_mcp_rejects_an_invalid_severity(mcp_env):
    ex, _, doc = mcp_env
    r = json.loads(_fn(ex.submit_answer)("t1", json.dumps(
        {"guardrails": [{"severity": "REQUIRED", "rule": "x",
                         "source_quote": "must expose health probes"}]})))
    assert r["accepted"] is False and "severity" in r["problems"][0].lower()


def test_mcp_accepts_verbatim_answer_wrapped_in_prose_and_fences(mcp_env):
    ex, tmp, _ = mcp_env
    good = json.dumps({"guardrails": [
        {"severity": "MUST", "rule": "Expose health probes.",
         "source_quote": "must expose health probes on the platform standard paths"}]})
    r = json.loads(_fn(ex.submit_answer)("t1", f"Sure:\n\n```json\n{good}\n```\n\nDone!"))
    assert r["accepted"] is True and r["remaining"] == 0
    assert list((tmp / ".state" / "llm_cache").glob("*.json"))


def test_rejected_answer_is_not_cached_so_the_task_stays_outstanding(mcp_env):
    ex, tmp, _ = mcp_env
    _fn(ex.submit_answer)("t1", json.dumps(
        {"guardrails": [{"severity": "MUST", "rule": "x", "source_quote": "invented"}]}))
    assert not list((tmp / ".state" / "llm_cache").glob("*.json"))
    assert json.loads(_fn(ex.queue_status)())["remaining"] == 1


def test_next_task_carries_the_untrusted_content_warning(mcp_env):
    ex, _, _ = mcp_env
    payload = json.loads(_fn(ex.next_task)())
    assert "untrusted" in payload["important"].lower()
    assert payload["tasks"][0]["task_id"] == "t1"


def test_unknown_task_id_is_reported_clearly(mcp_env):
    ex, _, _ = mcp_env
    r = json.loads(_fn(ex.submit_answer)("nope", "{}"))
    assert r["accepted"] is False and "Unknown task_id" in r["problems"][0]


def test_extraction_server_writes_the_same_cache_key_the_pipeline_reads(mcp_env):
    """If these two disagree the loop looks like it works and silently does
    nothing, so pin the contract."""
    ex, tmp, doc = mcp_env
    from pipeline.config import content_hash
    good = json.dumps({"guardrails": [
        {"severity": "MUST", "rule": "x",
         "source_quote": "must expose health probes on the platform standard paths"}]})
    assert json.loads(_fn(ex.submit_answer)("t1", good))["accepted"]
    expected = content_hash(f"test-model|Extract guardrails.|{doc}")
    assert (tmp / ".state" / "llm_cache" / f"{expected}.json").exists()


def test_read_only_query_server_has_no_write_tools():
    """The two servers are separate on purpose: developers load the read-only
    one, and its guarantee stays trivially auditable."""
    src = (pathlib.Path(__file__).resolve().parents[1]
           / "mcp_server" / "server.py").read_text()
    for banned in ("write_text", "submit_answer", "mkdir"):
        assert banned not in src, f"query server must stay read-only; found {banned!r}"
