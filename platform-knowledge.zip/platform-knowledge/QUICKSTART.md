# Quickstart

Full detail is in README.md. This is the shortest path to a first run.

## Running this with a coding agent

`AGENTS.md` (mirrored to `.github/copilot-instructions.md`) tells Copilot or any
other agent how to operate this repo, and where it must stop and ask you. An
agent can do steps 1, 3, 4, 6 and 7 unattended. It cannot do the gates, the
common-service inventory, or the golden slice: those are judgement calls, and an
agent that proceeds through them produces output that looks complete and is
built on a schema nobody approved. Give it the credentials, not just the wiki
link; a page URL is not access.

## 0. Before you touch anything

Two things to settle first, because both are awkward to retrofit:

1. **Get a service account** with **View-only** permission on the space, and
   create the PAT under that account. A Data Center PAT has no independent
   scope; it inherits every permission of the account that made it. The pipeline
   blocks all writes at the transport layer, but the credential should be
   constrained too.
2. **Decide this repo's visibility.** The graph and the skills' `references/`
   folders will contain verbatim text from the space, so this repo inherits the
   space's classification.

## 1. Install

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## 2. Configure

```bash
cp .env.example .env
```

Fill in four values:

| Variable | Where to find it |
|---|---|
| `CONFLUENCE_BASE_URL` | Include the context path, e.g. `https://wiki.bank.com/confluence` |
| `CONFLUENCE_SPACE_KEY` | The `spaceKey` in any page URL in the space |
| `CONFLUENCE_ROOT_PAGE_ID` | Open the single page everything hangs under; take `pageId` from the URL |
| `CONFLUENCE_PAT` | Service account token. Never commit it (`.gitignore` covers `.env`) |

If your instance uses a corporate CA, set `PK_VERIFY_TLS` to the bundle path.
If direct LLM egress is blocked, point `PK_LLM_BASE_URL` at your internal gateway.

```bash
set -a && source .env && set +a
```

## 3. Prove the connection and the read-only posture

```bash
python -m pytest tests/ -q          # 25 tests, incl. the write-blocking proof
python -m pipeline stage 01         # crawl
```

Then read three files before spending anything on LLM stages:

- `analysis/access_report.json` — what the token's account can actually do
- `analysis/unhandled_macros.json` — macros the parser skipped. Anything frequent
  and content-bearing needs a handler, or that context is silently lost
- `analysis/pruned.json` — what was dropped and why

## 4. Analyse, then look before you leap

```bash
python -m pipeline stage 02         # no LLM, no network, no cost
```

`analysis/clusters.json` now tells you how many skills you will get. If the
cluster count looks implausible, adjust `cluster_threshold` in `config.py`
rather than pushing on. `analysis/lifecycle_gaps.json` lists the late lifecycle
stages with no pages; raise those at gate 1.

## 5. Ontology, with a human

**No LLM API key?** Set `PK_LLM_MODE=handoff` and use Copilot as the model:

```bash
python -m pipeline stage 03            # queues prompts, calls nothing
python -m pipeline handoff export      # writes llm_queue/pending/*.md
#   in VS Code:  /process-knowledge-queue
python -m pipeline handoff import      # loads answers into the cache
python -m pipeline stage 03            # completes offline from cache
python -m pipeline handoff status      # progress at any time
```

With `PK_LLM_MODE=api` it is just `python -m pipeline stage 03`.
With `PK_LLM_MODE=deterministic` there is no queue and no model at all.

```bash
python -m pipeline stage 04            # writes review/gate1.html
```

Open `review/gate1.html` with a platform SME. Ninety minutes, three questions:
right concepts, right *names*, what is missing because everyone knows it
verbally. Download the decisions, save as `gate1.decisions.json`, then:

```bash
python -m pipeline freeze-ontology
```

## 6. Extract and generate

```bash
python -m pipeline stage 05         # full corpus; in handoff mode, queue again
python -m pipeline stage 06         # writes review/gate2.html  (60 min)
python -m pipeline stage 07
python -m pipeline stage 08         # evals must pass
```

## 7. Your own codebase

```bash
python -m pipeline scan-spring --src ../payments-service \
                               --approved-bom approved-extensions.json
```

Check `analysis/spring_scan.json` → `unmapped_spring_annotations`. Each one
needs a human decision before migration starts.

## 8. Ship it

```bash
cp -r out/.github  ../payments-service/
cp    out/AGENTS.md ../payments-service/
```

Copilot picks these up with no further configuration. For the MCP server, point
`.vscode/mcp.json` at this repo rather than copying anything.

## 9. Keep it alive

```bash
python -m pipeline run --incremental && python -m pipeline stage 08
```

`.github/workflows/refresh.yml` does this weekly and opens a PR. Set the repo
variables `CONFLUENCE_BASE_URL`, `CONFLUENCE_SPACE_KEY`, `CONFLUENCE_ROOT_PAGE_ID`
and the secrets `CONFLUENCE_PAT`, `ANTHROPIC_API_KEY`.

## The step people skip

Before letting Copilot migrate anything, **hand-migrate one vertical slice**
(Widget → Experience API → Process API). Put the diff in
`out/.github/skills/springboot-to-quarkus-migration/references/golden-example-diff.md`.
Copilot pattern-matches against that far more strongly than against any prose,
and it is the difference between plausible output and correct output.
