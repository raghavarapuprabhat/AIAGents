"""Confluence Data Center / Server REST client.

Data Center specifics handled here:
  * Auth is a Personal Access Token sent as `Authorization: Bearer <PAT>`.
    (Cloud uses Basic email:token -- not this file.)
  * Pagination is `start`/`limit` with a `_links.next` hint; DC caps `limit`
    at 100 for most collection endpoints and silently truncates above that.
  * The REST root is `<base>/rest/api`. If your instance is deployed under a
    context path (e.g. https://wiki.bank.com/confluence) include it in BASE_URL.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Iterator
from urllib.parse import urljoin

import requests

log = logging.getLogger(__name__)

PAGE_EXPAND = ",".join([
    "body.storage",
    "version",
    "ancestors",
    "space",
    "metadata.labels",
    "history.lastUpdated",
    "history.createdBy",
])


class ConfluenceError(RuntimeError):
    pass


class ReadOnlyViolation(RuntimeError):
    """Raised when anything attempts a mutating request against Confluence."""


# Confluence Server/DC keeps legacy action URLs that mutate on a plain GET, so
# restricting the HTTP verb alone is not sufficient. These paths are refused
# outright regardless of method.
MUTATING_ACTIONS = re.compile(
    r"/(doeditpage|docreatepage|removepage|dopostcomment|removecomment|"
    r"doattachfile|removeattachment|movepage|dosetpagepermissions|"
    r"removepageversion|purgetrasheditem|copypage|renamepage|"
    r"doaddlabel|removelabel|dodeletespace|editattachment)\.action",
    re.I,
)


class ReadOnlySession(requests.Session):
    """A session that is physically incapable of writing to Confluence.

    Every requests helper (`post`, `put`, `delete`, `patch`) funnels through
    `request()`, so overriding it here blocks writes even if someone reaches
    past the client and calls `client._session.post(...)` directly.

    This exists because a read-only client that is merely *missing* write
    methods stays read-only only for as long as nobody adds one. That is a
    weak guarantee in a repository whose whole purpose is to be extended by an
    AI coding assistant, so the constraint is enforced at the transport rather
    than left to code review.
    """

    ALLOWED_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})

    def request(self, method, url, *args, **kwargs):  # type: ignore[override]
        verb = str(method).upper()
        if verb not in self.ALLOWED_METHODS:
            raise ReadOnlyViolation(
                f"Blocked a {verb} request to {url}. This pipeline is read-only "
                f"by design and must never modify Confluence. If you genuinely "
                f"need to write, that belongs in a separate tool with its own "
                f"credentials and its own change approval."
            )
        if MUTATING_ACTIONS.search(str(url)):
            raise ReadOnlyViolation(
                f"Blocked a request to a mutating Confluence action URL: {url}. "
                f"Some legacy Confluence actions mutate on a GET."
            )
        return super().request(method, url, *args, **kwargs)


@dataclass
class ConfluenceClient:
    base_url: str
    token: str
    timeout: int = 30
    max_retries: int = 4
    rate_limit_sleep: float = 0.15
    verify_tls: bool | str = True
    _session: requests.Session = field(default_factory=ReadOnlySession, repr=False)

    def __post_init__(self) -> None:
        self.base_url = self.base_url.rstrip("/")
        if not isinstance(self._session, ReadOnlySession):
            raise ReadOnlyViolation(
                "ConfluenceClient must use a ReadOnlySession. Substituting a "
                "plain requests.Session would remove the write protection."
            )
        # No X-Atlassian-Token header. That header exists to satisfy Confluence's
        # CSRF check on *state-changing* requests; a read-only client has no use
        # for it, and sending it would only help an accidental write succeed.
        self._session.headers.update({
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/json",
            "User-Agent": "platform-knowledge/1.0 (read-only documentation indexer)",
        })
        self._session.verify = self.verify_tls

    # ---------------------------------------------------------------- plumbing

    def _url(self, path: str) -> str:
        if path.startswith("http"):
            return path
        return f"{self.base_url}/rest/api/{path.lstrip('/')}"

    def get(self, path: str, **params: Any) -> dict:
        url = self._url(path)
        delay = 1.0
        for attempt in range(self.max_retries):
            resp = self._session.get(url, params=params or None, timeout=self.timeout)
            if resp.status_code == 200:
                time.sleep(self.rate_limit_sleep)
                return resp.json()
            if resp.status_code in (429, 502, 503, 504):
                retry_after = float(resp.headers.get("Retry-After", delay))
                log.warning("HTTP %s on %s, retrying in %.1fs", resp.status_code, url, retry_after)
                time.sleep(retry_after)
                delay *= 2
                continue
            if resp.status_code == 401:
                raise ConfluenceError(
                    "401 Unauthorized. On Data Center the PAT goes in an "
                    "Authorization: Bearer header; check the token has not expired "
                    "and that BASE_URL includes any context path."
                )
            if resp.status_code == 404:
                raise ConfluenceError(f"404 for {url} (params={params})")
            raise ConfluenceError(f"HTTP {resp.status_code} for {url}: {resp.text[:400]}")
        raise ConfluenceError(f"Exhausted retries for {url}")

    def paginate(self, path: str, limit: int = 100, **params: Any) -> Iterator[dict]:
        """Yield every result across pages.

        DC returns `_links.next` as a path relative to the *context root*, not to
        /rest/api, so it is joined against base_url rather than passed through
        _url(). Falls back to manual start stepping when the hint is absent.
        """
        start = 0
        page_params = dict(params)
        page_params["limit"] = min(limit, 100)
        while True:
            page_params["start"] = start
            payload = self.get(path, **page_params)
            results = payload.get("results", [])
            for item in results:
                yield item
            nxt = payload.get("_links", {}).get("next")
            if not results:
                return
            if nxt:
                # Trust the server's own cursor when it gives us one.
                start += len(results)
            else:
                if len(results) < page_params["limit"]:
                    return
                start += len(results)

    # ------------------------------------------------------------------- reads

    def get_page(self, page_id: str, expand: str = PAGE_EXPAND) -> dict:
        return self.get(f"content/{page_id}", expand=expand)

    def get_child_pages(self, page_id: str) -> Iterator[dict]:
        yield from self.paginate(
            f"content/{page_id}/child/page",
            expand="version,ancestors,metadata.labels",
        )

    def get_attachments(self, page_id: str) -> Iterator[dict]:
        yield from self.paginate(
            f"content/{page_id}/child/attachment",
            expand="version,metadata",
        )

    def search_cql(self, cql: str, expand: str = "version,ancestors,metadata.labels") -> Iterator[dict]:
        yield from self.paginate("content/search", cql=cql, expand=expand)

    def download_attachment(self, download_link: str) -> bytes:
        """`download_link` is the relative `_links.download` from an attachment."""
        url = urljoin(self.base_url + "/", download_link.lstrip("/"))
        resp = self._session.get(url, timeout=self.timeout * 2)
        resp.raise_for_status()
        return resp.content

    # -------------------------------------------------------------- tree walk

    def walk_tree(self, root_page_id: str, max_depth: int = 12) -> Iterator[tuple[dict, int]]:
        """Depth-first walk from a root page. Yields (page_stub, depth).

        Cycles are impossible in the Confluence page tree, but duplicate visits
        are still guarded against because a corrupted ancestors index can make
        the same child appear under two parents.
        """
        seen: set[str] = set()
        stack: list[tuple[str, int]] = [(str(root_page_id), 0)]
        while stack:
            pid, depth = stack.pop()
            if pid in seen or depth > max_depth:
                continue
            seen.add(pid)
            stub = self.get(f"content/{pid}", expand="version,ancestors,metadata.labels,space")
            yield stub, depth
            if depth < max_depth:
                children = list(self.get_child_pages(pid))
                # reversed so the tree comes out in reading order
                for child in reversed(children):
                    if str(child["id"]) not in seen:
                        stack.append((str(child["id"]), depth + 1))

    def find_orphans(self, space_key: str, known_ids: set[str]) -> Iterator[dict]:
        """Pages in the space that the tree walk never reached."""
        cql = f'space="{space_key}" AND type=page'
        for page in self.search_cql(cql):
            if str(page["id"]) not in known_ids:
                yield page

    def whoami(self) -> dict:
        return self.get("user/current")

    def permission_report(self, space_key: str) -> dict:
        """Report what this token's account can do in the space.

        A Data Center personal access token has **no independent scope**: it
        inherits every permission of the account that created it. A token made
        by someone with edit rights can edit, whatever the code intends. The
        transport-level block in ReadOnlySession is the technical control; this
        is the check that tells you whether the credential itself is also
        constrained, which is what an auditor will ask about.
        """
        report: dict = {"can_write": None, "checked": False}
        try:
            user = self.whoami()
            report["account"] = user.get("username") or user.get("displayName")
            report["account_type"] = user.get("type", "")
        except ConfluenceError as exc:
            report["error"] = str(exc)
            return report

        try:
            space = self.get(f"space/{space_key}", expand="permissions")
            perms = space.get("permissions", [])
            write_ops = {"create", "administer", "restrict", "export", "setpermissions"}
            granted = set()
            for p in perms:
                op = p.get("operation", {})
                name = str(op.get("operation", "")).lower()
                if name in write_ops or "create" in name or "update" in name:
                    granted.add(name)
            report.update({"checked": True, "write_operations_visible": sorted(granted),
                           "can_write": bool(granted)})
        except ConfluenceError as exc:
            # Space permission expansion is restricted on many DC instances.
            # Inability to check is not evidence of safety, so say so plainly.
            report["note"] = (
                f"Could not read space permissions ({exc}). This does not mean the "
                f"token is read-only. Confirm with your Confluence admin that the "
                f"account has View-only permission on {space_key}."
            )
        return report
