"""Stage 1 -- crawl the whole space and normalise every page.

Walks the tree from the configured root page, then sweeps the space with CQL to
catch orphans that are not reachable from the root (there are always some).
Pages are pruned automatically rather than curated by hand, and every exclusion
is logged with a reason so the decision is auditable later.
"""

from __future__ import annotations

import concurrent.futures as cf
import logging
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .config import Config, State, content_hash, read_json, write_json
from .confluence import ConfluenceClient, PAGE_EXPAND
from .storage_format import convert

log = logging.getLogger(__name__)

DEAD_MARKERS = re.compile(
    r"\b(deprecated|superseded|obsolete|archive[d]?|do not use|old|retired|draft|wip)\b",
    re.I,
)
BINARY_KEEP = {".graphql", ".gql", ".yaml", ".yml", ".json", ".xsd", ".wsdl",
               ".sql", ".proto", ".avsc", ".xml", ".md", ".txt", ".properties"}


def _slug(title: str) -> str:
    s = re.sub(r"[^a-zA-Z0-9]+", "-", title).strip("-").lower()
    return s[:80] or "untitled"


def _iso(dt: str | None) -> str:
    return dt or ""


def _is_stale(updated: str, days: int) -> bool:
    if not updated:
        return False
    try:
        ts = datetime.fromisoformat(updated.replace("Z", "+00:00"))
    except ValueError:
        return False
    return ts < datetime.now(timezone.utc) - timedelta(days=days)


def _prune_reason(page: dict, extracted, inbound: int, cfg: Config) -> str | None:
    title = page.get("title", "")
    words = len(extracted.markdown.split())
    updated = _iso(page.get("history", {}).get("lastUpdated", {}).get("when"))
    labels = [l["name"].lower() for l in
              page.get("metadata", {}).get("labels", {}).get("results", [])]

    if words < 25 and not extracted.tables and not extracted.code_blocks:
        return "empty: fewer than 25 words and no tables or code"
    if "archived" in labels or page.get("status") == "trashed":
        return "archived: label or status"
    if _is_stale(updated, cfg.stale_after_days) and inbound == 0:
        return f"stale: not updated since {updated[:10]} and no inbound links"
    return None


def run(cfg: Config) -> dict:
    client = ConfluenceClient(cfg.base_url, cfg.token, verify_tls=cfg.tls)
    perms = client.permission_report(cfg.space_key)
    log.info("Authenticated to %s as %s", cfg.base_url, perms.get("account"))
    if perms.get("can_write"):
        log.warning(
            "This token's account has write permission on space %s (%s). The "
            "pipeline cannot write - ReadOnlySession blocks every mutating "
            "request - but the CREDENTIAL is broader than the task needs. "
            "Prefer a service account with View-only permission.",
            cfg.space_key, ", ".join(perms.get("write_operations_visible", [])))
    elif perms.get("note"):
        log.info("Permission check inconclusive: %s", perms["note"])
    write_json(cfg.p("analysis", "access_report.json"), perms)

    state = State(cfg, "crawl")

    # ---- discover -----------------------------------------------------------
    log.info("Walking tree from root page %s", cfg.root_page_id)
    stubs: dict[str, dict] = {}
    depths: dict[str, int] = {}
    for stub, depth in client.walk_tree(cfg.root_page_id):
        stubs[str(stub["id"])] = stub
        depths[str(stub["id"])] = depth
    log.info("Tree walk found %d pages", len(stubs))

    orphans = list(client.find_orphans(cfg.space_key, set(stubs)))
    for o in orphans:
        stubs[str(o["id"])] = o
        depths[str(o["id"])] = -1  # -1 marks "not reachable from root"
    log.info("Orphan sweep added %d pages not reachable from the root", len(orphans))

    # ---- fetch --------------------------------------------------------------
    def fetch(pid: str) -> tuple[str, dict | None]:
        try:
            return pid, client.get_page(pid, expand=PAGE_EXPAND)
        except Exception as exc:  # noqa: BLE001
            log.error("Failed to fetch %s: %s", pid, exc)
            return pid, None

    pages: dict[str, dict] = {}
    to_fetch = []
    for pid, stub in stubs.items():
        version = str(stub.get("version", {}).get("number", ""))
        raw_path = cfg.p("raw", f"{pid}.json")
        if state.unchanged(pid, version) and raw_path.exists():
            pages[pid] = read_json(raw_path)
        else:
            to_fetch.append(pid)
    log.info("%d unchanged, %d to fetch", len(pages), len(to_fetch))

    with cf.ThreadPoolExecutor(max_workers=cfg.max_workers) as pool:
        for pid, payload in pool.map(fetch, to_fetch):
            if payload:
                pages[pid] = payload
                write_json(cfg.p("raw", f"{pid}.json"), payload)
                state.mark(pid, str(payload.get("version", {}).get("number", "")))
    state.save()

    # ---- inbound link counts (needed before pruning) ------------------------
    title_to_id = {p.get("title", ""): pid for pid, p in pages.items()}
    inbound: dict[str, int] = {pid: 0 for pid in pages}
    extracted_cache = {}
    for pid, page in pages.items():
        storage = page.get("body", {}).get("storage", {}).get("value", "")
        ex = convert(storage)
        extracted_cache[pid] = ex
        for ref in ex.page_links:
            title = ref.split(":", 1)[-1]
            target = title_to_id.get(title)
            if target and target != pid:
                inbound[target] = inbound.get(target, 0) + 1

    # ---- normalise + prune --------------------------------------------------
    manifest, pruned = [], []
    for pid, page in pages.items():
        ex = extracted_cache[pid]
        reason = _prune_reason(page, ex, inbound.get(pid, 0), cfg)
        title = page.get("title", "")
        ancestors = [a["title"] for a in page.get("ancestors", [])]
        labels = [l["name"] for l in
                  page.get("metadata", {}).get("labels", {}).get("results", [])]
        updated = _iso(page.get("history", {}).get("lastUpdated", {}).get("when"))
        flagged_dead = bool(DEAD_MARKERS.search(title)) or any(
            DEAD_MARKERS.search(l) for l in labels) or bool(
            {"DEPRECATED", "SUPERSEDED", "OBSOLETE"} & set(ex.statuses))

        record = {
            "page_id": pid,
            "title": title,
            "slug": _slug(title),
            "url": f"{cfg.base_url}/pages/viewpage.action?pageId={pid}",
            "space": page.get("space", {}).get("key", cfg.space_key),
            "version": page.get("version", {}).get("number"),
            "last_updated": updated,
            "last_updated_by": page.get("history", {}).get("lastUpdated", {})
                                    .get("by", {}).get("displayName", ""),
            "labels": labels,
            "ancestors": ancestors,
            "depth": depths.get(pid, -1),
            "reachable_from_root": depths.get(pid, -1) >= 0,
            "inbound_links": inbound.get(pid, 0),
            "word_count": len(ex.markdown.split()),
            "flagged_dead": flagged_dead,
            "content_hash": content_hash(ex.markdown),
        }

        if reason:
            record["pruned_reason"] = reason
            pruned.append(record)
            continue

        # Confluence content is untrusted input. Anyone with edit rights on a
        # page can write text that a downstream agent will read as instructions,
        # so imperative second-person phrasing aimed at an AI is defanged here,
        # before the text ever reaches an LLM prompt or a generated skill file.
        body = _defang(ex.markdown)

        front = "\n".join(
            [f"{k}: {v!r}" for k, v in record.items() if k != "content_hash"]
        )
        (cfg.p("normalized", f"{pid}.md")).write_text(
            f"---\n{front}\n---\n\n# {title}\n\n{body}"
        )
        write_json(cfg.p("normalized", f"{pid}.signals.json"),
                   {**record, **ex.as_signals(),
                    "code_blocks": ex.code_blocks,
                    "tables": ex.tables,
                    "panels": ex.panels,
                    "task_items": ex.task_items})
        manifest.append(record)

        _save_attachments(client, cfg, pid, ex)

    write_json(cfg.p("analysis", "manifest.json"), manifest)
    write_json(cfg.p("analysis", "pruned.json"), pruned)
    log.info("Kept %d pages, pruned %d", len(manifest), len(pruned))
    return {"kept": len(manifest), "pruned": len(pruned)}


INJECTION = re.compile(
    r"^(\s*[-*>#`\s]*)((?:ignore|disregard|forget)\s+(?:all\s+)?(?:previous|prior|above)|"
    r"you\s+are\s+(?:now\s+)?an?\s|system\s*:|assistant\s*:|"
    r"new\s+instructions?\s*:)",
    re.I | re.M,
)


def _defang(md: str) -> str:
    return INJECTION.sub(lambda m: f"{m.group(1)}[neutralised-directive] {m.group(2)}", md)


def _save_attachments(client: ConfluenceClient, cfg: Config, pid: str, ex) -> None:
    """Download contract-bearing attachments only; skip images and archives."""
    try:
        atts = list(client.get_attachments(pid))
    except Exception as exc:  # noqa: BLE001
        log.warning("Attachment listing failed for %s: %s", pid, exc)
        return
    for att in atts:
        name = att.get("title", "")
        ext = Path(name).suffix.lower()
        if ext not in BINARY_KEEP:
            continue
        dest = cfg.p("attachments", pid, name)
        if dest.exists():
            continue
        link = att.get("_links", {}).get("download")
        if not link:
            continue
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(client.download_attachment(link))
        except Exception as exc:  # noqa: BLE001
            log.warning("Attachment download failed %s/%s: %s", pid, name, exc)
