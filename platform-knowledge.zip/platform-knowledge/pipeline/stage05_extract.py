"""Stage 5 -- constrained extraction over 100% of pages, then entity resolution.

The frozen ontology goes into the prompt as a closed enum. Four validators run
before anything reaches the graph:

  1. type is in the enum
  2. edge respects declared domain/range
  3. sourceQuote appears verbatim in the source chunk  <- kills most hallucinations
  4. confidence >= threshold, else routed to review

Then entity resolution merges the four surface forms every real service has
(full name, acronym, repo name, internal code name). Skipping resolution is the
single most common reason these graphs end up unqueryable.
"""

from __future__ import annotations

import logging
import re
from collections import Counter, defaultdict
from difflib import SequenceMatcher

from .config import Config, read_json, write_json
from .llm import LLM, PromptQueued, wrap_untrusted

log = logging.getLogger(__name__)

EXTRACT_SYSTEM = """Extract entities and relationships from the document using ONLY the ontology below.

NODE TYPES (closed set -- never invent a type):
{node_types}

EDGE TYPES (closed set; each shows allowed subject -> object):
{edge_types}

Rules:
- If something does not fit a listed type, omit it. Do not force a bad fit.
- `source_quote` MUST be copied verbatim from the document, 5-25 words. It is
  machine-checked against the source; a paraphrase is rejected.
- `label` should be the canonical name of the thing, normalised (strip "the",
  trailing "service"/"API" only if the ontology type already implies it).
- Set confidence below 0.6 when you are inferring rather than reading.

Return ONLY JSON:
{{"nodes": [{{"type": "...", "label": "...", "attributes": {{}},
             "source_quote": "...", "confidence": 0.0-1.0}}],
  "edges": [{{"predicate": "...", "subject": "...", "object": "...",
             "source_quote": "...", "confidence": 0.0-1.0}}]}}"""

GUARDRAIL_SYSTEM = """Classify each normative statement below. Do not invent statements.

For each, return:
- `severity`: MUST | MUST_NOT | SHOULD | SHOULD_NOT | MAY
- `subject_type`: one of [{node_types}] or null
- `subject_label`: what the rule is about, or null
- `stage`: one of [{stages}] or null
- `scope`: "global" if it applies to every plugin/API, else "local"
- `rule`: the rule restated in one imperative sentence, under 25 words
- `source_quote`: verbatim, unmodified

Return ONLY JSON: {{"guardrails": [ ... ]}}"""

MODAL_LINE = re.compile(
    r"(?m)^.*?\b(must not|must never|shall not|is not permitted|must|shall|"
    r"should not|should|may not|required to|mandatory|never|always)\b.*$", re.I)


# --------------------------------------------------------------------- chunking

def _chunk(md: str, title: str, ancestors: list[str], max_chars: int) -> list[dict]:
    """Split on H2 boundaries, prepending title and ancestor path to every chunk
    so context survives chunking. A chunk that loses its page identity produces
    orphan nodes that entity resolution cannot rescue."""
    body = re.sub(r"^---\n.*?\n---\n", "", md, flags=re.S)
    parts = re.split(r"(?m)^(?=##\s)", body)
    header = f"PAGE: {title}\nPATH: {' > '.join(ancestors)}\n\n"
    chunks, buf = [], ""
    for part in parts:
        if len(buf) + len(part) > max_chars and buf:
            chunks.append(header + buf)
            buf = part
        else:
            buf += part
    if buf.strip():
        chunks.append(header + buf)
    return [{"index": i, "text": c} for i, c in enumerate(chunks)]


def _normalise_quote(s: str) -> str:
    return re.sub(r"\s+", " ", s or "").strip().lower().strip(".,;:\"'`*_")


def _quote_present(quote: str, haystack: str) -> bool:
    q, h = _normalise_quote(quote), _normalise_quote(haystack)
    if not q or len(q) < 8:
        return False
    if q in h:
        return True
    # Tolerate markdown emphasis characters the model may have dropped.
    return re.sub(r"[^a-z0-9 ]", "", q) in re.sub(r"[^a-z0-9 ]", "", h)


# ------------------------------------------------------------------------ run

def run(cfg: Config) -> dict:
    if cfg.llm_mode == "deterministic":
        from .deterministic import extract
        return extract(cfg)

    onto = read_json(cfg.p("graph", "ontology.json"))
    if not onto:
        raise SystemExit(
            "graph/ontology.json not found. Gate 1 must sign off the candidate "
            "ontology first: review review/gate1.html, then run "
            "`python -m pipeline freeze-ontology`.")
    if onto.get("status", "").startswith("candidate"):
        raise SystemExit("Ontology is still marked candidate. Freeze it at gate 1.")

    manifest = read_json(cfg.p("analysis", "manifest.json"), [])
    llm = LLM(cfg).for_stage("05-extract")

    node_types = {n["name"]: n for n in onto["node_types"]}
    label_to_type = {}
    for n in onto["node_types"]:
        label_to_type[n["canonical_label"].lower()] = n["name"]
        for a in n.get("aliases", []):
            label_to_type[a.lower()] = n["name"]
    edge_types = {e["name"]: e for e in onto["edge_types"]}
    stages = onto.get("lifecycle_stages", [])

    node_block = "\n".join(
        f"- {n['name']} ({n['canonical_label']}): {n.get('definition','')}"
        + (f" [aliases: {', '.join(n['aliases'])}]" if n.get("aliases") else "")
        for n in onto["node_types"])
    edge_block = "\n".join(
        f"- {e['name']}: {', '.join(e['domain'])} -> {', '.join(e['range'])}"
        for e in onto["edge_types"])

    raw_nodes: list[dict] = []
    raw_edges: list[dict] = []
    rejected: list[dict] = []
    guardrails: list[dict] = []

    for rec in manifest:
        pid, title = rec["page_id"], rec["title"]
        md_path = cfg.p("normalized", f"{pid}.md")
        if not md_path.exists():
            continue
        md = md_path.read_text()
        for chunk in _chunk(md, title, rec.get("ancestors", []), cfg.max_chunk_chars):
            cid = f"{pid}#{chunk['index']}"
            try:
                out = llm.complete_json(
                    EXTRACT_SYSTEM.format(node_types=node_block, edge_types=edge_block),
                    wrap_untrusted(chunk["text"]), max_tokens=3000)
            except PromptQueued:
                continue
            except Exception as exc:  # noqa: BLE001
                log.error("Extraction failed %s: %s", cid, exc)
                continue

            for n in out.get("nodes", []):
                ok, why = _validate_node(n, node_types, label_to_type, chunk["text"], cfg)
                target = raw_nodes if ok else rejected
                n.update({"page_id": pid, "chunk_id": cid, "page_title": title})
                if not ok:
                    n["rejected_because"] = why
                target.append(n)

            for e in out.get("edges", []):
                ok, why = _validate_edge(e, edge_types, chunk["text"], cfg)
                e.update({"page_id": pid, "chunk_id": cid})
                if ok:
                    raw_edges.append(e)
                else:
                    e["rejected_because"] = why
                    rejected.append(e)

        guardrails.extend(_extract_guardrails(cfg, llm, md, pid, title,
                                              list(node_types), stages))

    if llm.queued:
        from .stage03_induce import _await_handoff
        return _await_handoff(cfg, llm, "05")

    log.info("Extracted %d node mentions, %d edges, rejected %d, %d guardrails",
             len(raw_nodes), len(raw_edges), len(rejected), len(guardrails))

    nodes, alias_index, merge_log = _resolve_entities(raw_nodes)
    edges = _rewire_edges(raw_edges, alias_index, nodes)

    write_json(cfg.p("graph", "nodes.json"), nodes)
    write_json(cfg.p("graph", "edges.json"), edges)
    write_json(cfg.p("graph", "guardrails.json"), guardrails)
    write_json(cfg.p("graph", "rejected.json"), rejected)
    write_json(cfg.p("graph", "entity_merges.json"), merge_log)

    return {"nodes": len(nodes), "edges": len(edges), "guardrails": len(guardrails),
            "rejected": len(rejected), "merges": len(merge_log),
            "llm_calls": llm.calls, "cache_hits": llm.cache_hits}


# ------------------------------------------------------------------ validators

def _validate_node(n, node_types, label_to_type, chunk, cfg):
    t = str(n.get("type", "")).strip()
    if t not in node_types:
        resolved = label_to_type.get(t.lower())
        if not resolved:
            return False, f"type '{t}' not in ontology"
        n["type"] = resolved
    if not str(n.get("label", "")).strip():
        return False, "empty label"
    if float(n.get("confidence", 0)) < cfg.min_confidence:
        return False, f"confidence {n.get('confidence')} below {cfg.min_confidence}"
    if not _quote_present(n.get("source_quote", ""), chunk):
        return False, "source_quote not found verbatim in chunk"
    return True, ""


def _validate_edge(e, edge_types, chunk, cfg):
    p = str(e.get("predicate", "")).strip().upper()
    if p not in edge_types:
        return False, f"predicate '{p}' not in ontology"
    if not (e.get("subject") and e.get("object")):
        return False, "missing subject or object"
    if float(e.get("confidence", 0)) < cfg.min_confidence:
        return False, "below confidence threshold"
    if not _quote_present(e.get("source_quote", ""), chunk):
        return False, "source_quote not found verbatim in chunk"
    e["predicate"] = p
    return True, ""


# ------------------------------------------------------------------ guardrails

def _extract_guardrails(cfg, llm, md, pid, title, node_types, stages):
    """Deterministic mining first, LLM only classifies. Guardrails are the
    highest-value and lowest-error-tolerance content in the corpus, so the set of
    statements is fixed by regex and the model is never asked to produce them."""
    candidates = [m.group(0).strip() for m in MODAL_LINE.finditer(md)]
    candidates = [c for c in candidates if 20 < len(c) < 400][:40]
    if not candidates:
        return []
    numbered = "\n".join(f"{i+1}. {c}" for i, c in enumerate(candidates))
    try:
        out = llm.complete_json(
            GUARDRAIL_SYSTEM.format(node_types=", ".join(node_types), stages=", ".join(stages)),
            wrap_untrusted(f"PAGE: {title}\n\n{numbered}"), max_tokens=3000)
    except PromptQueued:
        return []
    except Exception as exc:  # noqa: BLE001
        log.error("Guardrail classification failed %s: %s", pid, exc)
        return []
    results = []
    for g in out.get("guardrails", []):
        if not _quote_present(g.get("source_quote", ""), md):
            continue
        g.update({"page_id": pid, "page_title": title,
                  "url_hint": f"pageId={pid}"})
        results.append(g)
    return results


# ----------------------------------------------------------- entity resolution

ACRONYM_STOP = {"api", "ui", "id"}


def _canon_label(s: str) -> str:
    s = re.sub(r"\(.*?\)", " ", s)
    s = re.sub(r"[^a-zA-Z0-9 ]+", " ", s).strip().lower()
    s = re.sub(r"\b(the|a|an|our|platform)\b", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _acronym(s: str) -> str:
    words = [w for w in _canon_label(s).split() if w not in ACRONYM_STOP]
    return "".join(w[0] for w in words) if len(words) > 1 else ""


def _resolve_entities(raw_nodes):
    """Block by type, then match on canonical form, acronym expansion, and
    sequence similarity. All surface forms are kept as aliases so a later query
    for any of them still resolves."""
    by_type: dict[str, list[dict]] = defaultdict(list)
    for n in raw_nodes:
        by_type[n["type"]].append(n)

    nodes, merge_log = [], []
    alias_index: dict[tuple[str, str], str] = {}

    for typ, mentions in by_type.items():
        clusters: list[dict] = []
        for m in sorted(mentions, key=lambda x: -len(x["label"])):
            label = m["label"].strip()
            canon = _canon_label(label)
            if not canon:
                continue
            hit = None
            for c in clusters:
                if canon == c["canon"]:
                    hit = c
                    break
                if canon and (canon == _acronym(c["canon"]) or _acronym(canon) == c["canon"]):
                    hit = c
                    merge_log.append({"type": typ, "merged": label, "into": c["label"],
                                      "rule": "acronym expansion"})
                    break
                if SequenceMatcher(None, canon, c["canon"]).ratio() >= 0.88:
                    hit = c
                    merge_log.append({"type": typ, "merged": label, "into": c["label"],
                                      "rule": "string similarity >= 0.88"})
                    break
            if hit is None:
                hit = {"canon": canon, "label": label, "surface": Counter(),
                       "mentions": [], "attributes": {}}
                clusters.append(hit)
            hit["surface"].update([label])
            hit["mentions"].append(m)
            hit["attributes"].update(m.get("attributes") or {})

        for c in clusters:
            canonical = c["surface"].most_common(1)[0][0]
            node_id = f"{typ}:{_canon_label(canonical).replace(' ', '-')}"
            pages = sorted({m["page_id"] for m in c["mentions"]})
            nodes.append({
                "id": node_id, "type": typ, "label": canonical,
                "aliases": sorted({s for s in c["surface"] if s != canonical}),
                "attributes": c["attributes"],
                "mention_count": len(c["mentions"]),
                "source_page_ids": pages,
                "source_quotes": [m["source_quote"] for m in c["mentions"]][:3],
                "mean_confidence": round(
                    sum(float(m.get("confidence", 0.5)) for m in c["mentions"]) / len(c["mentions"]), 2),
            })
            for s in c["surface"]:
                alias_index[(typ, _canon_label(s))] = node_id
            alias_index[("*", _canon_label(canonical))] = node_id
            for s in c["surface"]:
                alias_index.setdefault(("*", _canon_label(s)), node_id)
    return nodes, alias_index, merge_log


def _rewire_edges(raw_edges, alias_index, nodes):
    """Point edges at resolved node ids. Edges whose endpoints cannot be resolved
    are dropped rather than left dangling, and counted so the loss is visible."""
    by_id = {n["id"]: n for n in nodes}
    resolved, dangling = [], 0
    seen = set()
    for e in raw_edges:
        s = alias_index.get(("*", _canon_label(e["subject"])))
        o = alias_index.get(("*", _canon_label(e["object"])))
        if not s or not o or s == o:
            dangling += 1
            continue
        key = (s, e["predicate"], o)
        if key in seen:
            continue
        seen.add(key)
        resolved.append({
            "subject": s, "predicate": e["predicate"], "object": o,
            "subject_label": by_id[s]["label"], "object_label": by_id[o]["label"],
            "source_page_id": e["page_id"], "source_quote": e["source_quote"],
            "confidence": e.get("confidence"),
        })
    if dangling:
        log.info("Dropped %d edges with unresolvable endpoints", dangling)
    return resolved
