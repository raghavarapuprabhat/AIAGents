"""Deterministic mode: build the graph with no model at all.

This is the floor, not the ceiling. It exists because a pipeline that is useless
without an API key is useless in an environment that does not have one, and
because a large fraction of what stages 03 and 05 do is recoverable from
structure alone in a wiki organised the way platform documentation usually is.

What it recovers well:
  * node types, from repeated title nouns across the page tree
  * lifecycle stages, from title verbs (already done in stage 02)
  * guardrails and their severity, from modal phrasing
  * which guardrail is about what, by matching known entity labels
  * CALLS / CONTAINS style edges, from explicit subject-verb-object sentences

What it cannot do, and where handoff mode earns its keep:
  * paraphrased relationships ("orders flow through the gateway before reaching")
  * implied subjects ("this must be registered" -- registered by whom, for what)
  * disambiguating two services described in the same paragraph

Accuracy is materially lower than the model path. Everything it emits is marked
`extraction_method: deterministic` so a later handoff pass can supersede it, and
so gate 2 shows you what rests on pattern matching rather than comprehension.
"""

from __future__ import annotations

import logging
import re
from collections import Counter, defaultdict

from .config import Config, read_json, write_json

log = logging.getLogger(__name__)

SEVERITY = [
    ("MUST_NOT", re.compile(r"\b(must not|must never|shall not|may not|is not permitted|"
                            r"are not permitted|do not|don't|never)\b", re.I)),
    ("SHOULD_NOT", re.compile(r"\b(should not|shouldn't|avoid|discouraged|"
                              r"not recommended)\b", re.I)),
    ("MUST", re.compile(r"\b(must|shall|is required|are required|mandatory|"
                        r"required to|always|has to|have to)\b", re.I)),
    ("SHOULD", re.compile(r"\b(should|recommended|prefer|preferably|"
                          r"best practice)\b", re.I)),
    ("MAY", re.compile(r"\b(may|optional|optionally|can choose)\b", re.I)),
]

SENTENCE = re.compile(r"(?<=[.!?])\s+|\n")

# Subject-verb-object patterns that map onto the usual platform relationships.
REL_PATTERNS = [
    ("CALLS", re.compile(r"\b(calls?|invokes?|requests?|queries|consumes? the)\b", re.I)),
    ("CONTAINS", re.compile(r"\b(contains?|includes?|is made up of|consists? of|"
                            r"is composed of)\b", re.I)),
    ("DEPENDS_ON", re.compile(r"\b(depends? on|requires?|relies on)\b", re.I)),
    ("EXPOSES", re.compile(r"\b(exposes?|publishes?|provides?|offers?)\b", re.I)),
    ("OWNED_BY", re.compile(r"\b(is owned by|owned by|is maintained by)\b", re.I)),
]

NOISE = {"the", "a", "an", "my", "your", "our", "of", "for", "to", "and", "in",
         "how", "do", "i", "with", "on", "is", "are", "be", "this", "that",
         "guide", "page", "overview", "introduction", "using", "use"}

VERBS = {"name", "design", "develop", "build", "create", "deploy", "test",
         "configure", "register", "onboard", "publish", "release", "migrate",
         "monitor", "support", "secure", "review", "version", "retire",
         "integrate", "troubleshoot", "understand", "deprecate"}


def _pascal(s: str) -> str:
    return "".join(w.capitalize() for w in re.split(r"[^a-zA-Z0-9]+", s) if w)


def _title_nouns(title: str) -> list[str]:
    toks = [w for w in re.sub(r"[^a-zA-Z0-9 ]", " ", title.lower()).split()
            if w not in NOISE and w not in VERBS and len(w) > 2]
    return toks


def induce_ontology(cfg: Config) -> dict:
    """Derive candidate types from repeated nouns in page titles and labels.

    Platform wikis are overwhelmingly titled `<verb> <noun>`, so the noun
    distribution across the tree is a usable proxy for the type system. This is
    the same signal stage 02 uses for lifecycle, read along the other axis.
    """
    manifest = read_json(cfg.p("analysis", "manifest.json"), [])
    clusters = read_json(cfg.p("analysis", "clusters.json"), [])
    lifecycle = read_json(cfg.p("analysis", "lifecycle.json"), [])
    if not manifest:
        raise SystemExit("No manifest. Run stage 01 first.")

    # Count noun phrases: unigrams and bigrams, bigrams weighted higher because
    # "process api" is a type where "api" alone is not.
    grams: Counter = Counter()
    examples: dict[str, list[str]] = defaultdict(list)
    for rec in manifest:
        toks = _title_nouns(rec["title"])
        for i, t in enumerate(toks):
            grams[t] += 1
            examples[t].append(rec["page_id"])
            if i + 1 < len(toks):
                bg = f"{t} {toks[i+1]}"
                grams[bg] += 3
                examples[bg].append(rec["page_id"])
        for label in rec.get("labels", []):
            l = label.lower().replace("-", " ")
            if l not in NOISE:
                grams[l] += 2
                examples[l].append(rec["page_id"])

    # Drop a unigram that is nearly always part of a stronger bigram.
    bigrams = {g for g in grams if " " in g}
    for bg in bigrams:
        for part in bg.split():
            if grams.get(part, 0) <= grams[bg] + 2:
                grams.pop(part, None)

    floor = max(3, cfg.type_frequency_floor - 2)
    ranked = [(g, c) for g, c in grams.most_common() if c >= floor][:15]

    node_types = []
    for gram, count in ranked:
        node_types.append({
            "name": f"platform.{_pascal(gram)}",
            "canonical_label": gram.title(),
            "aliases": [],
            "definition": f"Derived from {count} occurrences in page titles and labels. "
                          f"Review and write a real definition at gate 1.",
            "evidence": {
                "instance_count": count,
                "clusters": sorted({c["cluster_id"] for c in clusters
                                    if set(c["member_page_ids"]) & set(examples[gram])}),
                "source_page_ids": sorted(set(examples[gram]))[:5],
                "example_instances": [],
                "example_quote": "",
                "method": "deterministic: title and label frequency",
            },
            "mean_confidence": 0.5,
        })

    labels = {n["canonical_label"].lower() for n in node_types}
    edge_types = [
        {"name": name, "domain": [n["name"] for n in node_types[:4]],
         "range": [n["name"] for n in node_types[:4]], "aliases": [],
         "evidence": {"method": "deterministic: fixed relational vocabulary"}}
        for name, _ in REL_PATTERNS
    ]

    from .stage03_induce import _migration_namespace, _migration_edges, _write_yaml
    onto = {
        "version": 0,
        "status": "candidate -- NOT frozen, requires gate 1 sign-off",
        "extraction_method": "deterministic",
        "namespaces": {
            "platform": "Concepts discovered in Confluence.",
            "migration": "Concepts from your codebase scan and the Quarkus catalogue.",
        },
        "lifecycle_stages": [s["stage"] for s in lifecycle],
        "node_types": node_types + _migration_namespace(),
        "edge_types": edge_types + _migration_edges(),
        "demoted": [{"name": g, "instance_count": c,
                     "reason": "below frequency floor"}
                    for g, c in grams.most_common()[len(ranked):len(ranked) + 20]
                    if c < floor],
        "page_archetypes": [],
        "stats": {"sampled_pages": len(manifest), "clusters": len(clusters),
                  "llm_calls": 0, "cache_hits": 0},
        "caveat": "Types were derived from title and label frequency, not from "
                  "reading the pages. Definitions are placeholders. Gate 1 review "
                  "is more important here than on the model path, not less.",
    }
    write_json(cfg.p("graph", "ontology.candidate.yaml.json"), onto)
    _write_yaml(cfg.p("graph", "ontology.candidate.yaml"), onto)
    write_json(cfg.p("analysis", "coverage.json"), {
        "coverage_pct": 0.0, "held_out": 0,
        "verdict": "Not measured: the coverage test requires a model. Judge the "
                   "schema at gate 1 on the examples instead.",
        "unmatched_examples": [], "type_usage": [], "unused_types": [],
    })
    log.info("Deterministic ontology: %d node types from title/label frequency",
             len(node_types))
    return {"node_types": len(node_types), "edge_types": len(edge_types),
            "method": "deterministic"}


def extract(cfg: Config) -> dict:
    """Mine guardrails and explicit relationships without a model."""
    onto = read_json(cfg.p("graph", "ontology.json"))
    if not onto:
        raise SystemExit("Freeze the ontology at gate 1 first.")
    manifest = read_json(cfg.p("analysis", "manifest.json"), [])

    # Build a label -> node-type index, longest first so "Process API" wins
    # over "API" when both would match.
    label_index: list[tuple[str, str]] = []
    for n in onto["node_types"]:
        for surface in [n["canonical_label"], *n.get("aliases", [])]:
            label_index.append((surface.lower(), n["name"]))
    label_index.sort(key=lambda kv: -len(kv[0]))

    stages = onto.get("lifecycle_stages", [])
    valid_edges = {e["name"] for e in onto["edge_types"]}

    nodes_seen: dict[str, dict] = {}
    edges: list[dict] = []
    guardrails: list[dict] = []

    for rec in manifest:
        pid, title = rec["page_id"], rec["title"]
        p = cfg.p("normalized", f"{pid}.md")
        if not p.exists():
            continue
        body = re.sub(r"^---\n.*?\n---\n", "", p.read_text(), flags=re.S)
        page_stage = _page_stage(title, stages)

        for raw in SENTENCE.split(body):
            s = re.sub(r"\s+", " ", raw).strip(" -*>#|")
            if not (20 < len(s) < 400):
                continue
            mentions = _mentions(s, label_index)

            for typ, label in mentions:
                key = f"{typ}:{label.lower().replace(' ', '-')}"
                node = nodes_seen.setdefault(key, {
                    "id": key, "type": typ, "label": label.title(), "aliases": [],
                    "attributes": {}, "mention_count": 0, "source_page_ids": [],
                    "source_quotes": [], "mean_confidence": 0.5,
                    "extraction_method": "deterministic",
                })
                node["mention_count"] += 1
                if pid not in node["source_page_ids"]:
                    node["source_page_ids"].append(pid)
                if len(node["source_quotes"]) < 3:
                    node["source_quotes"].append(s[:200])

            sev = _severity(s)
            if sev:
                subject = mentions[0] if mentions else (None, None)
                guardrails.append({
                    "severity": sev,
                    "subject_type": subject[0],
                    "subject_label": subject[1].title() if subject[1] else None,
                    "stage": page_stage,
                    "scope": "global" if _looks_global(s) else "local",
                    "rule": _imperative(s),
                    "source_quote": s[:200],
                    "page_id": pid, "page_title": title,
                    "extraction_method": "deterministic",
                })

            if len(mentions) >= 2:
                for pred, rx in REL_PATTERNS:
                    if pred not in valid_edges or not rx.search(s):
                        continue
                    (st, sl), (ot, ol) = mentions[0], mentions[1]
                    if sl == ol:
                        continue
                    edges.append({
                        "subject": f"{st}:{sl.lower().replace(' ', '-')}",
                        "predicate": pred,
                        "object": f"{ot}:{ol.lower().replace(' ', '-')}",
                        "subject_label": sl.title(), "object_label": ol.title(),
                        "source_page_id": pid, "source_quote": s[:200],
                        "confidence": 0.5, "extraction_method": "deterministic",
                    })
                    break

    # Deduplicate edges on (subject, predicate, object).
    seen = set()
    unique_edges = []
    for e in edges:
        k = (e["subject"], e["predicate"], e["object"])
        if k not in seen:
            seen.add(k)
            unique_edges.append(e)

    nodes = sorted(nodes_seen.values(), key=lambda n: -n["mention_count"])
    write_json(cfg.p("graph", "nodes.json"), nodes)
    write_json(cfg.p("graph", "edges.json"), unique_edges)
    write_json(cfg.p("graph", "guardrails.json"), guardrails)
    write_json(cfg.p("graph", "rejected.json"), [])
    write_json(cfg.p("graph", "entity_merges.json"), [])
    write_json(cfg.p("analysis", "extraction_method.json"), {
        "method": "deterministic",
        "caveat": "Relationships come from explicit subject-verb-object sentences "
                  "only. Paraphrased and implied relationships are missed, so this "
                  "graph is sparser than the model path would produce. Guardrail "
                  "recall is good; guardrail subject attribution is approximate.",
    })
    log.info("Deterministic extraction: %d nodes, %d edges, %d guardrails",
             len(nodes), len(unique_edges), len(guardrails))
    return {"nodes": len(nodes), "edges": len(unique_edges),
            "guardrails": len(guardrails), "method": "deterministic",
            "llm_calls": 0}


def _mentions(sentence: str, label_index) -> list[tuple[str, str]]:
    low = sentence.lower()
    found, claimed = [], []
    for surface, typ in label_index:
        for m in re.finditer(rf"\b{re.escape(surface)}\b", low):
            span = (m.start(), m.end())
            if any(span[0] < c[1] and c[0] < span[1] for c in claimed):
                continue
            claimed.append(span)
            found.append((span[0], typ, surface))
            break
    found.sort()
    return [(t, s) for _, t, s in found]


def _severity(sentence: str) -> str | None:
    for name, rx in SEVERITY:
        if rx.search(sentence):
            return name
    return None


def _looks_global(s: str) -> bool:
    return bool(re.search(r"\b(all|every|any|each|always|never)\b", s, re.I))


def _imperative(s: str) -> str:
    """Trim a sentence toward a rule. Crude, and gate 2 is where you see it."""
    s = re.sub(r"^(please|note that|remember that|be aware that)\s+", "", s, flags=re.I)
    return (s[:160] + "…") if len(s) > 160 else s


def _page_stage(title: str, stages: list[str]) -> str | None:
    first = re.sub(r"[^a-zA-Z ]", " ", title.lower()).split()
    if not first:
        return None
    lead = first[0]
    if lead in ("how",):
        return "how-do-i" if "how-do-i" in stages else None
    return lead if lead in stages else None
