"""Stage 2 -- structural fingerprinting and clustering. No LLM, no network.

The premise: pages written from the same Confluence template share a heading
skeleton and table header sets. Shared template means shared type, so clustering
on structure recovers the archetype list from the corpus instead of assuming it.

Clustering is a deliberately dependency-free greedy pass over a weighted
Jaccard similarity. scikit-learn/HDBSCAN would be marginally tighter but pulls a
heavy dependency into a bank build pipeline for very little gain at this corpus
size, and the greedy result is deterministic, which matters because the cluster
IDs end up cited as evidence in the frozen ontology.
"""

from __future__ import annotations

import logging
import re
from collections import Counter, defaultdict

from .config import Config, read_json, write_json

log = logging.getLogger(__name__)

LEAD_VERBS = re.compile(
    r"^(how\s+do\s+i|how\s+to|name|design|develop|build|create|test|deploy|"
    r"release|publish|configure|onboard|register|migrate|monitor|support|"
    r"troubleshoot|secure|review|version|retire|deprecate|integrate|"
    r"understand|overview|introduction|getting\s+started)\b",
    re.I,
)

MODALS = {
    "must not": re.compile(r"\b(must not|must never|shall not|is not permitted|do not|never)\b", re.I),
    "must": re.compile(r"\b(must|shall|is required to|mandatory|required)\b", re.I),
    "should not": re.compile(r"\b(should not|avoid|discouraged)\b", re.I),
    "should": re.compile(r"\b(should|recommended|prefer)\b", re.I),
    "may": re.compile(r"\b(may|optional|can choose)\b", re.I),
}

STOP = {"the", "a", "an", "of", "for", "to", "and", "in", "my", "your", "with", "on", "i", "do", "how"}

# Ordering prior only. Used to break ties when sibling pages sit at equal tree
# depth. Stages absent from the corpus are reported as gaps rather than invented.
STAGE_PRIOR = {
    "overview": 0, "introduction": 0, "understand": 1, "getting started": 1,
    "onboard": 2, "register": 3, "name": 4, "design": 5, "develop": 6,
    "build": 7, "integrate": 7, "configure": 8, "secure": 9, "test": 10,
    "review": 11, "deploy": 12, "release": 13, "publish": 13, "version": 14,
    "monitor": 15, "support": 16, "troubleshoot": 16, "migrate": 17,
    "deprecate": 18, "retire": 19, "how-do-i": 99,
}


def _norm_heading(h: str) -> str:
    h = re.sub(r"[^a-z0-9 ]+", " ", h.lower())
    toks = [t for t in h.split() if t not in STOP]
    return " ".join(toks[:4])


def _title_tokens(title: str) -> list[str]:
    t = re.sub(r"[^a-zA-Z0-9 ]+", " ", title.lower())
    return [w for w in t.split() if w not in STOP]


def _features(sig: dict) -> dict:
    headings = [_norm_heading(h) for h in sig.get("heading_sequence", []) if h]
    tables = {"|".join(sorted(h.lower() for h in hs)) for hs in sig.get("table_header_sets", []) if hs}
    labels = {l.lower() for l in sig.get("labels", [])}
    parent = (sig.get("ancestors") or ["<root>"])[-1].lower()
    langs = set(sig.get("code_languages", {}).keys()) - {"none"}
    verb_m = LEAD_VERBS.match(sig.get("title", ""))
    return {
        "headings": set(headings),
        "heading_seq": headings,
        "tables": tables,
        "labels": labels,
        "parent": parent,
        "langs": langs,
        "title_tokens": set(_title_tokens(sig.get("title", ""))),
        "lead_verb": (verb_m.group(1).lower().replace("  ", " ") if verb_m else ""),
        "has_panels": bool(sig.get("panel_types")),
    }


def _jaccard(a: set, b: set) -> float:
    if not a and not b:
        return 0.0
    return len(a & b) / len(a | b)


def _similarity(x: dict, y: dict) -> float:
    """Weighted blend. Heading skeleton dominates because it is the strongest
    template signal; identical table header sets are near-conclusive."""
    s = 0.0
    s += 0.40 * _jaccard(x["headings"], y["headings"])
    s += 0.20 * (1.0 if (x["tables"] & y["tables"]) else 0.0)
    s += 0.15 * _jaccard(x["labels"], y["labels"])
    s += 0.10 * (1.0 if x["parent"] == y["parent"] else 0.0)
    s += 0.10 * _jaccard(x["title_tokens"], y["title_tokens"])
    s += 0.05 * _jaccard(x["langs"], y["langs"])
    return s


def _cluster(items: list[tuple[str, dict]], threshold: float) -> list[list[str]]:
    """Greedy leader clustering, seeded by descending structural richness so the
    most template-like pages become cluster leaders."""
    order = sorted(items, key=lambda kv: -(len(kv[1]["headings"]) + len(kv[1]["tables"])))
    leaders: list[tuple[str, dict]] = []
    members: dict[str, list[str]] = defaultdict(list)
    for pid, feat in order:
        best, best_score = None, 0.0
        for lid, lfeat in leaders:
            score = _similarity(feat, lfeat)
            if score > best_score:
                best, best_score = lid, score
        if best is not None and best_score >= threshold:
            members[best].append(pid)
        else:
            leaders.append((pid, feat))
            members[pid].append(pid)
    return sorted(members.values(), key=len, reverse=True)


def run(cfg: Config) -> dict:
    manifest = read_json(cfg.p("analysis", "manifest.json"), [])
    if not manifest:
        raise SystemExit("No manifest. Run stage 01 first.")

    sigs: dict[str, dict] = {}
    for rec in manifest:
        pid = rec["page_id"]
        sig = read_json(cfg.p("normalized", f"{pid}.signals.json"))
        if sig:
            sigs[pid] = sig

    feats = {pid: _features(s) for pid, s in sigs.items()}
    clusters = _cluster(list(feats.items()), cfg.cluster_threshold)

    # ---- cluster report -----------------------------------------------------
    cluster_records = []
    for idx, member_ids in enumerate(clusters):
        heads = Counter()
        labels = Counter()
        parents = Counter()
        verbs = Counter()
        tbl = Counter()
        for pid in member_ids:
            f = feats[pid]
            heads.update(f["headings"])
            labels.update(f["labels"])
            parents.update([f["parent"]])
            if f["lead_verb"]:
                verbs.update([f["lead_verb"]])
            tbl.update(f["tables"])
        n = len(member_ids)
        skeleton = [h for h, c in heads.most_common() if c >= max(2, n * 0.5)]
        reps = sorted(member_ids, key=lambda p: -sigs[p].get("inbound_links", 0))[:5]
        cluster_records.append({
            "cluster_id": f"C{idx:02d}",
            "size": n,
            "shared_heading_skeleton": skeleton,
            "dominant_labels": [l for l, _ in labels.most_common(5)],
            "dominant_parent": parents.most_common(1)[0][0] if parents else "",
            "dominant_lead_verbs": [v for v, _ in verbs.most_common(3)],
            "shared_table_headers": [t for t, c in tbl.most_common(3) if c >= 2],
            "representative_page_ids": reps,
            "representative_titles": [sigs[p]["title"] for p in reps],
            "member_page_ids": member_ids,
        })
    write_json(cfg.p("analysis", "clusters.json"), cluster_records)

    # ---- lifecycle recovery -------------------------------------------------
    # Lead verbs ordered by mean tree position recovers the real stage sequence,
    # including the stages after "Develop" that may not be obvious from a sample.
    verb_pos: dict[str, list[float]] = defaultdict(list)
    verb_pages: dict[str, list[str]] = defaultdict(list)
    for pid, s in sigs.items():
        m = LEAD_VERBS.match(s.get("title", ""))
        if not m:
            continue
        v = re.sub(r"\s+", " ", m.group(1).lower())
        if v.startswith("how"):
            v = "how-do-i"
        verb_pos[v].append(float(s.get("depth", 0)) + _sibling_hint(s))
        verb_pages[v].append(pid)
    lifecycle = []
    for v, positions in verb_pos.items():
        lifecycle.append({
            "stage": v,
            "page_count": len(verb_pages[v]),
            "mean_tree_position": round(sum(positions) / len(positions), 2),
            "canonical_rank": STAGE_PRIOR.get(v, 50),
            "example_titles": [sigs[pid]["title"] for pid in verb_pages[v][:4]],
        })
    # Tree position is the primary evidence, but sibling pages usually sit at
    # identical depth, so a canonical delivery-lifecycle prior breaks the tie.
    # The prior only orders; it never invents a stage that is not in the corpus.
    lifecycle.sort(key=lambda d: (d["mean_tree_position"], d["canonical_rank"]))

    missing = [s for s, r in sorted(STAGE_PRIOR.items(), key=lambda kv: kv[1])
               if s not in verb_pos and r >= STAGE_PRIOR["develop"]]
    write_json(cfg.p("analysis", "lifecycle_gaps.json"), {
        "recovered": [s["stage"] for s in lifecycle],
        "absent_late_stages": missing,
        "note": "Late-lifecycle stages absent from the page tree are usually held "
                "verbally rather than documented, and they carry the constraints "
                "that fail the delivery pipeline. Raise these at gate 1.",
    })
    if missing:
        log.warning("No pages found for late lifecycle stages: %s", missing)
    write_json(cfg.p("analysis", "lifecycle.json"), lifecycle)

    # ---- hubs ---------------------------------------------------------------
    hubs = sorted(
        ({"page_id": pid, "title": s["title"], "inbound_links": s.get("inbound_links", 0),
          "depth": s.get("depth"), "labels": s.get("labels", [])} for pid, s in sigs.items()),
        key=lambda d: -d["inbound_links"],
    )[:30]
    write_json(cfg.p("analysis", "hubs.json"), hubs)

    # ---- guardrail density --------------------------------------------------
    density = []
    for pid, s in sigs.items():
        text = " ".join(p["text"] for p in s.get("panels", []))
        md = (cfg.p("normalized", f"{pid}.md")).read_text()
        counts = {k: len(rx.findall(md)) for k, rx in MODALS.items()}
        counts["must"] = max(0, counts["must"] - counts["must not"])
        counts["should"] = max(0, counts["should"] - counts["should not"])
        total = sum(counts.values())
        if total:
            density.append({"page_id": pid, "title": s["title"],
                            "modal_counts": counts, "total": total,
                            "panel_chars": len(text)})
    density.sort(key=lambda d: -d["total"])
    write_json(cfg.p("analysis", "guardrail_density.json"), density[:60])

    # ---- unhandled macro audit ---------------------------------------------
    unhandled = Counter()
    for s in sigs.values():
        unhandled.update(s.get("unhandled_macros", []))
    write_json(cfg.p("analysis", "unhandled_macros.json"), unhandled.most_common())
    if unhandled:
        log.warning("Unhandled macros seen (add handlers if any look content-bearing): %s",
                    dict(unhandled.most_common(10)))

    log.info("%d pages -> %d clusters; %d lifecycle stages recovered",
             len(sigs), len(clusters), len(lifecycle))
    return {"pages": len(sigs), "clusters": len(clusters), "lifecycle_stages": len(lifecycle)}


def _sibling_hint(sig: dict) -> float:
    """Small tiebreaker so stages under the same parent keep document order."""
    return min(0.9, len(sig.get("ancestors", [])) * 0.01)
