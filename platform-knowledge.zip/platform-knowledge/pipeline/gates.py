"""Gates 1 and 2 -- the only two places a human reads anything.

Both reports are deliberately fixed-size regardless of corpus size. Gate 1 asks
three questions about the ontology (right concepts, right names, what is missing
that nobody wrote down). Gate 2 shows only conflicts, orphans, the unclassified
bucket, and low-confidence triples ranked by node centrality.
"""

from __future__ import annotations

import html
import json
import logging
from collections import Counter, defaultdict

from .config import Config, read_json, write_json

log = logging.getLogger(__name__)

CSS = """
:root{--bg:#fff;--fg:#1a1a1a;--mut:#666;--line:#e2e2e2;--acc:#0b5fff;--warn:#b45309;--bad:#b91c1c}
@media(prefers-color-scheme:dark){:root{--bg:#111;--fg:#eee;--mut:#999;--line:#333}}
*{box-sizing:border-box}body{background:var(--bg);color:var(--fg);font:15px/1.5 -apple-system,Segoe UI,Roboto,sans-serif;max-width:1000px;margin:0 auto;padding:2rem 1.25rem}
h1{font-size:1.6rem;margin:0 0 .25rem}h2{font-size:1.1rem;margin:2rem 0 .5rem;border-bottom:1px solid var(--line);padding-bottom:.3rem}
.sub{color:var(--mut);margin-bottom:1.5rem}
.card{border:1px solid var(--line);border-radius:8px;padding:1rem;margin:.75rem 0}
.card h3{margin:0 0 .3rem;font-size:1rem}
.meta{color:var(--mut);font-size:.83rem;margin:.3rem 0}
blockquote{margin:.5rem 0;padding:.4rem .75rem;border-left:3px solid var(--acc);color:var(--mut);font-size:.88rem}
.controls{display:flex;gap:1rem;flex-wrap:wrap;margin-top:.6rem;font-size:.88rem}
label{cursor:pointer}input[type=text]{padding:.25rem .5rem;border:1px solid var(--line);border-radius:4px;background:transparent;color:var(--fg);width:220px}
table{border-collapse:collapse;width:100%;font-size:.87rem;overflow-x:auto;display:block}
th,td{border:1px solid var(--line);padding:.4rem .55rem;text-align:left;vertical-align:top}
th{background:rgba(128,128,128,.08)}
.pill{display:inline-block;padding:.1rem .5rem;border-radius:99px;font-size:.75rem;background:rgba(128,128,128,.15);margin-right:.3rem}
.bad{color:var(--bad);font-weight:600}.warn{color:var(--warn);font-weight:600}
.actions{position:sticky;bottom:0;background:var(--bg);border-top:1px solid var(--line);padding:.75rem 0;margin-top:2rem}
button{background:var(--acc);color:#fff;border:0;padding:.55rem 1.1rem;border-radius:6px;font-size:.92rem;cursor:pointer}
code{background:rgba(128,128,128,.12);padding:.1rem .3rem;border-radius:3px;font-size:.85em}
"""

SCRIPT = """
function collect(){
  const out={decisions:[],notes:document.getElementById('notes').value};
  document.querySelectorAll('[data-item]').forEach(el=>{
    const v=el.querySelector('input[type=radio]:checked');
    const rn=el.querySelector('input[type=text]');
    out.decisions.push({item:el.dataset.item,verdict:v?v.value:'unreviewed',rename:rn?rn.value:''});
  });
  const blob=new Blob([JSON.stringify(out,null,2)],{type:'application/json'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);
  a.download=DECISION_FILE;a.click();
}
"""


def _e(s) -> str:
    return html.escape(str(s or ""))


def _shell(title: str, subtitle: str, body: str, decision_file: str) -> str:
    return f"""<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>{_e(title)}</title><style>{CSS}</style></head><body>
<h1>{_e(title)}</h1><div class="sub">{subtitle}</div>
{body}
<div class="actions">
<h2 style="margin-top:0">Notes / what is missing that nobody wrote down</h2>
<textarea id="notes" rows="4" style="width:100%;background:transparent;color:inherit;border:1px solid var(--line);border-radius:6px;padding:.5rem"></textarea>
<p><button onclick="collect()">Download decisions</button>
<span class="meta">Save next to the pipeline, then run the freeze command.</span></p>
</div>
<script>const DECISION_FILE={json.dumps(decision_file)};{SCRIPT}</script>
</body></html>"""


# ------------------------------------------------------------------- gate one

def gate1(cfg: Config) -> dict:
    onto = read_json(cfg.p("graph", "ontology.candidate.yaml.json"))
    if not onto:
        raise SystemExit("No candidate ontology. Run stage 03 first.")
    coverage = read_json(cfg.p("analysis", "coverage.json"), {})
    manifest = read_json(cfg.p("analysis", "manifest.json"), [])
    titles = {r["page_id"]: r["title"] for r in manifest}

    cov_class = "bad" if coverage.get("coverage_pct", 0) < 80 else ""
    parts = [
        f"""<div class="card"><h3>Coverage test</h3>
        <p class="{cov_class}">{coverage.get('coverage_pct','?')}% of flagged spans in
        {coverage.get('held_out',0)} held-out pages fit this schema.</p>
        <div class="meta">{_e(coverage.get('verdict',''))}</div>
        <div class="meta">Below 80% means a type is missing. Above 95% with unused
        types means the schema is too large.</div></div>""",
        "<h2>Node types</h2>",
        "<p class='meta'>You are answering three questions: are these the right "
        "concepts, are these the right <em>names</em> for them, and what is missing "
        "because everybody knows it verbally. Do not read the source pages.</p>",
    ]

    for n in onto["node_types"]:
        if n["name"].startswith("migration."):
            continue
        ev = n.get("evidence", {})
        srcs = " ".join(
            f'<span class="pill">{_e(titles.get(p, p))}</span>'
            for p in ev.get("source_page_ids", [])[:3])
        insts = ", ".join(_e(i) for i in ev.get("example_instances", [])[:6]) or "—"
        aliases = ", ".join(_e(a) for a in n.get("aliases", [])) or "—"
        parts.append(f"""
<div class="card" data-item="node:{_e(n['name'])}">
  <h3>{_e(n['canonical_label'])} <span class="meta">({_e(n['name'])})</span></h3>
  <div>{_e(n.get('definition',''))}</div>
  <div class="meta">{ev.get('instance_count',0)} instances ·
     clusters {', '.join(ev.get('clusters',[]))} · confidence {n.get('mean_confidence','')}</div>
  <div class="meta">Examples: {insts}</div>
  <div class="meta">Other names seen: {aliases}</div>
  <blockquote>{_e(ev.get('example_quote',''))}</blockquote>
  <div class="meta">Seen on: {srcs}</div>
  <div class="controls">
    <label><input type="radio" name="{_e(n['name'])}" value="keep"> Keep</label>
    <label><input type="radio" name="{_e(n['name'])}" value="drop"> Drop</label>
    <label><input type="radio" name="{_e(n['name'])}" value="merge"> Merge into…</label>
    <input type="text" placeholder="rename / merge target">
  </div>
</div>""")

    parts.append("<h2>Edge types</h2>")
    for e in onto["edge_types"]:
        if e["name"] in ("MAPS_TO", "HAS_GOTCHA"):
            continue
        ev = e.get("evidence", {})
        parts.append(f"""
<div class="card" data-item="edge:{_e(e['name'])}">
  <h3><code>{_e(e['name'])}</code></h3>
  <div class="meta">{' , '.join(_e(d) for d in e['domain'])} →
     {' , '.join(_e(r) for r in e['range'])} · {ev.get('instance_count',0)} instances</div>
  <blockquote>{_e(ev.get('example_quote',''))}</blockquote>
  <div class="controls">
    <label><input type="radio" name="e_{_e(e['name'])}" value="keep"> Keep</label>
    <label><input type="radio" name="e_{_e(e['name'])}" value="drop"> Drop</label>
    <input type="text" placeholder="rename predicate">
  </div>
</div>""")

    life = onto.get("lifecycle_stages", [])
    parts.append(f"""<h2>Lifecycle stages recovered from the page tree</h2>
<div class="card"><p>{' → '.join(_e(s) for s in life) or '—'}</p>
<div class="meta">Stages are an attribute dimension on every node, not node types.
Check whether the late stages (test, build, deploy, version, support, retire) are
present. Their absence usually means those constraints are held verbally, and they
are the ones that fail your pipeline.</div></div>""")

    if onto.get("demoted"):
        rows = "".join(
            f"<tr><td>{_e(d['name'])}</td><td>{d['instance_count']}</td><td>{_e(d['reason'])}</td></tr>"
            for d in onto["demoted"][:25])
        parts.append(f"""<h2>Demoted below the frequency floor</h2>
<div class="card"><table><tr><th>Candidate</th><th>Instances</th><th>Reason</th></tr>
{rows}</table><div class="meta">Promote any of these only if you believe the corpus
under-represents them.</div></div>""")

    if coverage.get("unmatched_examples"):
        rows = "".join(
            f"<tr><td>{_e(u.get('label'))}</td><td>{_e(u.get('why'))}</td>"
            f"<td><blockquote>{_e(u.get('quote'))}</blockquote></td></tr>"
            for u in coverage["unmatched_examples"])
        parts.append(f"""<h2>Things the schema could not express</h2>
<div class="card"><table><tr><th>Label</th><th>Why</th><th>Quote</th></tr>{rows}</table></div>""")

    out = cfg.p("review", "gate1.html")
    out.write_text(_shell(
        "Gate 1 — Ontology review",
        f"{len(onto['node_types'])} node types · {len(onto['edge_types'])} edge types · "
        f"induced from {onto['stats']['sampled_pages']} sampled pages across "
        f"{onto['stats']['clusters']} clusters. Time-box: 90 minutes, one platform SME.",
        "\n".join(parts), "gate1.decisions.json"))
    log.info("Wrote %s", out)
    return {"report": str(out)}


def freeze_ontology(cfg: Config, decisions_path: str | None = None) -> dict:
    """Apply gate 1 decisions and freeze ontology.json at version 1."""
    onto = read_json(cfg.p("graph", "ontology.candidate.yaml.json"))
    decisions = read_json(cfg.root / (decisions_path or "gate1.decisions.json"), None)
    if decisions is None:
        log.warning("No decisions file found; freezing the candidate unchanged. "
                    "This is only sensible for a dry run.")
        decisions = {"decisions": [], "notes": ""}

    verdicts = {d["item"]: d for d in decisions.get("decisions", [])}
    nodes, edges = [], []
    for n in onto["node_types"]:
        d = verdicts.get(f"node:{n['name']}", {})
        if d.get("verdict") == "drop":
            continue
        if d.get("verdict") == "merge" and d.get("rename"):
            continue  # aliases folded into the target by hand before freezing
        if d.get("rename"):
            n["aliases"] = sorted(set(n.get("aliases", [])) | {n["canonical_label"]})
            n["canonical_label"] = d["rename"]
            n["name"] = "platform." + "".join(w.capitalize() for w in d["rename"].split())
        nodes.append(n)
    for e in onto["edge_types"]:
        d = verdicts.get(f"edge:{e['name']}", {})
        if d.get("verdict") == "drop":
            continue
        if d.get("rename"):
            e["aliases"] = sorted(set(e.get("aliases", [])) | {e["name"]})
            e["name"] = d["rename"].upper().replace(" ", "_")
        edges.append(e)

    frozen = {**onto, "version": 1, "status": "frozen",
              "node_types": nodes, "edge_types": edges,
              "gate1_notes": decisions.get("notes", "")}
    frozen.pop("demoted", None)
    write_json(cfg.p("graph", "ontology.json"), frozen)
    log.info("Froze ontology v1: %d node types, %d edge types", len(nodes), len(edges))
    return {"node_types": len(nodes), "edge_types": len(edges)}


# ------------------------------------------------------------------- gate two

def gate2(cfg: Config) -> dict:
    nodes = read_json(cfg.p("graph", "nodes.json"), [])
    edges = read_json(cfg.p("graph", "edges.json"), [])
    guardrails = read_json(cfg.p("graph", "guardrails.json"), [])
    merges = read_json(cfg.p("graph", "entity_merges.json"), [])

    degree = Counter()
    for e in edges:
        degree[e["subject"]] += 1
        degree[e["object"]] += 1
    by_id = {n["id"]: n for n in nodes}

    # 1. contradictions: same subject+predicate, incompatible objects
    grouped = defaultdict(list)
    for e in edges:
        grouped[(e["subject"], e["predicate"])].append(e)
    conflicts = [
        {"subject": by_id.get(k[0], {}).get("label", k[0]), "predicate": k[1],
         "objects": [{"label": v["object_label"], "page_id": v["source_page_id"],
                      "quote": v["source_quote"]} for v in vs]}
        for k, vs in grouped.items()
        if len({v["object"] for v in vs}) > 1 and k[1] in {"OWNED_BY", "IMPLEMENTS", "SUPERSEDES"}
    ][:20]

    # 2. guardrail contradictions: same subject, opposing severity
    gmap = defaultdict(list)
    for g in guardrails:
        if g.get("subject_label"):
            gmap[g["subject_label"].lower()].append(g)
    g_conflicts = []
    for subj, gs in gmap.items():
        sev = {x.get("severity") for x in gs}
        if {"MUST", "MUST_NOT"} <= sev or {"SHOULD", "SHOULD_NOT"} <= sev:
            g_conflicts.append({"subject": subj, "rules": gs[:4]})
    g_conflicts = g_conflicts[:15]

    orphans = [n for n in nodes if degree[n["id"]] == 0]
    orphans.sort(key=lambda n: -n["mention_count"])
    low_conf = sorted(
        [n for n in nodes if n["mean_confidence"] < 0.75],
        key=lambda n: -(degree[n["id"]] * n["mention_count"]))[:30]

    parts = [f"""<div class="card"><h3>Fixed-size review</h3>
    <div class="meta">{len(nodes)} nodes · {len(edges)} edges · {len(guardrails)} guardrails ·
    {len(merges)} entity merges. This report shows only what needs a decision,
    so it stays the same length whether the space has 80 pages or 3,000.</div></div>"""]

    parts.append("<h2>1. Contradictions</h2>")
    if not conflicts and not g_conflicts:
        parts.append("<div class='card'><div class='meta'>None found.</div></div>")
    for c in conflicts:
        objs = "".join(
            f"<tr><td>{_e(o['label'])}</td><td>pageId={_e(o['page_id'])}</td>"
            f"<td><blockquote>{_e(o['quote'])}</blockquote></td></tr>" for o in c["objects"])
        parts.append(f"""<div class="card" data-item="conflict:{_e(c['subject'])}:{_e(c['predicate'])}">
<h3 class="warn">{_e(c['subject'])} <code>{_e(c['predicate'])}</code> → several values</h3>
<table><tr><th>Object</th><th>Source</th><th>Quote</th></tr>{objs}</table>
<div class="controls">
<label><input type="radio" name="c_{_e(c['subject'])}" value="first"> First is correct</label>
<label><input type="radio" name="c_{_e(c['subject'])}" value="disputed"> Mark disputed</label>
<input type="text" placeholder="correct value"></div></div>""")
    for gc in g_conflicts:
        rules = "".join(
            f"<tr><td><span class='pill'>{_e(r.get('severity'))}</span></td>"
            f"<td>{_e(r.get('rule'))}</td><td>pageId={_e(r.get('page_id'))}</td></tr>"
            for r in gc["rules"])
        parts.append(f"""<div class="card" data-item="guardrail-conflict:{_e(gc['subject'])}">
<h3 class="bad">Opposing rules for {_e(gc['subject'])}</h3>
<table><tr><th>Severity</th><th>Rule</th><th>Source</th></tr>{rules}</table>
<div class="meta">Unresolved items are marked <code>disputed</code> in the graph and
excluded from generated instructions rather than silently picked.</div>
<div class="controls">
<label><input type="radio" name="gc_{_e(gc['subject'])}" value="disputed"> Mark disputed</label>
<label><input type="radio" name="gc_{_e(gc['subject'])}" value="resolved"> Resolved →</label>
<input type="text" placeholder="which rule wins"></div></div>""")

    parts.append(f"<h2>2. Orphans ({len(orphans)})</h2>")
    rows = "".join(
        f"<tr><td>{_e(n['label'])}</td><td>{_e(n['type'])}</td><td>{n['mention_count']}</td>"
        f"<td>{_e(', '.join(n['source_page_ids'][:2]))}</td></tr>" for n in orphans[:20])
    parts.append(f"""<div class="card"><table>
<tr><th>Label</th><th>Type</th><th>Mentions</th><th>Pages</th></tr>{rows}</table>
<div class="meta">A node with no edges is usually a missing relationship rather
than a bad node. High mention counts here suggest an edge type is missing.</div></div>""")

    parts.append(f"<h2>3. Low-confidence, ranked by centrality ({len(low_conf)})</h2>")
    for n in low_conf:
        q = "".join(f"<blockquote>{_e(x)}</blockquote>" for x in n["source_quotes"][:2])
        parts.append(f"""<div class="card" data-item="node:{_e(n['id'])}">
<h3>{_e(n['label'])} <span class="meta">{_e(n['type'])} · confidence
{n['mean_confidence']} · degree {degree[n['id']]}</span></h3>{q}
<div class="controls">
<label><input type="radio" name="n_{_e(n['id'])}" value="keep"> Keep</label>
<label><input type="radio" name="n_{_e(n['id'])}" value="drop"> Drop</label>
<label><input type="radio" name="n_{_e(n['id'])}" value="disputed"> Disputed</label>
<input type="text" placeholder="correct label"></div></div>""")

    parts.append("<h2>4. Entity merges to sanity-check</h2>")
    rows = "".join(
        f"<tr><td>{_e(m['merged'])}</td><td>→ {_e(m['into'])}</td><td>{_e(m['rule'])}</td></tr>"
        for m in merges[:25])
    parts.append(f"""<div class="card"><table>
<tr><th>Surface form</th><th>Merged into</th><th>Rule</th></tr>{rows}</table>
<div class="meta">Acronym expansion is the risky rule. Scan for false merges.</div></div>""")

    out = cfg.p("review", "gate2.html")
    out.write_text(_shell("Gate 2 — Conflicts and low confidence",
                          "Time-box: 60 minutes. Only decisions, no reading.",
                          "\n".join(parts), "gate2.decisions.json"))
    log.info("Wrote %s", out)
    return {"report": str(out), "conflicts": len(conflicts) + len(g_conflicts),
            "orphans": len(orphans), "low_confidence": len(low_conf)}
