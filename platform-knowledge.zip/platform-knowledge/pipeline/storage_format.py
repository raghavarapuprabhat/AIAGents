"""Confluence storage format (XHTML) -> Markdown, structure preserved.

Storage format is not HTML. It carries undeclared `ac:` and `ri:` namespaces and
puts the content that matters most inside macros. Parsing it with a generic HTML
-> Markdown library loses exactly the things this pipeline needs:

  * code blocks live in <ac:structured-macro ac:name="code"> / <ac:plain-text-body>
    with the language in an <ac:parameter ac:name="language">
  * guardrails live in info/note/warning panels, which a generic converter
    flattens into ordinary paragraphs
  * page and attachment links are <ac:link><ri:page ri:content-title="..."/>,
    which is the raw material for graph edges
  * status lozenges (<ac:structured-macro ac:name="status">) carry DEPRECATED /
    APPROVED markers that decide whether a page is still true

BeautifulSoup's html.parser is used deliberately: it treats `ac:structured-macro`
as a literal tag name, which sidesteps the undeclared-namespace problem that
makes lxml's XML parser reject these documents outright.
"""

from __future__ import annotations

import html
import re
from dataclasses import dataclass, field
from typing import Any

from bs4 import BeautifulSoup, NavigableString, Tag

PANEL_MACROS = {
    "info": "INFO",
    "note": "NOTE",
    "warning": "WARNING",
    "tip": "TIP",
    "panel": "PANEL",
    "important": "IMPORTANT",
}

# Macros that add no extractable meaning and should be dropped silently.
NOISE_MACROS = {
    "toc", "children", "pagetree", "recently-updated", "contributors",
    "livesearch", "gallery", "anchor", "spaces-list", "content-report-table",
    "detailsummary", "create-from-template-button",
}


@dataclass
class ExtractedPage:
    """Normalised page content plus the structural signals stage 2 needs."""
    markdown: str = ""
    code_blocks: list[dict] = field(default_factory=list)
    tables: list[dict] = field(default_factory=list)
    panels: list[dict] = field(default_factory=list)
    page_links: list[str] = field(default_factory=list)
    attachment_links: list[str] = field(default_factory=list)
    external_links: list[str] = field(default_factory=list)
    headings: list[dict] = field(default_factory=list)
    statuses: list[str] = field(default_factory=list)
    task_items: list[dict] = field(default_factory=list)
    unhandled_macros: list[str] = field(default_factory=list)

    def as_signals(self) -> dict[str, Any]:
        return {
            "heading_sequence": [h["text"] for h in self.headings],
            "heading_levels": [h["level"] for h in self.headings],
            "table_header_sets": [tuple(t["headers"]) for t in self.tables if t["headers"]],
            "code_languages": _counter([c["language"] or "none" for c in self.code_blocks]),
            "panel_types": _counter([p["type"] for p in self.panels]),
            "link_out_pages": self.page_links,
            "attachment_refs": self.attachment_links,
            "statuses": self.statuses,
            "unhandled_macros": sorted(set(self.unhandled_macros)),
        }


def _counter(items: list[str]) -> dict[str, int]:
    out: dict[str, int] = {}
    for i in items:
        out[i] = out.get(i, 0) + 1
    return out


def _macro_params(macro: Tag) -> dict[str, str]:
    params = {}
    for p in macro.find_all("ac:parameter", recursive=False):
        name = p.get("ac:name", "")
        params[name] = p.get_text().strip()
    return params


def _clean(text: str) -> str:
    text = html.unescape(text)
    text = text.replace("\u00a0", " ")
    return re.sub(r"[ \t]+", " ", text).strip()


class StorageConverter:
    def __init__(self) -> None:
        self.out = ExtractedPage()
        self._lines: list[str] = []

    # ------------------------------------------------------------------ public

    def convert(self, storage_xhtml: str) -> ExtractedPage:
        soup = BeautifulSoup(storage_xhtml or "", "html.parser")
        self._strip_inline_comment_markers(soup)
        self._render_children(soup)
        md = "\n".join(self._lines)
        md = re.sub(r"\n{3,}", "\n\n", md).strip() + "\n"
        self.out.markdown = md
        return self.out

    # ----------------------------------------------------------------- helpers

    def _strip_inline_comment_markers(self, soup: BeautifulSoup) -> None:
        for marker in soup.find_all("ac:inline-comment-marker"):
            marker.unwrap()

    def _emit(self, line: str = "") -> None:
        self._lines.append(line)

    def _render_children(self, node: Tag) -> None:
        for child in list(node.children):
            self._render(child)

    def _render(self, node: Any) -> None:
        if isinstance(node, NavigableString):
            text = _clean(str(node))
            if text:
                self._emit(text)
            return
        if not isinstance(node, Tag):
            return

        name = node.name.lower()
        handler = getattr(self, f"_h_{name.replace('-', '_').replace(':', '_')}", None)
        if handler:
            handler(node)
        elif name in ("p", "div", "span", "section", "article"):
            self._block_text(node)
        elif name in ("ac:layout", "ac:layout-section", "ac:layout-cell", "ac:rich-text-body", "body"):
            self._render_children(node)
        else:
            self._block_text(node)

    def _inline(self, node: Tag) -> str:
        """Flatten a node to inline markdown, recording links as it goes."""
        parts: list[str] = []
        for child in node.children:
            if isinstance(child, NavigableString):
                parts.append(html.unescape(str(child)))
                continue
            if not isinstance(child, Tag):
                continue
            n = child.name.lower()
            if n in ("strong", "b"):
                parts.append(f"**{self._inline(child)}**")
            elif n in ("em", "i"):
                parts.append(f"*{self._inline(child)}*")
            elif n == "code":
                parts.append(f"`{child.get_text()}`")
            elif n == "br":
                parts.append("\n")
            elif n == "a":
                href = child.get("href", "")
                label = self._inline(child) or href
                if href:
                    self.out.external_links.append(href)
                    parts.append(f"[{label}]({href})")
                else:
                    parts.append(label)
            elif n == "ac:link":
                parts.append(self._render_ac_link(child))
            elif n == "ac:image":
                parts.append(self._render_ac_image(child))
            elif n == "ac:structured-macro":
                parts.append(self._render_inline_macro(child))
            elif n == "ac:emoticon":
                parts.append("")
            elif n in ("time",):
                parts.append(child.get("datetime", ""))
            else:
                parts.append(self._inline(child))
        return _clean("".join(parts))

    def _block_text(self, node: Tag) -> None:
        # Block-level macros nested inside a <p> must not be inlined away.
        block_macros = [
            m for m in node.find_all("ac:structured-macro", recursive=True)
            if m.get("ac:name", "") in PANEL_MACROS or m.get("ac:name", "") == "code"
        ]
        if block_macros:
            self._render_children(node)
            return
        text = self._inline(node)
        if text:
            self._emit(text)
            self._emit()

    # ---------------------------------------------------------------- handlers

    def _h_h1(self, n): self._heading(n, 1)
    def _h_h2(self, n): self._heading(n, 2)
    def _h_h3(self, n): self._heading(n, 3)
    def _h_h4(self, n): self._heading(n, 4)
    def _h_h5(self, n): self._heading(n, 5)
    def _h_h6(self, n): self._heading(n, 6)

    def _heading(self, node: Tag, level: int) -> None:
        text = self._inline(node)
        if not text:
            return
        self.out.headings.append({"level": level, "text": text})
        self._emit()
        self._emit(f"{'#' * level} {text}")
        self._emit()

    def _h_ul(self, node: Tag) -> None:
        self._list(node, ordered=False)

    def _h_ol(self, node: Tag) -> None:
        self._list(node, ordered=True)

    def _list(self, node: Tag, ordered: bool, depth: int = 0) -> None:
        idx = 1
        for li in node.find_all("li", recursive=False):
            bullet = f"{idx}." if ordered else "-"
            nested = [c for c in li.find_all(["ul", "ol"], recursive=False)]
            for nst in nested:
                nst.extract()
            text = self._inline(li)
            if text:
                self._emit(f"{'  ' * depth}{bullet} {text}")
            for nst in nested:
                self._list(nst, nst.name.lower() == "ol", depth + 1)
            idx += 1
        if depth == 0:
            self._emit()

    def _h_table(self, node: Tag) -> None:
        rows: list[list[str]] = []
        for tr in node.find_all("tr"):
            cells = tr.find_all(["th", "td"], recursive=False)
            rows.append([self._inline(c).replace("\n", " ").replace("|", "\\|") for c in cells])
        if not rows:
            return
        first_tr = node.find("tr")
        has_header = bool(first_tr and first_tr.find("th"))
        headers = rows[0] if has_header else []
        body = rows[1:] if has_header else rows
        self.out.tables.append({"headers": headers, "rows": body, "row_count": len(body)})

        width = max(len(r) for r in rows)
        self._emit()
        if has_header:
            padded = headers + [""] * (width - len(headers))
            self._emit("| " + " | ".join(padded) + " |")
            self._emit("|" + "---|" * width)
        for r in body:
            padded = r + [""] * (width - len(r))
            self._emit("| " + " | ".join(padded) + " |")
        self._emit()

    def _h_ac_structured_macro(self, node: Tag) -> None:
        name = (node.get("ac:name") or "").lower()
        params = _macro_params(node)

        if name == "code":
            language = params.get("language", "") or ""
            body_el = node.find("ac:plain-text-body")
            code = body_el.get_text() if body_el else ""
            code = html.unescape(code).strip("\n")
            title = params.get("title", "")
            self.out.code_blocks.append({
                "language": language.lower(), "code": code, "title": title,
                "lines": code.count("\n") + 1 if code else 0,
            })
            self._emit()
            if title:
                self._emit(f"*{title}*")
            self._emit(f"```{language}")
            self._lines.append(code)
            self._emit("```")
            self._emit()
            return

        if name in PANEL_MACROS:
            label = PANEL_MACROS[name]
            body_el = node.find("ac:rich-text-body")
            sub = StorageConverter()
            inner = sub.convert(str(body_el) if body_el else "")
            self._merge(sub.out, skip_markdown=True)
            text = inner.markdown.strip()
            title = params.get("title", "")
            self.out.panels.append({"type": label, "title": title, "text": text})
            self._emit()
            header = f"> **{label}**" + (f" — {title}" if title else "")
            self._emit(header)
            for line in text.splitlines():
                self._emit(f"> {line}" if line else ">")
            self._emit()
            return

        if name == "status":
            title = params.get("title", "").strip()
            colour = params.get("colour", params.get("color", "")).strip()
            if title:
                self.out.statuses.append(title.upper())
                self._emit(f"`[{title.upper()}]`" + (f" ({colour})" if colour else ""))
            return

        if name in ("expand", "excerpt", "section", "column", "deck", "card"):
            body_el = node.find("ac:rich-text-body")
            if body_el:
                title = params.get("title", "")
                if title:
                    self._emit()
                    self._emit(f"**{title}**")
                self._render_children(body_el)
            return

        if name == "jira":
            key = params.get("key", "")
            if key:
                self._emit(f"[JIRA:{key}]")
            return

        if name in NOISE_MACROS:
            return

        self.out.unhandled_macros.append(name)
        body_el = node.find("ac:rich-text-body")
        if body_el:
            self._render_children(body_el)
        else:
            plain = node.find("ac:plain-text-body")
            if plain:
                self._emit(html.unescape(plain.get_text()).strip())

    def _render_inline_macro(self, node: Tag) -> str:
        name = (node.get("ac:name") or "").lower()
        params = _macro_params(node)
        if name == "status":
            title = params.get("title", "").strip()
            if title:
                self.out.statuses.append(title.upper())
                return f"`[{title.upper()}]`"
            return ""
        if name == "jira":
            return f"[JIRA:{params.get('key', '')}]"
        if name in NOISE_MACROS:
            return ""
        self.out.unhandled_macros.append(name)
        body_el = node.find("ac:rich-text-body") or node.find("ac:plain-text-body")
        return _clean(body_el.get_text()) if body_el else ""

    def _h_ac_link(self, node: Tag) -> None:
        text = self._render_ac_link(node)
        if text:
            self._emit(text)

    def _render_ac_link(self, node: Tag) -> str:
        body = node.find("ac:plain-text-link-body") or node.find("ac:link-body")
        label = _clean(body.get_text()) if body else ""

        page = node.find("ri:page")
        if page:
            title = page.get("ri:content-title", "")
            space = page.get("ri:space-key", "")
            ref = f"{space}:{title}" if space else title
            if ref:
                self.out.page_links.append(ref)
            return f"[[{label or title}]](confluence-page:{ref})"

        att = node.find("ri:attachment")
        if att:
            fn = att.get("ri:filename", "")
            if fn:
                self.out.attachment_links.append(fn)
            return f"[{label or fn}](attachment:{fn})"

        user = node.find("ri:user")
        if user:
            return f"@{user.get('ri:username', user.get('ri:userkey', 'user'))}"

        anchor = node.get("ac:anchor", "")
        return label or (f"#{anchor}" if anchor else "")

    def _h_ac_image(self, node: Tag) -> None:
        self._emit(self._render_ac_image(node))
        self._emit()

    def _render_ac_image(self, node: Tag) -> str:
        alt = node.get("ac:alt", "") or node.get("ac:title", "")
        att = node.find("ri:attachment")
        if att:
            fn = att.get("ri:filename", "")
            self.out.attachment_links.append(fn)
            return f"![{alt or fn}](attachment:{fn})"
        url = node.find("ri:url")
        if url:
            return f"![{alt}]({url.get('ri:value', '')})"
        return f"![{alt}]()" if alt else ""

    def _h_ac_task_list(self, node: Tag) -> None:
        for task in node.find_all("ac:task"):
            status = (task.find("ac:task-status").get_text().strip()
                      if task.find("ac:task-status") else "incomplete")
            body = task.find("ac:task-body")
            text = self._inline(body) if body else ""
            self.out.task_items.append({"status": status, "text": text})
            box = "x" if status == "complete" else " "
            self._emit(f"- [{box}] {text}")
        self._emit()

    def _h_ac_placeholder(self, node: Tag) -> None:
        return  # template placeholder text, not real content

    def _h_hr(self, node: Tag) -> None:
        self._emit()
        self._emit("---")
        self._emit()

    def _h_blockquote(self, node: Tag) -> None:
        sub = StorageConverter()
        inner = sub.convert(node.decode_contents())
        self._merge(sub.out, skip_markdown=True)
        self._emit()
        for line in inner.markdown.strip().splitlines():
            self._emit(f"> {line}")
        self._emit()

    def _h_pre(self, node: Tag) -> None:
        code = node.get_text()
        self.out.code_blocks.append({"language": "", "code": code, "title": "", "lines": code.count("\n") + 1})
        self._emit("```")
        self._lines.append(code.strip("\n"))
        self._emit("```")
        self._emit()

    def _merge(self, other: ExtractedPage, skip_markdown: bool = False) -> None:
        self.out.code_blocks.extend(other.code_blocks)
        self.out.tables.extend(other.tables)
        self.out.panels.extend(other.panels)
        self.out.page_links.extend(other.page_links)
        self.out.attachment_links.extend(other.attachment_links)
        self.out.external_links.extend(other.external_links)
        self.out.headings.extend(other.headings)
        self.out.statuses.extend(other.statuses)
        self.out.task_items.extend(other.task_items)
        self.out.unhandled_macros.extend(other.unhandled_macros)


def convert(storage_xhtml: str) -> ExtractedPage:
    return StorageConverter().convert(storage_xhtml)
