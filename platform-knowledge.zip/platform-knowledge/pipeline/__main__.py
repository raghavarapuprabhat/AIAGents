"""platform-knowledge pipeline.

  python -m pipeline run --from 01 --to 08     full pipeline (stops at gates)
  python -m pipeline run --incremental         weekly refresh
  python -m pipeline stage 02                  one stage
  python -m pipeline freeze-ontology           apply gate 1 decisions
  python -m pipeline scan-spring --src ../svc  build the migration namespace
  python -m pipeline eval

Stages 04 and 06 are human gates. `run` writes the report and stops there; pass
--yes to continue past a gate using whatever decisions file is on disk.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys

from .config import Config

STAGES = {
    "01": ("crawl", "Crawl the space and normalise every page"),
    "02": ("fingerprint", "Structural fingerprinting and clustering (no LLM)"),
    "03": ("induce", "Induce candidate ontology from cluster representatives"),
    "04": ("gate1", "GATE: ontology review (90 min, one SME)"),
    "05": ("extract", "Constrained extraction over 100% of pages + entity resolution"),
    "06": ("gate2", "GATE: conflicts and low confidence (60 min)"),
    "07": ("generate", "Generate the Copilot layer"),
    "08": ("eval", "Run the eval set"),
}
GATES = {"04", "06"}


def _dispatch(key: str, cfg: Config):
    if key == "01":
        from .stage01_crawl import run
        return run(cfg)
    if key == "02":
        from .stage02_fingerprint import run
        return run(cfg)
    if key == "03":
        from .stage03_induce import run
        return run(cfg)
    if key == "04":
        from .gates import gate1
        return gate1(cfg)
    if key == "05":
        from .stage05_extract import run
        return run(cfg)
    if key == "06":
        from .gates import gate2
        return gate2(cfg)
    if key == "07":
        from .stage07_generate import run
        return run(cfg)
    if key == "08":
        from .stage08_eval import run
        return run(cfg)
    raise SystemExit(f"Unknown stage {key}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="pipeline")
    ap.add_argument("-v", "--verbose", action="store_true")
    ap.add_argument("--mode", choices=["api", "handoff", "deterministic"],
                    help="override PK_LLM_MODE for this run")
    sub = ap.add_subparsers(dest="cmd", required=True)

    r = sub.add_parser("run", help="run a range of stages")
    r.add_argument("--from", dest="start", default="01", choices=sorted(STAGES))
    r.add_argument("--to", dest="end", default="08", choices=sorted(STAGES))
    r.add_argument("--incremental", action="store_true",
                   help="refresh: crawl, then re-run extraction only for changed pages")
    r.add_argument("--yes", action="store_true", help="do not stop at human gates")

    s = sub.add_parser("stage", help="run one stage")
    s.add_argument("key", choices=sorted(STAGES))

    f = sub.add_parser("freeze-ontology")
    f.add_argument("--decisions", default=None)

    sc = sub.add_parser("scan-spring", help="build the migration.* namespace from your code")
    sc.add_argument("--src", required=True)
    sc.add_argument("--approved-bom", default=None,
                    help="optional JSON list of platform-approved Quarkus extensions")

    h = sub.add_parser("handoff", help="use GitHub Copilot as the model, no API key")
    h.add_argument("action", choices=["export", "import", "status"])

    sub.add_parser("eval")
    sub.add_parser("stats")

    args = ap.parse_args(argv)
    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)-7s %(name)-28s %(message)s",
        datefmt="%H:%M:%S")
    if getattr(args, "mode", None):
        os.environ["PK_LLM_MODE"] = args.mode
    cfg = Config()
    if cfg.llm_mode != "api":
        logging.info("LLM mode: %s", cfg.llm_mode)

    if args.cmd == "run":
        order = sorted(STAGES)
        keys = order[order.index(args.start): order.index(args.end) + 1]
        if args.incremental:
            keys = [k for k in keys if k not in GATES]
        for k in keys:
            name, desc = STAGES[k]
            logging.info("─── stage %s  %s", k, desc)
            result = _dispatch(k, cfg)
            logging.info("─── stage %s done: %s", k, result)
            if k in GATES and not args.yes:
                report = result.get("report", "")
                print(f"\nGATE {k}. Open {report} in a browser, make the decisions, "
                      f"download the JSON next to this pipeline, then continue:\n"
                      f"  python -m pipeline run --from "
                      f"{order[order.index(k)+1]} --to {args.end}\n")
                return 0
        return 0

    if args.cmd == "stage":
        print(_dispatch(args.key, cfg))
        return 0

    if args.cmd == "freeze-ontology":
        from .gates import freeze_ontology
        print(freeze_ontology(cfg, args.decisions))
        return 0

    if args.cmd == "scan-spring":
        from .scan_spring import run
        print(run(cfg, args.src, args.approved_bom))
        return 0

    if args.cmd == "handoff":
        from . import handoff
        fn = {"export": handoff.export, "import": handoff.import_responses,
              "status": handoff.status}[args.action]
        result = fn(cfg)
        for k, v in result.items():
            print(f"  {k}: {v}")
        return 0

    if args.cmd == "eval":
        from .stage08_eval import run
        print(run(cfg))
        return 0

    if args.cmd == "stats":
        from .config import read_json
        for f in ("analysis/manifest.json", "analysis/clusters.json",
                  "graph/nodes.json", "graph/edges.json", "graph/guardrails.json"):
            data = read_json(cfg.root / f, [])
            print(f"{f:34} {len(data)}")
        return 0

    return 1


if __name__ == "__main__":
    sys.exit(main())
