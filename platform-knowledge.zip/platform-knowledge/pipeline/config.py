"""Configuration and resumable state.

Every stage keys its outputs by page id and content hash. Re-running a stage
skips any page whose hash is unchanged, which is what makes the weekly refresh
cost proportional to what actually changed rather than to corpus size.
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import dataclass, field
from pathlib import Path


def _env(name: str, default: str | None = None, required: bool = False) -> str:
    val = os.environ.get(name, default)
    if required and not val:
        raise SystemExit(
            f"Missing required environment variable {name}. "
            f"Copy .env.example to .env and fill it in."
        )
    return val or ""


@dataclass
class Config:
    base_url: str = field(default_factory=lambda: _env("CONFLUENCE_BASE_URL", required=True))
    token: str = field(default_factory=lambda: _env("CONFLUENCE_PAT", required=True))
    space_key: str = field(default_factory=lambda: _env("CONFLUENCE_SPACE_KEY", required=True))
    root_page_id: str = field(default_factory=lambda: _env("CONFLUENCE_ROOT_PAGE_ID", required=True))

    root: Path = field(default_factory=lambda: Path(_env("PK_ROOT", ".")).resolve())

    # api | handoff | deterministic
    #   api           call a model directly (needs a key or an internal gateway)
    #   handoff       queue prompts for GitHub Copilot to answer in the IDE
    #   deterministic no model at all; structure and pattern matching only
    llm_mode: str = field(default_factory=lambda: _env("PK_LLM_MODE", "api"))
    llm_model: str = field(default_factory=lambda: _env("PK_LLM_MODEL", "claude-sonnet-5"))
    llm_api_key: str = field(default_factory=lambda: _env("ANTHROPIC_API_KEY"))
    llm_base_url: str = field(default_factory=lambda: _env("PK_LLM_BASE_URL"))

    max_workers: int = field(default_factory=lambda: int(_env("PK_MAX_WORKERS", "6")))
    verify_tls: str = field(default_factory=lambda: _env("PK_VERIFY_TLS", "true"))

    # Stage 2/3 tuning
    cluster_threshold: float = 0.55
    sample_per_cluster: int = 3
    max_induction_pages: int = 40
    type_frequency_floor: int = 5

    # Stage 5 tuning
    min_confidence: float = 0.6
    max_chunk_chars: int = 6000

    # Stage 1 pruning
    stale_after_days: int = int(_env("PK_STALE_AFTER_DAYS", "1095"))

    def __post_init__(self) -> None:
        if self.llm_mode not in ("api", "handoff", "deterministic"):
            raise SystemExit(
                f"PK_LLM_MODE must be api, handoff or deterministic, "
                f"not {self.llm_mode!r}")
        for d in ("raw", "normalized", "attachments", "analysis", "graph",
                  "review", "out", ".state", "eval"):
            (self.root / d).mkdir(parents=True, exist_ok=True)

    @property
    def tls(self) -> bool | str:
        v = self.verify_tls.strip()
        if v.lower() in ("true", "1", "yes"):
            return True
        if v.lower() in ("false", "0", "no"):
            return False
        return v  # path to a corporate CA bundle

    def p(self, *parts: str) -> Path:
        return self.root.joinpath(*parts)


def content_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", "replace")).hexdigest()[:16]


class State:
    """Tiny JSON-backed checkpoint store."""

    def __init__(self, cfg: Config, name: str) -> None:
        self.path = cfg.p(".state", f"{name}.json")
        self.data: dict = {}
        if self.path.exists():
            self.data = json.loads(self.path.read_text())

    def unchanged(self, key: str, digest: str) -> bool:
        return self.data.get(key) == digest

    def mark(self, key: str, digest: str) -> None:
        self.data[key] = digest

    def save(self) -> None:
        self.path.write_text(json.dumps(self.data, indent=0))


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False, default=str))


def read_json(path: Path, default=None):
    if not path.exists():
        return default
    return json.loads(path.read_text())
