"""Build the migration.* namespace by scanning your actual Spring Boot codebase.

This runs in the opposite direction from the Confluence pipeline. Confluence
tells you what the platform expects; this tells you what you actually have. The
intersection is the real migration surface, and it is far smaller than Spring's
API surface, because you only use a fraction of it.

The output feeds `.github/skills/springboot-to-quarkus-migration/references/`.
"""

from __future__ import annotations

import json
import logging
import re
from collections import Counter
from pathlib import Path

from .config import Config, read_json, write_json

log = logging.getLogger(__name__)

ANNOTATION = re.compile(r"@(\w+)")
IMPORT = re.compile(r"^\s*import\s+(org\.springframework[\w.]*|jakarta[\w.]*|javax[\w.]*);", re.M)
DEP = re.compile(r"<artifactId>([^<]+)</artifactId>")
GRADLE_DEP = re.compile(r"['\"]([\w.\-]+:[\w.\-]+)(?::[\w.\-]+)?['\"]")

# Curated mapping. Confluence will not contain this; it comes from the Quarkus
# catalogue and is then constrained by your platform's approved BOM.
BASE_MAP = {
    "RestController": ("jakarta.ws.rs @Path + @GET/@POST (Quarkus REST)",
                       "Do not reach for quarkus-spring-web; it defers the migration"),
    "RequestMapping": ("@Path", "Method-level HTTP verb annotations replace the method attribute"),
    "GetMapping": ("@GET + @Path", ""),
    "PostMapping": ("@POST + @Path", ""),
    "PathVariable": ("@PathParam", ""),
    "RequestParam": ("@QueryParam", ""),
    "RequestBody": ("(implicit: the unannotated method parameter)", ""),
    "Service": ("@ApplicationScoped", "CDI scopes resolve at build time"),
    "Component": ("@ApplicationScoped", ""),
    "Repository": ("@ApplicationScoped, or a Panache repository", ""),
    "Autowired": ("@Inject", "Constructor injection is preferred and needs no annotation"),
    "Value": ("@ConfigProperty", ""),
    "ConfigurationProperties": ("@ConfigMapping",
                                "Interface-based with accessor methods, not a POJO with setters"),
    "Bean": ("@Produces", ""),
    "Configuration": ("a class with @Produces methods", ""),
    "Transactional": ("jakarta.transaction.Transactional", "Different package, same name"),
    "Scheduled": ("@Scheduled (quarkus-scheduler)", "Cron syntax differs"),
    "Async": ("Mutiny Uni/Multi, or @Blocking on a worker thread",
              "Not a mechanical swap; the calling contract changes"),
    "Cacheable": ("@CacheResult (quarkus-cache)", ""),
    "SpringBootTest": ("@QuarkusTest", "Use RestAssured for endpoint tests"),
    "MockBean": ("@InjectMock (quarkus-junit5-mockito)", ""),
    "PreAuthorize": ("@RolesAllowed", "Check how the platform gateway propagates identity"),
    "ControllerAdvice": ("an ExceptionMapper<T>", ""),
    "ExceptionHandler": ("ExceptionMapper.toResponse", ""),
    "Entity": ("@Entity (unchanged), consider PanacheEntity", ""),
    "FeignClient": ("@RegisterRestClient", "Config keys are per-client-prefix"),
    "EnableScheduling": ("(not needed; the extension is enough)", ""),
    "ComponentScan": ("(no equivalent; build-time indexing replaces it)",
                      "Beans in external jars need a Jandex index"),
}

DEP_MAP = {
    "spring-boot-starter-web": "quarkus-rest, quarkus-rest-jackson",
    "spring-boot-starter-webflux": "quarkus-rest (reactive) + Mutiny",
    "spring-boot-starter-data-jpa": "quarkus-hibernate-orm-panache + a JDBC extension",
    "spring-boot-starter-security": "quarkus-oidc or quarkus-smallrye-jwt",
    "spring-boot-starter-actuator": "quarkus-smallrye-health, quarkus-micrometer-registry-prometheus",
    "spring-boot-starter-validation": "quarkus-hibernate-validator",
    "spring-boot-starter-cache": "quarkus-cache",
    "spring-boot-starter-amqp": "quarkus-messaging-amqp",
    "spring-kafka": "quarkus-messaging-kafka",
    "spring-cloud-starter-openfeign": "quarkus-rest-client-jackson",
    "spring-cloud-starter-config": "quarkus-config-consul or quarkus-vault",
    "springdoc-openapi-ui": "quarkus-smallrye-openapi",
    "spring-boot-starter-graphql": "quarkus-smallrye-graphql",
    "resilience4j-spring-boot2": "quarkus-smallrye-fault-tolerance",
}

GOTCHAS = [
    ("build-time DI", "Quarkus resolves injection at build time. Runtime bean lookup, "
                      "conditional bean registration and dynamic proxies do not translate."),
    ("native image", "Reflection, dynamic class loading and resource loading need explicit "
                     "registration. Anything reflective must be declared."),
    ("reactive", "CompletableFuture-based async becomes Mutiny Uni/Multi. This changes the "
                 "calling contract, so it propagates outward through the call chain."),
    ("config", "Profile syntax and property precedence differ. Do not assume a "
               "copied application.yml behaves the same."),
    ("jandex", "Beans in a dependency jar are invisible unless that jar has a Jandex index."),
]


def run(cfg: Config, src: str, approved_bom: str | None = None) -> dict:
    root = Path(src).resolve()
    if not root.exists():
        raise SystemExit(f"{root} does not exist")

    annotations, imports, deps = Counter(), Counter(), Counter()
    files = 0
    for p in root.rglob("*.java"):
        if any(part in {"target", "build", ".git"} for part in p.parts):
            continue
        files += 1
        text = p.read_text(errors="ignore")
        for m in IMPORT.finditer(text):
            imports.update([m.group(1)])
        body = re.sub(r"^\s*import .*$", "", text, flags=re.M)
        annotations.update(ANNOTATION.findall(body))

    for pom in root.rglob("pom.xml"):
        deps.update(DEP.findall(pom.read_text(errors="ignore")))
    for gr in list(root.rglob("build.gradle")) + list(root.rglob("build.gradle.kts")):
        for d in GRADLE_DEP.findall(gr.read_text(errors="ignore")):
            deps.update([d.split(":")[1]])

    approved = set(read_json(Path(approved_bom), []) if approved_bom else [])

    rows = []
    for ann, count in annotations.most_common():
        if ann not in BASE_MAP:
            continue
        target, gotcha = BASE_MAP[ann]
        flagged = ""
        if approved:
            ext = re.findall(r"quarkus-[\w-]+", target)
            unapproved = [e for e in ext if e not in approved]
            if unapproved:
                flagged = f" NOT IN APPROVED BOM: {', '.join(unapproved)}"
        rows.append({"spring": f"@{ann}", "quarkus": target,
                     "gotcha": (gotcha + flagged).strip(), "occurrences": count})

    for dep, count in deps.most_common():
        if dep in DEP_MAP:
            rows.append({"spring": dep, "quarkus": DEP_MAP[dep],
                         "gotcha": "dependency", "occurrences": count})

    unmapped = [a for a, c in annotations.most_common()
                if a not in BASE_MAP and c >= 3
                and any(a in i for i in imports if i.startswith("org.springframework"))]

    write_json(cfg.p("graph", "spring_quarkus_mapping.json"), rows)
    write_json(cfg.p("analysis", "spring_scan.json"), {
        "files_scanned": files,
        "spring_imports": imports.most_common(40),
        "annotations": annotations.most_common(60),
        "dependencies": deps.most_common(60),
        "unmapped_spring_annotations": unmapped,
        "gotchas": [{"name": n, "detail": d} for n, d in GOTCHAS],
    })

    skill_ref = cfg.p("out", ".github", "skills",
                      "springboot-to-quarkus-migration", "references")
    skill_ref.mkdir(parents=True, exist_ok=True)
    table = ["| Spring construct | Quarkus target | Occurrences | Gotcha |", "|---|---|---|---|"]
    table += [f"| `{r['spring']}` | {r['quarkus']} | {r['occurrences']} | {r['gotcha']} |"
              for r in rows]
    table += ["", "## Behavioural differences that break a mechanical port", ""]
    table += [f"- **{n}** — {d}" for n, d in GOTCHAS]
    if unmapped:
        table += ["", "## Unmapped Spring annotations found in your code", "",
                  "These need a decision before migration starts:", ""]
        table += [f"- `@{a}`" for a in unmapped]
    (skill_ref / "mapping-table.md").write_text("\n".join(table) + "\n")

    log.info("Scanned %d java files: %d mapped constructs, %d unmapped",
             files, len(rows), len(unmapped))
    return {"files": files, "mapped": len(rows), "unmapped": unmapped}
