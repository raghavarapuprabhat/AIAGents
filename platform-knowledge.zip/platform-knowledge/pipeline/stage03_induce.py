"""Stage 3 -- induce a candidate ontology from cluster representatives.

Open-schema extraction runs here and only here, on ~40 sampled pages. Running it
across the whole corpus produces an unmergeable pile of near-synonym types and
costs many times more, which is the failure mode this two-tier design exists to
avoid.

The output is a *candidate* ontology. It is not used for extraction until a human
signs it off at gate 1, because the type names become the vocabulary of every
generated instruction file and every code comment Copilot writes downstream.
"""

from __future__ import annotations

import logging
import re
from collections import Counter, defaultdict

from .config import Config, read_json, write_json
from .llm import LLM, PromptQueued, wrap_untrusted

log = logging.getLogger(__name__)

INDUCE_SYSTEM = """You are an ontology engineer analysing an internal engineering wiki.

Extract the entity types and relationship types this document implies.

Hard rules:
- Use the DOCUMENT'S OWN terminology for type names. If it says "Plugin", the type
  is Plugin, not Microfrontend. Never substitute an industry-standard synonym.
- A type is a class of thing, not an instance. "Payments Plugin" is an instance of
  the type "Plugin".
- Only emit a type if the document actually distinguishes it from others.
- Prefer few, well-evidenced types over many speculative ones.

Return ONLY JSON:
{
  "node_types": [
    {"type_name": "...", "definition": "...", "instances": ["..."],
     "evidence_quote": "verbatim span from the document", "confidence": 0.0-1.0}
  ],
  "edge_types": [
    {"predicate": "...", "subject_type": "...", "object_type": "...",
     "evidence_quote": "verbatim span", "confidence": 0.0-1.0}
  ],
  "lifecycle_stage": "the lifecycle stage this page belongs to, or null",
  "page_archetype": "a short name for what KIND of page this is"
}"""

COVERAGE_SYSTEM = """Given this fixed ontology, extract entities from the document.

ONTOLOGY NODE TYPES: {types}

Return ONLY JSON:
{{"matched": [{{"type": "...", "label": "...", "quote": "..."}}],
  "unmatched": [{{"label": "...", "quote": "...", "why": "no type fits because ..."}}]}}

Put anything the ontology cannot express in "unmatched". Do not force a bad fit."""


def _normalise(name: str) -> str:
    n = re.sub(r"[^a-zA-Z0-9 ]+", " ", name).strip().lower()
    n = re.sub(r"\s+", " ", n)
    for suffix in (" type", " entity", " object", " artifact"):
        if n.endswith(suffix):
            n = n[: -len(suffix)]
    if n.endswith("ies"):
        n = n[:-3] + "y"
    elif n.endswith("ses") or n.endswith("xes"):
        n = n[:-2]
    elif n.endswith("s") and not n.endswith("ss"):
        n = n[:-1]
    return n.strip()


def _pascal(name: str) -> str:
    return "".join(w.capitalize() for w in re.split(r"[^a-zA-Z0-9]+", name) if w)


def _token_sim(a: str, b: str) -> float:
    ta, tb = set(a.split()), set(b.split())
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def _sample(cfg: Config, clusters: list[dict]) -> list[str]:
    picked: list[str] = []
    for c in clusters:
        picked.extend(c["representative_page_ids"][: cfg.sample_per_cluster])
        if len(picked) >= cfg.max_induction_pages:
            break
    # Always include the highest guardrail-density pages; they carry the
    # constraint vocabulary that representative pages can miss.
    density = read_json(cfg.p("analysis", "guardrail_density.json"), [])
    for d in density[:6]:
        if d["page_id"] not in picked:
            picked.append(d["page_id"])
    return picked[: cfg.max_induction_pages + 6]


def run(cfg: Config) -> dict:
    if cfg.llm_mode == "deterministic":
        from .deterministic import induce_ontology
        return induce_ontology(cfg)

    clusters = read_json(cfg.p("analysis", "clusters.json"), [])
    if not clusters:
        raise SystemExit("No clusters. Run stage 02 first.")
    llm = LLM(cfg).for_stage("03-induce")

    sample_ids = _sample(cfg, clusters)
    log.info("Inducing ontology from %d sampled pages across %d clusters",
             len(sample_ids), len(clusters))

    raw_nodes: list[dict] = []
    raw_edges: list[dict] = []
    archetypes: Counter = Counter()
    page_of_cluster = {pid: c["cluster_id"] for c in clusters for pid in c["member_page_ids"]}

    for pid in sample_ids:
        md_path = cfg.p("normalized", f"{pid}.md")
        if not md_path.exists():
            continue
        body = md_path.read_text()[: cfg.max_chunk_chars * 2]
        try:
            result = llm.complete_json(INDUCE_SYSTEM, wrap_untrusted(body), max_tokens=3000)
        except PromptQueued:
            continue
        except Exception as exc:  # noqa: BLE001
            log.error("Induction failed for %s: %s", pid, exc)
            continue
        if result.get("page_archetype"):
            archetypes.update([str(result["page_archetype"]).lower()])
        for n in result.get("node_types", []):
            n["_page_id"] = pid
            n["_cluster"] = page_of_cluster.get(pid, "?")
            raw_nodes.append(n)
        for e in result.get("edge_types", []):
            e["_page_id"] = pid
            raw_edges.append(e)

    if llm.queued:
        return _await_handoff(cfg, llm, "03")

    # ---- merge synonyms -----------------------------------------------------
    groups: list[dict] = []
    for n in raw_nodes:
        key = _normalise(n.get("type_name", ""))
        if not key:
            continue
        target = None
        for g in groups:
            if key == g["key"] or _token_sim(key, g["key"]) >= 0.6:
                target = g
                break
        if target is None:
            target = {"key": key, "surface_forms": Counter(), "records": []}
            groups.append(target)
        target["surface_forms"].update([n["type_name"].strip()])
        target["records"].append(n)

    # ---- frequency floor and canonical naming -------------------------------
    candidate_nodes, demoted = [], []
    for g in groups:
        instances = {i.strip() for r in g["records"] for i in (r.get("instances") or []) if i}
        count = max(len(instances), len(g["records"]))
        canonical = g["surface_forms"].most_common(1)[0][0]
        aliases = sorted({s for s in g["surface_forms"] if s != canonical})
        entry = {
            "name": f"platform.{_pascal(canonical)}",
            "canonical_label": canonical,
            "aliases": aliases,
            "definition": _best_definition(g["records"]),
            "evidence": {
                "instance_count": count,
                "clusters": sorted({r["_cluster"] for r in g["records"]}),
                "source_page_ids": sorted({r["_page_id"] for r in g["records"]})[:5],
                "example_instances": sorted(instances)[:8],
                "example_quote": _best_quote(g["records"]),
            },
            "mean_confidence": round(
                sum(float(r.get("confidence", 0.5)) for r in g["records"]) / len(g["records"]), 2),
        }
        (candidate_nodes if count >= cfg.type_frequency_floor else demoted).append(entry)

    candidate_nodes.sort(key=lambda e: -e["evidence"]["instance_count"])
    if len(candidate_nodes) > 15:
        demoted.extend(candidate_nodes[15:])
        candidate_nodes = candidate_nodes[:15]

    valid_names = {e["canonical_label"].lower() for e in candidate_nodes}
    alias_map = {a.lower(): e["canonical_label"] for e in candidate_nodes for a in e["aliases"]}
    alias_map.update({e["canonical_label"].lower(): e["canonical_label"] for e in candidate_nodes})

    # ---- edges --------------------------------------------------------------
    edge_groups: dict[str, dict] = defaultdict(
        lambda: {"domain": Counter(), "range": Counter(), "count": 0,
                 "pages": set(), "surface": Counter(), "quote": ""})
    for e in raw_edges:
        pred = re.sub(r"[^a-zA-Z0-9]+", "_", str(e.get("predicate", ""))).strip("_").upper()
        if not pred:
            continue
        subj = alias_map.get(str(e.get("subject_type", "")).lower())
        obj = alias_map.get(str(e.get("object_type", "")).lower())
        g = edge_groups[pred]
        g["count"] += 1
        g["surface"].update([e.get("predicate", "")])
        g["pages"].add(e["_page_id"])
        if subj:
            g["domain"].update([f"platform.{_pascal(subj)}"])
        if obj:
            g["range"].update([f"platform.{_pascal(obj)}"])
        if not g["quote"]:
            g["quote"] = e.get("evidence_quote", "")

    candidate_edges = [
        {"name": pred,
         "domain": [d for d, _ in g["domain"].most_common(3)],
         "range": [r for r, _ in g["range"].most_common(3)],
         "aliases": sorted({s for s in g["surface"] if s.upper() != pred}),
         "evidence": {"instance_count": g["count"],
                      "source_page_ids": sorted(g["pages"])[:5],
                      "example_quote": g["quote"]}}
        for pred, g in edge_groups.items()
        if g["count"] >= max(3, cfg.type_frequency_floor - 2) and g["domain"] and g["range"]
    ]
    candidate_edges.sort(key=lambda e: -e["evidence"]["instance_count"])
    candidate_edges = candidate_edges[:10]

    lifecycle = read_json(cfg.p("analysis", "lifecycle.json"), [])
    ontology = {
        "version": 0,
        "status": "candidate -- NOT frozen, requires gate 1 sign-off",
        "namespaces": {
            "platform": "Concepts discovered in Confluence. Confluence is truth; "
                        "where prose and a code sample disagree, the code sample wins.",
            "migration": "Concepts from your own codebase scan and the Quarkus "
                         "extension catalogue. Code and official docs are truth. "
                         "Kept separate so provenance stays coherent when the two "
                         "namespaces disagree.",
        },
        "lifecycle_stages": [s["stage"] for s in lifecycle],
        "node_types": candidate_nodes + _migration_namespace(),
        "edge_types": candidate_edges + _migration_edges(),
        "demoted": [{"name": d["name"], "instance_count": d["evidence"]["instance_count"],
                     "reason": "below frequency floor or outside the 15-type cap; "
                               "treat as an attribute, not a type"} for d in demoted],
        "page_archetypes": archetypes.most_common(),
        "stats": {"sampled_pages": len(sample_ids), "clusters": len(clusters),
                  "llm_calls": llm.calls, "cache_hits": llm.cache_hits},
    }
    write_json(cfg.p("graph", "ontology.candidate.yaml.json"), ontology)
    _write_yaml(cfg.p("graph", "ontology.candidate.yaml"), ontology)

    coverage = _coverage_test(cfg, llm, clusters, sample_ids, candidate_nodes)
    write_json(cfg.p("analysis", "coverage.json"), coverage)

    log.info("Candidate ontology: %d node types, %d edge types, coverage %.0f%%",
             len(candidate_nodes), len(candidate_edges), coverage["coverage_pct"])
    return {"node_types": len(candidate_nodes), "edge_types": len(candidate_edges),
            "coverage_pct": coverage["coverage_pct"]}


def _await_handoff(cfg: Config, llm: LLM, stage: str) -> dict:
    log.warning(
        "%d prompt(s) queued for GitHub Copilot. Nothing was written yet.\n"
        "  1. python -m pipeline handoff export\n"
        "  2. in VS Code, run /process-knowledge-queue\n"
        "  3. python -m pipeline handoff import\n"
        "  4. python -m pipeline stage %s   (re-run; completes from cache)",
        llm.queued, stage)
    return {"queued": llm.queued, "mode": "handoff",
            "next": "python -m pipeline handoff export"}


def _best_definition(records: list[dict]) -> str:
    defs = [r.get("definition", "") for r in records if r.get("definition")]
    return max(defs, key=len) if defs else ""


def _best_quote(records: list[dict]) -> str:
    qs = [r.get("evidence_quote", "") for r in records if r.get("evidence_quote")]
    return min(qs, key=len) if qs else ""


def _coverage_test(cfg: Config, llm: LLM, clusters, sample_ids, nodes) -> dict:
    """Held-out pages: does the draft schema express what is actually there?

    Below 80% means a type is missing. Above 95% with types barely used means the
    schema is too big and should be cut.
    """
    held_out = [pid for c in clusters for pid in c["member_page_ids"]
                if pid not in set(sample_ids)][:10]
    if not held_out:
        return {"coverage_pct": 100.0, "held_out": 0, "unmatched_examples": [],
                "note": "corpus too small for a held-out test"}
    types = ", ".join(n["canonical_label"] for n in nodes)
    matched = unmatched = 0
    examples, type_usage = [], Counter()
    for pid in held_out:
        p = cfg.p("normalized", f"{pid}.md")
        if not p.exists():
            continue
        try:
            r = llm.complete_json(COVERAGE_SYSTEM.format(types=types),
                                  wrap_untrusted(p.read_text()[: cfg.max_chunk_chars]),
                                  max_tokens=2500)
        except Exception:  # noqa: BLE001
            continue
        matched += len(r.get("matched", []))
        unmatched += len(r.get("unmatched", []))
        type_usage.update(m.get("type", "") for m in r.get("matched", []))
        examples.extend(r.get("unmatched", [])[:2])
    total = matched + unmatched
    pct = round(100.0 * matched / total, 1) if total else 0.0
    unused = [n["canonical_label"] for n in nodes if type_usage[n["canonical_label"]] == 0]
    verdict = ("PASS" if 80 <= pct else "FAIL: a node type is probably missing, "
                                        "review the unmatched examples")
    if pct >= 95 and unused:
        verdict += f" | schema may be too large; unused in held-out set: {unused}"
    return {"coverage_pct": pct, "held_out": len(held_out), "matched": matched,
            "unmatched": unmatched, "unmatched_examples": examples[:12],
            "type_usage": type_usage.most_common(), "unused_types": unused,
            "verdict": verdict}


def _migration_namespace() -> list[dict]:
    """Types that will never appear in Confluence because they do not come from
    there. Separate namespace, separate provenance rule."""
    return [
        {"name": "migration.SpringConstruct", "canonical_label": "Spring Construct",
         "aliases": [], "definition": "A Spring Boot annotation, starter or API in use "
                                      "in the source codebase.",
         "evidence": {"source": "static scan of your pom.xml and Java sources"},
         "mean_confidence": 1.0},
        {"name": "migration.QuarkusExtension", "canonical_label": "Quarkus Extension",
         "aliases": [], "definition": "A Quarkus extension, constrained to the "
                                      "platform-approved BOM where one exists.",
         "evidence": {"source": "Quarkus extension catalogue x platform approved list"},
         "mean_confidence": 1.0},
        {"name": "migration.Gotcha", "canonical_label": "Migration Gotcha",
         "aliases": [], "definition": "A known behavioural difference that breaks a "
                                      "mechanical port (build-time DI, native image "
                                      "reflection, reactive rewrite).",
         "evidence": {"source": "hand-curated from the golden slice migration"},
         "mean_confidence": 1.0},
    ]


def _migration_edges() -> list[dict]:
    return [
        {"name": "MAPS_TO", "domain": ["migration.SpringConstruct"],
         "range": ["migration.QuarkusExtension"], "aliases": [],
         "evidence": {"source": "hand-curated, reviewed at gate 1"}},
        {"name": "HAS_GOTCHA", "domain": ["migration.SpringConstruct"],
         "range": ["migration.Gotcha"], "aliases": [], "evidence": {"source": "hand-curated"}},
    ]


def _write_yaml(path, obj) -> None:
    try:
        import yaml
        path.write_text(yaml.safe_dump(obj, sort_keys=False, allow_unicode=True, width=100))
    except ImportError:
        pass
