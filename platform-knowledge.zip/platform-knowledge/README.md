# platform-knowledge

Turns a Confluence space into a distilled, versioned, machine-checkable context
layer that GitHub Copilot consumes, so Copilot writes code that matches your
platform's conventions instead of generic Spring/Quarkus/GraphQL defaults.

Built for **Confluence Data Center**, one space, one root page.

## Why not just point Copilot at Confluence

Raw wiki prose is the worst possible context: verbose, contradictory, stale, and
full of screenshots. This pipeline produces four tiers instead, each with a
different budget, because always-on context is the scarcest resource:

| Tier | Artifact | Loaded | Budget |
|---|---|---|---|
| 1 | `.github/copilot-instructions.md`, `AGENTS.md` | always | hard-capped at 1,500 words |
| 2 | `.github/instructions/*.instructions.md` | when a file matches `applyTo` | ~1 page each |
| 3 | `.github/skills/<name>/SKILL.md` + `references/` | on demand, by description | unbounded |
| 4 | MCP server (`mcp_server/server.py`) | queried by the agent | unbounded |

## Running without an LLM API key

Only stages 03 and 05 need language understanding. Stages 01, 02, 04, 06, 07 and
08 never call a model in any mode. Set `PK_LLM_MODE`:

| Mode | Needs | Quality |
|---|---|---|
| `handoff` | GitHub Copilot in the IDE, no API key | matches the api path |
| `deterministic` | nothing | good guardrail recall, much sparser graph |
| `api` | a key or an internal gateway | baseline |

### handoff

Copilot is a coding assistant, not a completions endpoint, so the pipeline
inverts the call: it writes the prompts to disk, Copilot answers them in the
editor, and the pipeline resumes from the answers.

```bash
python -m pipeline stage 03            # queues prompts, calls nothing
python -m pipeline handoff export      # writes llm_queue/pending/*.md
#   in VS Code:  /process-knowledge-queue     (generated for you)
python -m pipeline handoff import      # loads answers into the response cache
python -m pipeline stage 03            # completes offline from cache
```

This needs no special-casing inside the stages. `LLM.complete_json` already keys
its cache on sha256(model|system|user), so `handoff import` simply pre-populates
that cache and every stage runs unchanged. The import is tolerant of the ways
Copilot actually replies (bare JSON, fenced, fenced with a preamble) and rejects
anything unparseable rather than caching it silently. `handoff status` shows
progress; already-answered items are never re-exported, so the queue is
resumable across sessions.

### deterministic

No model at all. Types come from noun frequency across page titles and labels,
guardrails from modal phrasing, edges from explicit subject-verb-object
sentences.

On the test corpus this recovered `Plugin`, `Experience API`, `Process API` and
`Common Services` unaided, plus 114 guardrails with correct severities. It also
proposed `Rotate Secret` as a type, which is a task rather than a type: exactly
the kind of error gate 1 exists to catch, and the reason gate 1 matters *more*
on this path, not less.

What it misses is paraphrased and implied relationships, so the graph is sparser.
The eval suite reports this honestly rather than hiding it: on the test corpus
`graph-answers-call-chain` fails with a note explaining that only explicit
relationship sentences become edges. Everything produced this way is tagged
`extraction_method: deterministic`, so a later handoff pass can supersede it.

## Human cost is flat

Roughly three hours whether the space has 80 pages or 3,000. Only stage 5 touches
the full corpus, and it does so with a closed schema and short outputs.

| Stage | Machine | Human |
|---|---|---|
| 01 crawl | 20–40 min | 0 |
| 02 fingerprint (no LLM, no network) | ~5 min | 0 |
| 03 induce ontology (~40 LLM calls) | ~15 min | 0 |
| **04 GATE 1 — ontology review** | — | **90 min, one platform SME** |
| 05 extract full corpus + resolve | 1–3 hrs | 0 |
| **06 GATE 2 — conflicts, low confidence** | — | **60 min** |
| 07 generate the Copilot layer | ~10 min | 0 |
| 08 eval | ~20 min | 30 min, first time only |

## Quick start

```bash
pip install -r requirements.txt
cp .env.example .env && $EDITOR .env     # base URL, space key, root page id, PAT
set -a && source .env && set +a

python -m pipeline run --from 01 --to 08
```

`run` stops at each gate and tells you which report to open. After gate 1:

```bash
# review/gate1.html -> download decisions -> save as gate1.decisions.json
python -m pipeline freeze-ontology
python -m pipeline run --from 05 --to 08
```

Build the migration namespace from your own code, in the opposite direction:

```bash
python -m pipeline scan-spring --src ../payments-service \
                               --approved-bom approved-extensions.json
```

Weekly refresh (also wired as a GitHub Action):

```bash
python -m pipeline run --incremental && python -m pipeline stage 08
```

## Design decisions worth knowing

**Two-tier cost model.** A deterministic pass runs over 100% of pages; the
open-ended LLM pass runs over ~40 sampled pages. Running open extraction on the
whole corpus produces an unmergeable pile of near-synonym types and costs many
times more.

**The ontology is induced, not assumed.** Stage 2 clusters pages on heading
skeletons and table header sets, because pages written from the same Confluence
template share both, and shared template means shared type. Stage 3 then samples
cluster representatives and extracts types **using the document's own
vocabulary**. If your wiki says *Plugin*, the type is `platform.Plugin` and
`microfrontend` is only an alias. Getting this backwards means every artifact
Copilot produces is subtly foreign to your reviewers and greps against nothing.

**Two namespaces, two provenance rules.** `platform.*` comes from Confluence
(Confluence is truth; where prose and a code sample disagree, the code sample
wins). `migration.*` comes from your codebase scan and the Quarkus catalogue
(code and official docs are truth). Mixing them makes provenance incoherent the
first time they disagree, which they will.

**Four validators before anything enters the graph.** Type in the closed enum;
edge respects `domain`/`range`; `source_quote` present verbatim in the source
chunk; confidence above threshold. The verbatim-quote check kills most
hallucinated triples on its own.

**Entity resolution is not optional.** The same service appears as its full name,
its acronym, its repo name and its internal code name. Without resolution you get
four nodes where you meant one and the graph answers nothing.

**Guardrails are mined deterministically.** Modal phrasing and panel macros fix
the *set* of normative statements by regex; the LLM only classifies them. The
model is never asked to produce a rule, because guardrails have the lowest
tolerance for error in the whole corpus.

**Nothing about the output filenames is hardcoded.** The skills are one per
cluster discovered in stage 2, named from the lead verb and the noun shared
across the cluster's page titles. The tier-2 `applyTo` globs are inferred from
the code languages and attachment types on the pages each rule came from, so a
type gate 1 invents or renames still gets a correct glob. A type with no file
evidence anywhere gets no tier-2 file at all rather than a fabricated glob, and
is reported in `analysis/unroutable_types.json`; its rules still reach Copilot
through the skills tier.

**Disputed facts are excluded, not guessed.** Anything unresolved at gate 2 is
marked `disputed` and never reaches a generated instruction file.

## The pipeline cannot write to Confluence

This is enforced, not merely intended. "We never wrote a POST call" holds only
until someone adds one, and this repository is explicitly meant to be extended
by an AI coding assistant, so the constraint lives at the transport:

- **`ReadOnlySession`** overrides `requests.Session.request()`. Every helper
  (`post`, `put`, `delete`, `patch`) funnels through it, so the block holds even
  for a caller that reaches past the client into `client._session`.
- **Legacy action URLs are refused.** Confluence Server/DC still exposes
  endpoints that mutate on a plain GET (`removepage.action`, `doeditpage.action`
  and friends), so restricting the HTTP verb alone would not be enough.
- **`ConfluenceClient` refuses a plain-session substitution**, so the protection
  cannot be removed by passing in an ordinary `requests.Session`.
- **No `X-Atlassian-Token` header.** That header exists to satisfy Confluence's
  CSRF check on state-changing requests. A read-only client has no use for it,
  and sending it would only help an accidental write succeed.
- **Method names are allowlisted by a test.** Every public method on the client
  must start with a read verb, so a newly added `create_page` fails CI on its
  name before anyone has to notice what it does.
- **The MCP server never touches the network** and holds no Confluence
  credential. A test asserts it imports no HTTP library.

`tests/test_readonly.py` covers all of the above.

### The credential is a separate control

A Data Center personal access token has **no independent scope**: it inherits
every permission of the account that created it. A token you create with your own
account can edit and delete pages no matter what this code does. The transport
block is the technical control; constrain the credential too:

- Create the token under a **service account with View-only permission** on the
  space, not under a named engineer.
- Set an expiry, and rotate it.
- Stage 01 calls `permission_report()` and writes `analysis/access_report.json`.
  If the account can write, it logs a warning naming the operations. If the check
  is inconclusive because permission expansion is restricted, it says so plainly
  rather than implying safety.

## Other security notes

- The PAT lives in `.env` / CI secrets, never in the repo.
- **Classify before you publish.** Decide the visibility of this repo before the
  first run. Some of a platform space is usually internal-confidential.
- **Confluence is untrusted input.** Anyone with edit rights on a page can write
  text that a downstream agent reads as instructions. Two defences are wired in:
  imperative directive phrasing is neutralised in `stage01_crawl._defang`, and
  every LLM prompt wraps page content in an explicit untrusted-data envelope.
- Be conservative with `allowed-tools` in any generated SKILL.md. Pre-approving
  `shell` removes the confirmation step and lets an injected instruction run
  commands.

## Known limits

- **Diagrams are opaque.** draw.io, Gliffy and image attachments carry real
  architecture that no text pass recovers. Either run them through a
  vision-capable model or write the descriptions by hand. A missing architecture
  diagram is a genuine gap in Copilot's context, not a rounding error.
- **Confluence lies.** Expect 20–30% of platform docs to be out of date. Where a
  reference implementation repo exists, treat code as truth and the wiki as a
  hint. `analysis/pruned.json` and `flagged_dead` in the manifest show what the
  crawler already doubts.
- **Late lifecycle stages are usually undocumented.** `analysis/lifecycle_gaps.json`
  lists which of test / build / deploy / version / support / retire have no pages.
  Those hold the constraints that fail your delivery pipeline, and they are
  normally held verbally. Raise them at gate 1.
- The `migration.*` mapping table is seeded, not exhaustive. It is meant to be
  intersected with your platform's approved extension BOM.

## Where the graph lives

Plain JSON in `graph/`, committed to git. Not a graph database, deliberately:

- A few thousand pages yields roughly 300–2,000 nodes. That is megabytes, and
  in-memory traversal is faster than a database round trip.
- The requirement is not fast queries, it is **knowing what changed and being
  able to reject it**. `git diff graph/guardrails.json` shows that a MUST rule
  disappeared because someone edited a page. A database shows nothing, and you
  would build a diffing layer on top to get back what git gives free.
- The graph is regenerated, never mutated. No incremental writes, no
  transactions, no concurrency: none of the properties a database exists for.
- A new datastore in a bank means provisioning, security review, DR sign-off and
  an on-call owner. That, not query performance, is what stalls projects.

Move to DuckDB (as a derived index) above ~10k nodes or when several teams query
concurrently; move to Neo4j if you need 4+ hop traversal or path ranking. In both
cases the JSON stays the source of truth and the database becomes a build
artifact, because inverting that loses the reviewable diff.

The graph inherits the classification of the source space. Decide this repo's
visibility before the first run: `rejected.json` and the skills' `references/`
copies hold the most verbatim source text.

The MCP server reloads these files on mtime change, so a merged refresh reaches
developers without an editor restart. `graph_status` reports the ontology
version and when each file was last regenerated.

## Layout

```
pipeline/
  confluence.py        Data Center client: Bearer PAT, start/limit paging, tree walk
  storage_format.py    storage XHTML -> markdown, macro-aware (the hard part)
  stage01_crawl.py     crawl, prune, normalise, defang, attachments
  stage02_fingerprint.py  clustering, lifecycle recovery, hubs, guardrail density
  stage03_induce.py    open-schema induction, synonym merge, coverage test
  gates.py             gate 1 + gate 2 HTML reports, ontology freeze
  stage05_extract.py   constrained extraction, validation, entity resolution
  stage07_generate.py  the Copilot layer
  stage08_eval.py      context-quality regression suite
  scan_spring.py       migration.* namespace from your codebase
mcp_server/server.py   tier-4 tools: list_types, find_entity, traverse,
                       get_rules, search_docs, check_migration
analysis/  graph/  review/  out/  .state/
```

## First-week sequence

1. Run stages 01–03 and hold gate 1 with a platform SME. Do not skip this; it is
   the cheapest, highest-yield hour in the project.
2. Run `scan-spring` against your Spring Boot service.
3. **Hand-migrate one vertical slice** (Widget → Experience API → Process API)
   before letting Copilot migrate anything. The diff becomes
   `references/golden-example-diff.md`, and Copilot pattern-matches against it far
   more strongly than against any prose.
4. Fill in `references/common-service-inventory.md`. Deciding migrate / replace /
   delete per module is the judgement Copilot cannot make, and skipping it is the
   most common way these migrations end up with 40% waste.
5. Add the verification Copilot cannot argue with: an ArchUnit rule banning
   `org.springframework.*`, contract tests between Experience and Process API, and
   a native-image build in CI.
