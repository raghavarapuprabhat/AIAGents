# DataForge — agent build prompts

Sequenced, self-contained prompts for driving Claude Sonnet (or Claude Code)
through the build. Attach `LLD.md` to every session. Run one prompt per session
or per agent turn; each ends with a verifiable check.

**Session opener — paste at the start of every session:**

> You are implementing DataForge, a cross-system mock data generation platform
> for banking. `LLD.md` is the authoritative specification — follow its file
> paths, function signatures and design tokens exactly. Do not add features it
> does not describe. When something is ambiguous, choose the simplest option
> that satisfies the named acceptance test and append a one-line note to
> `DECISIONS.md`. Work only on the milestone I name, run its tests, and stop.

---

### P0 — Skeleton (LLD § 3, § 13 M0)
> Implement milestone M0. Create the repository layout in LLD § 3 (backend and
> frontend trees, empty modules with docstrings where a later milestone fills
> them). Add `docker-compose.yml` with postgres:16, the FastAPI api on 8000 and
> the Vite web app on 5173. Backend: `app/main.py` with a `/health` endpoint,
> `app/config.py` using pydantic-settings, `app/db.py` with the SQLAlchemy
> engine/session/Base, Alembic initialised against it. Frontend: Vite + React +
> TypeScript, `src/styles.css` containing the token block from LLD § 10.1
> verbatim, and the app shell from § 10.2 (TopBar, Tabs with the six tab names,
> StatusBar) with six empty screen components. No business logic.
> **Check:** `docker compose up` starts all three; `curl localhost:8000/health`
> returns 200; the Studio shell renders with the correct tabs and colours.

### P1 — Data model & CRUD (§ 4, § 9.1–9.2, M1)
> Implement milestone M1. Write the SQLAlchemy models for every table in LLD § 4
> and a single Alembic migration creating them with the stated indexes. Add
> pydantic v2 schemas and CRUD routers for tables/columns, links, valuesets,
> scenarios, and file contents, matching the paths and payloads in LLD § 9.2.
> Implement `GET /api/bootstrap` returning exactly the shape in § 9.1. Add
> `scripts/seed_sample.py` that inserts the `samples/retail_bank` model of § 12.4
> as database objects. Write `tests/test_api_bootstrap_shape.py`.
> **Check:** `pytest tests/test_api_bootstrap_shape.py` passes and the seeded
> bootstrap response contains 3 systems, 4 tables, 3 links, 1 valueset.

### P2 — MDL compiler (§ 5, M2)
> Implement milestone M2. Create `app/mdl/grammar.lark` from LLD § 5.1 exactly,
> the AST dataclasses, the Lark-based parser, the resolver, the checker
> implementing stages 2–8 of § 5.2 (skip stage 9), the emitter for round-tripping,
> and `POST /api/models/{id}/compile` returning the Diagnostic shape of § 5.3 and
> § 9.3. Write the `samples/retail_bank/*.mdl` files. Add the five M2 acceptance
> tests named in LLD § 13.
> **Check:** all five tests pass; compiling the sample returns `ok: true`;
> introducing `decimal(10_000..500)` returns one `ERR_FIT` diagnostic with the
> correct line and column.

### P3 — Engine core (§ 7.1–7.5, 7.8, § 8 file adapter, M3)
> Implement milestone M3. Build the Plan IR (§ 7.1), the planner with
> system-flow-primary topological ordering (§ 7.2), the deterministic `cell_rng`
> (§ 7.3 — every draw in the engine must use it), the generator registry (§ 7.5),
> valueset tuple picking, the key vault, direct/conditional/function link
> resolution with cardinality tracking (§ 7.8, excluding two-pass), the file
> adapter (§ 8) writing CSV and Parquet under `runs/{run_id}/`, and
> `execute_run` in `app/engine/runner.py` driven by `POST /api/runs` as a
> background task with `GET /api/runs` polling. Add the six M3 acceptance tests.
> **Check:** all six pass. Two runs at the same seed produce byte-identical
> Parquet; every generated `(ENTITY_CODE, ENTITY_DESC)` pair exists in the
> valueset; `CPTY_VALUE` is drawn from `ACC_NO` exactly on rows where
> `CPTY_TYPE = 'ACCOUNT'`.

### P4 — Rules, scenarios, aggregates, two-pass (§ 7.4, 7.6, 7.7, 7.8, 7.10, M4)
> Implement milestone M4. Add rule domain narrowing by forward checking (§ 7.6)
> with the discriminator-first column ordering of § 7.5. Add scenario quota
> apportionment by largest remainder, IPOG pairwise coverage expansion, and
> boundary injection (§ 7.4). **Copy the `aggregate_engine` package from
> `aggregate-constraint-engine.zip` into `app/engine/aggregate/` unchanged,
> including its tests — do not reimplement the solver** — and wire it per § 7.7,
> including the running-balance guard. Implement two-pass deferred columns and
> patch artifacts (§ 7.8). Implement the validator and `RunReport` (§ 7.10,
> § 9.7). Add the seven M4 acceptance tests.
> **Check:** all seven pass; a run on the sample model reports 100% hard-rule
> pass and produces a patch artifact for `LATEST_CARD_STATUS`.

### P5 — Studio canvas, inspectors, valuesets (§ 10.3, 10.5, 10.9, M5)
> Implement milestone M5. Build the Zustand store of § 10.9 and the typed API
> client. Build the linkage canvas exactly as specified in LLD § 10.3: swimlane
> backdrop in flow order, React Flow on top, the custom `TableNode` with per-column
> handles and computed type labels, edge styling by link kind, drag-to-link
> creating a link via the API, and node position persistence. Build the Link and
> Column inspectors including physical type editing (dtype, length,
> precision/scale, nullable), the valueset `value source` + `field` selects, the
> multi-column binding note, and the live fit warning. Build the Valuesets screen
> per § 10.5 with the tuple grid, weights, CSV import and fit-check block. Add
> Vitest tests for the fit-check and binding-note logic.
> **Check:** dragging between two column handles creates a persisted link;
> selecting a column and changing its type updates the node label; a
> too-long valueset value shows the red fit warning in both screens.

### P6 — Studio editor, scenarios, runs (§ 10.4, 10.6, 10.7, M6)
> Implement milestone M6. Register the `mdl` Monaco language with the Monarch
> tokenizer and `mdl-light` theme from LLD § 10.4, bundling monaco locally (no
> CDN). Wire debounced save + compile and render diagnostics as editor markers;
> the returned error count must drive both the TopBar pill and the disabled state
> of the Generate button. Add the copilot card wired to the stub endpoint
> (§ 9.6). Build the Scenarios screen (§ 10.6) with sliders, total pill and
> largest-remainder normalisation, and the Runs screen (§ 10.7) with 1.5s polling,
> the metric grid, flow-ordered ingestion list including the pass-2 row, rule
> assertions and the coverage heat map with rule-excluded cells.
> **Check:** typing an invalid range squiggles in the editor and disables
> Generate; clicking Generate produces a run that polls to `verified` and renders
> the full report.

### P7 — Ingestion & schema import (§ 7.9, § 8, § 10.8, M7)
> Implement milestone M7. Implement the JDBC adapter (SQLAlchemy bulk insert,
> keyed UPDATE patches, `verify()` by row count and sampled key spot-checks) and
> the REST adapter, both against the `IngestionAdapter` ABC of LLD § 8. Implement
> flow-ordered ingestion orchestration: a child system's load starts only after
> its parents verify, and all patch artifacts apply only after every insert
> verifies. Implement schema import and drift detection (§ 7.9) with the
> `breaking` classification, plus the drift endpoints of § 9.5. Build the Schema
> import screen per § 10.8. Add `test_ingestion_order_follows_flow`.
> **Check:** the test passes; a JDBC run into a scratch Postgres schema verifies
> row counts and cross-system keys; changing a column type in the scratch schema
> is detected as `changed` and can be applied.

### P8 — Hardening (optional)
> Add the § 11 safety guardrails (environment `allow_write`, `max_rows` caps,
> `dryRun`), structured per-run logging with `GET /api/runs/{id}/log`, and the
> golden-fingerprint test of § 12.1. Then run the full suite and produce a
> `README.md` quickstart.
> **Check:** `pytest` fully green, `npm run build` clean, `docker compose up`
> yields a working Studio.

---

## Guidance for the agent

* **Reuse, don't reinvent:** the aggregate solver is already written and tested.
  Copy it. Its tests must keep passing unchanged.
* **The ordering rules are not cosmetic:** system flow order governs planning,
  generation and ingestion. Three separate acceptance tests exist for it.
* **Determinism is a hard requirement.** If you find yourself calling
  `random.random()` directly, you have introduced a bug.
* **Money is integer minor units** everywhere in the aggregate path. Never float.
* **The UI is a view over the model, not the source of truth.** Every mutation
  goes through the API; the store mirrors the server.

---

# Part B prompts — source intelligence, mapping and migration (M8–M15)

Prerequisite: P0–P7 complete and green. Attach `LLD.md` (v2.0). For every Part B
session, add to the opener: *"The LLM is always called through `LLMProvider`; tests
use `StubProvider`. Real rows never reach the control plane."*

### P9 — Graph and planes (LLD § 18, § 25.1, M8)
> Implement milestone M8. Add the § 18 tables in one Alembic migration (enable
> pgvector). Build `app/kg/` (models, store with supersede and bitemporal "as known
> at" queries, PROV-O JSON-LD export). Create the data-plane worker
> `app/worker/main.py` polling `job` with `FOR UPDATE SKIP LOCKED`, refusing
> rehearse/migrate/delta jobs whose `spec_hash` lacks an approved `mapping_spec`
> sign-off. Add `governance/roles.py` with the § 25.2 matrix. Add the four M8 tests.
> **Check:** M8 tests pass; the worker runs as a separate process and the API
> process holds no source credentials.

### P10 — Source intelligence (§ 20, § 26.2 Sources and Evidence, M9)
> Implement milestone M9. Create the `samples/legacy_v1_to_core_v2` fixture exactly
> as § 27.4 describes, including seeded issues and `golden.csv`. Build `app/intel/`:
> inventory, profiling with MinHash/HLL and format histograms and the k-threshold,
> deterministic semantic validators, UCC/IND/FD discovery with exact confirmation,
> sqlglot code mining, the arborescence structure solve, entity clustering, and the
> data-quality report. Every result is a claim with evidence and an activity. Build
> the Sources and Evidence screens. Add the six M9 tests.
> **Check:** M9 tests pass; the undeclared ACCT_MASTER → CUST_MASTER key is found
> with containment evidence and shown in the Evidence screen.

### P11 — Grounded LLM (§ 21.6, 21.7, 21.9, § 20.8, § 25.3, M10)
> Implement milestone M10. Build `app/llm/`: the `LLMProvider` protocol, a stub and
> one real provider (model id from config, recorded on every activity), versioned
> prompt files, grounded k-hop context, JSON-schema contracts, the deterministic
> validator with one repair round, keyed format-preserving masking, and the
> golden-set harness writing `eval_run`. Add confidence bands per § 21.8 and the
> isotonic calibrator behind the configurable label minimum. Add the four M10 tests.
> **Check:** M10 tests pass; an LLM proposal naming an unknown node is rejected and
> stored with its reasons.

### P12 — Concepts and specs (§ 19, M11)
> Implement milestone M11. Extend the Lark grammar with § 19.1 exactly, add the
> § 19.2 checks and decisions, compose `realize from` with `realize into` into the
> § 22.1 `MappingPlan` with `spec_hash`, and write `REALISES` and `MAPS_TO` claims on
> compile. Write the fixture's concepts, realisations and migration in MDL. Build
> the Concepts screen. Add the six M11 tests.
> **Check:** M11 tests pass; compiling the fixture lists the expected open decisions
> until they are decided, then compiles clean.

### P13 — Discovery and review (§ 21.1–21.5, 21.8, M12)
> Implement milestone M12. Build `app/mapping/`: entity alignment, candidate
> retrieval with pgvector, the 14-pattern classifier, the transform library with
> direction properties, assignment with `linear_sum_assignment`, bands, impact-ordered
> review queue, and example-driven synthesis. Build the Mapping review screen on the
> Part A drift-review pattern, with the decisions list. Add the four M12 tests.
> **Check:** M12 tests pass; every golden mapping in the fixture appears in the
> top-10 candidates, and the name split is learned from examples.

### P14 — Prove on synthetic data (§ 22.1–22.4, § 23.2–23.5, 23.7, M13)
> Implement milestone M13. Build the reference interpreter and the polars production
> executor from the same `MappingPlan`, sharing only the transform library. Build the
> deterministic crosswalk, partitioned idempotent loads with checkpoints, the ledger,
> quarantine, risk-aimed fixtures from the Part A scenario engine, differential and
> metamorphic tests, and mutation testing. Add the six M13 tests.
> **Check:** M13 tests pass; a synthetic rehearsal of the fixture shows zero diffs
> and zero unexplained ledger rows.

### P15 — Migrate (§ 22.5–22.9, § 23.6, 23.8, § 26, M14)
> Implement milestone M14. Build sizing, cutover-state handling, watermark delta,
> rehearsal runs and run-to-run diff attribution, PONR recording, control totals via
> the aggregate engine, round trip, cleanse rules with reject categories and owners,
> the behaviour comparator and test pack, four-eyes approval, and the sign-off gates.
> Build the Migration, Reconcile and Sign-offs screens and the § 26.1 endpoints. Add
> the ten M14 tests.
> **Check:** M14 tests pass; a dress rehearsal of the fixture produces a complete
> § 23.9 report, and cutover readiness stays blocked until all five sign-offs exist.

### P16 — Learn (§ 24, M15)
> Implement milestone M15. In the data plane, learn degree distributions,
> k-thresholded marginals (optional Laplace noise) and per-segment transaction
> sequence models; mine rare-but-valid edge patterns as scenario templates. Emit
> `learned()` generator specs for the Part A engine, generate target-shaped data
> through the `into` realisation, and support volume scaling with the value-space
> check. Add the privacy gate, the six-family fidelity report (advisory until
> thresholds are set from a baseline), and the versioned `learned_model` table with
> drift reports and pinned references. Build the Learned models screen and its
> endpoints. Add the eleven M15 tests.
> **Check:** M15 tests pass; synthetic CORE_V2 data generated from the fixture passes
> v2 constraints, a shuffled-column generator fails the fidelity report, a
> deliberately leaky model is blocked, and a 10× scaled run keeps its shape.

## Part B guidance for the agent

* **Claims, not facts.** Every inferred relationship, type or mapping is a claim
  with evidence and an activity. Never write an accepted claim without evidence.
* **Two executors stay independent.** Do not share code between the interpreter and
  the executor beyond the transform library and the IR.
* **The control plane never sees rows.** If a feature seems to need a real value in
  the API or UI, show a count, a hashed key or a masked value instead.
* **Open decisions block.** Do not add defaults that silently close a decision.
* **The fixture is the contract.** If a Part B test is hard to pass, fix the code,
  not the fixture, and record any fixture change in `DECISIONS.md`.
