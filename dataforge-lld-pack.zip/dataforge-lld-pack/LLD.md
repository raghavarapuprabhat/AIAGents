# DataForge — Low-Level Design & Build Specification
### Cross-system mock data generation, learned generation and version-to-version migration for banking estates
**Version 3.4 · intended as direct input to an AI coding agent (Claude Sonnet / Claude Code)**

> **Part A (§ 0–14)** specifies the synthetic data generator (milestones M0–M7).
> **Part B (§ 15–29)** extends it into source intelligence, mapping and migration
> (milestones M8–M15). Part B requires Part A to be complete.
> **Part C (§ 30–44)** adds an agentic layer that drives Parts A and B through
> their own tools (milestones M16–M24). Every agent workflow starts by modelling
> the source and target systems from uploaded DDL or JSON Schema (§ 42); agents
> also read attached spreadsheets, such as mapping sheets, and write and run
> scripts and commands like a coding assistant (§ 43). All authoring happens in an
> authoring tier on development machines; only signed, verified MDL moves to
> runtime tiers, which run no agents (§ 44). Part C requires M8–M13 to be complete;
> M14–M15 may proceed in parallel.

---

## 0. How to use this document

This is an implementation-ready specification. It is written to be executed
top-to-bottom by a coding agent, in the milestone order of § 13.

**Rules for the implementing agent**

1. Build in milestone order (M0 → M7, then M8 → M15, then M16 → M24). Each milestone has a Definition of Done
   with named tests. Do not begin a milestone until the previous one's tests pass.
2. Every file path in this document is authoritative. Create files exactly where
   specified so later milestones can find them.
3. Where this document gives a function signature, implement that signature
   exactly — later milestones call it.
4. The frontend must match the screen specs in § 10 (layout regions, component
   names, design tokens). The tokens in § 10.1 are exact hex values; do not
   substitute a UI library's defaults.
5. When something is ambiguous, prefer the simplest implementation that passes
   the stated acceptance test, and record the decision in `DECISIONS.md`.
6. Do not invent scope. Features not in this document are out of scope for v1.

**Companion artefacts referenced by this LLD** (delivered separately in the same
conversation; treat this document as authoritative if they disagree):

| Artefact | Role |
|---|---|
| `mock-data-platform-architecture.md` | High-level architecture and rationale (the "why") |
| `architecture-section-6.9-aggregate-constraints.md` | Deep design of the aggregate solver |
| `aggregate-constraint-engine.zip` | **Working, tested Python implementation of the aggregate solver — reuse it verbatim** |
| `dataforge-studio.zip` | React prototype of the UI — visual source of truth for § 10 |
| *DataForge — Intelligent Migration & Learned Generation Architecture* (Claude Doc, https://claude.ai/artifact/W8HMQPfonpSZuV49HbrSKY) | Design rationale for Part B, including the accepted findings in its *Independent review* tab |

---

## 1. Scope

### 1.1 What the system does

Users model the tables of several banking core systems, declare how those systems
and tables link to each other, describe what meaningful values look like, express
business rules, define test scenarios, then generate referentially-consistent
synthetic data across all systems and load it into target environments.

### 1.2 In scope for v1

Schema modelling with physical types; the MDL language and compiler; direct,
conditional and function-based links; system flow ordering with optional two-pass
back-references; value sets (correlated code/description tuples); rules with
conditional value domains; scenarios with weights and pairwise coverage;
aggregate constraints; seeded deterministic generation; validation and run
reports; CSV/JSON file output and JDBC + REST ingestion adapters; the Studio UI.

### 1.3 Out of scope for v1

Production data masking, mainframe integration, LLM copilot (stub the endpoint
and return canned suggestions), Kafka adapter, lifecycle state machines, fault
injection, RBAC/SSO (single trusted user), and the CP-SAT solver fallback
(forward-checking only — raise a clear error on genuinely interlocked rules).

---

## 2. Technology stack

**Decision: build v1 in Python.** The architecture document recommends the JVM
for the eventual production system, and that remains the long-term target. For
this build, Python is chosen because the aggregate-constraint solver is already
written and tested in Python (`aggregate-constraint-engine.zip`) and can be
dropped in unchanged, which removes the riskiest component from the critical
path. § 14 records the migration path.

| Layer | Choice | Version |
|---|---|---|
| Backend | Python + FastAPI | 3.11+, fastapi 0.115+ |
| ASGI server | uvicorn | 0.32+ |
| Validation | pydantic | v2 |
| ORM | SQLAlchemy 2.x + Alembic | 2.0+ |
| Database | PostgreSQL | 16 |
| MDL parser | Lark (earley/lalr) | 1.2+ |
| Data frames | polars | 1.x |
| Output format | Parquet + CSV | via polars |
| Target DB driver | psycopg[binary], plus SQLAlchemy for other targets | — |
| Testing | pytest, httpx | — |
| Frontend | React + Vite + TypeScript | React 18, Vite 5 |
| Canvas | reactflow | 11.x |
| Code editor | @monaco-editor/react + monaco-editor | latest |
| Frontend state | Zustand | 4.x |
| Package mgmt | uv or pip + requirements.txt; npm | — |

No CSS framework. Styling is plain CSS with the custom properties in § 10.1.

---

## 3. Repository layout

```
dataforge/
├── README.md
├── DECISIONS.md                    # agent records ambiguity resolutions here
├── docker-compose.yml              # postgres + api + web
├── backend/
│   ├── pyproject.toml
│   ├── alembic/
│   ├── app/
│   │   ├── main.py                 # FastAPI app factory, router registration
│   │   ├── config.py               # env settings (pydantic-settings)
│   │   ├── db.py                   # engine, session, Base
│   │   ├── models/                 # SQLAlchemy ORM models (§ 4)
│   │   │   ├── project.py  model.py  system.py  link.py
│   │   │   ├── valueset.py  scenario.py  run.py  drift.py
│   │   ├── schemas/                # pydantic request/response models (§ 9)
│   │   ├── api/                    # FastAPI routers, one file per resource
│   │   │   ├── models_api.py  tables_api.py  links_api.py  valuesets_api.py
│   │   │   ├── scenarios_api.py  runs_api.py  schema_import_api.py  copilot_api.py
│   │   ├── mdl/                    # § 5
│   │   │   ├── grammar.lark
│   │   │   ├── ast.py              # dataclasses for AST nodes
│   │   │   ├── parser.py           # text -> AST
│   │   │   ├── resolver.py         # name resolution against the model
│   │   │   ├── checker.py          # semantic checks -> Diagnostic[]
│   │   │   ├── compiler.py         # AST -> GenerationPlan IR
│   │   │   └── emitter.py          # model objects -> MDL text (round-trip)
│   │   ├── engine/                 # § 7
│   │   │   ├── plan.py             # GenerationPlan IR dataclasses
│   │   │   ├── planner.py          # flow + table topological ordering
│   │   │   ├── allocator.py        # scenario quotas + pairwise coverage
│   │   │   ├── rng.py              # deterministic per-cell RNG
│   │   │   ├── generators.py       # value generators registry
│   │   │   ├── valuesets.py        # tuple pick + binding
│   │   │   ├── rules.py            # domain narrowing / forward checking
│   │   │   ├── keyvault.py         # generated key store for link resolution
│   │   │   ├── links.py            # direct / conditional / function resolution
│   │   │   ├── aggregate/          # COPY OF aggregate-constraint-engine (§ 7.7)
│   │   │   ├── twopass.py          # deferred column patch sets
│   │   │   ├── validator.py        # post-generation assertions -> report
│   │   │   └── runner.py           # orchestrates stages, writes artefacts
│   │   ├── adapters/               # § 8
│   │   │   ├── base.py             # IngestionAdapter ABC
│   │   │   ├── file_adapter.py     # CSV / JSON / Parquet to disk
│   │   │   ├── jdbc_adapter.py     # SQLAlchemy bulk insert + patch UPDATEs
│   │   │   ├── rest_adapter.py     # HTTP POST/PATCH loader
│   │   │   └── registry.py
│   │   └── importers/              # schema import + drift (§ 7.9)
│   │       ├── sqlalchemy_importer.py  openapi_importer.py  drift.py
│   └── tests/                      # pytest, mirrors app/ structure
├── frontend/
│   ├── package.json  vite.config.ts  index.html
│   └── src/
│       ├── main.tsx  App.tsx  styles.css        # tokens in § 10.1
│       ├── api/client.ts                        # typed API client (§ 9)
│       ├── store/useStudio.ts                   # Zustand store
│       ├── components/                          # shared primitives
│       │   ├── TopBar.tsx  Tabs.tsx  StatusBar.tsx  Pill.tsx
│       │   ├── Panel.tsx  Segmented.tsx  AllocBar.tsx  ListRow.tsx
│       └── screens/
│           ├── CanvasScreen.tsx  TableNode.tsx  LinkInspector.tsx  ColumnInspector.tsx
│           ├── EditorScreen.tsx  mdlLanguage.ts
│           ├── ValuesetsScreen.tsx
│           ├── ScenariosScreen.tsx
│           ├── RunsScreen.tsx
│           └── SchemaImportScreen.tsx
└── samples/
    └── retail_bank/                # seed model used by tests and demos (§ 12.4)
        ├── core_banking.mdl  cards.mdl  payments.mdl
        ├── links.mdl  valuesets.mdl  scenarios.mdl
```

---

## 4. Data model (PostgreSQL)

All tables carry `id UUID PRIMARY KEY DEFAULT gen_random_uuid()`,
`created_at timestamptz NOT NULL DEFAULT now()`, `updated_at timestamptz`.

```sql
-- A project is one banking estate; a model_version is a snapshot of it.
CREATE TABLE project (
  id UUID PRIMARY KEY, name text NOT NULL UNIQUE, description text);

CREATE TABLE model_version (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  label text NOT NULL,                    -- 'release_2026_R3'
  content_hash text NOT NULL,             -- sha256 of compiled IR, e.g. 'a41f9c...'
  seed bigint NOT NULL DEFAULT 84921,
  as_of date,                             -- dataset clock
  is_draft boolean NOT NULL DEFAULT true,
  UNIQUE (project_id, label));

-- Systems form a DAG via system_flow. Order matters (§ 7.2).
CREATE TABLE system (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,                     -- 'CORE_BANKING'
  display_name text,                      -- 'Core banking'
  connection_profile text,                -- 'sit2-corebank'
  adapter_type text NOT NULL DEFAULT 'file',  -- file | jdbc | rest
  ui_lane int NOT NULL DEFAULT 0,         -- swimlane order on the canvas
  UNIQUE (model_version_id, name));

CREATE TABLE system_flow (                -- parent -> child edges
  id UUID PRIMARY KEY,
  parent_system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  child_system_id  UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  UNIQUE (parent_system_id, child_system_id));

CREATE TABLE table_def (
  id UUID PRIMARY KEY,
  system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  name text NOT NULL,                     -- 'CUSTOMER'
  ui_x int NOT NULL DEFAULT 0, ui_y int NOT NULL DEFAULT 0,
  UNIQUE (system_id, name));

CREATE TABLE column_def (
  id UUID PRIMARY KEY,
  table_id UUID NOT NULL REFERENCES table_def(id) ON DELETE CASCADE,
  name text NOT NULL,
  ordinal int NOT NULL,
  -- physical type
  dtype text NOT NULL,                    -- VARCHAR|CHAR|NUMBER|INTEGER|DATE|TIMESTAMP|BOOLEAN
  length int, precision int, scale int,
  nullable boolean NOT NULL DEFAULT true,
  is_pk boolean NOT NULL DEFAULT false,
  -- semantics: exactly one of generator_spec / valueset binding is used
  generator_spec jsonb,                   -- {"kind":"enum","values":[...],"weights":[...]}
  valueset_id UUID REFERENCES valueset(id) ON DELETE SET NULL,
  valueset_field text,                    -- which tuple field this column takes
  describe_text text,                     -- natural-language description (copilot)
  UNIQUE (table_id, name));

CREATE TABLE valueset (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,                     -- 'ENTITY_TYPES'
  fields text[] NOT NULL,                 -- ['code','description','category']
  source text NOT NULL DEFAULT 'inline',  -- inline | csv | reference_table
  UNIQUE (model_version_id, name));

CREATE TABLE valueset_row (
  id UUID PRIMARY KEY,
  valueset_id UUID NOT NULL REFERENCES valueset(id) ON DELETE CASCADE,
  ordinal int NOT NULL,
  values text[] NOT NULL,                 -- aligned with valueset.fields
  weight int NOT NULL DEFAULT 1);

CREATE TABLE link (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,
  source_column_id UUID NOT NULL REFERENCES column_def(id) ON DELETE CASCADE,
  target_column_id UUID NOT NULL REFERENCES column_def(id) ON DELETE CASCADE,
  kind text NOT NULL,                     -- direct | conditional | function
  condition jsonb,                        -- {"column":"CPTY_TYPE","op":"==","value":"ACCOUNT"}
  transform_fn text,                      -- registered plugin name for kind=function
  card_min int NOT NULL DEFAULT 1,
  card_max int NOT NULL DEFAULT 1,
  back_reference boolean NOT NULL DEFAULT false,
  two_pass boolean NOT NULL DEFAULT false,
  UNIQUE (model_version_id, name));

CREATE TABLE rule (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,
  table_id UUID NOT NULL REFERENCES table_def(id) ON DELETE CASCADE,
  strength text NOT NULL DEFAULT 'hard',  -- hard | soft
  probability numeric,                    -- for soft rules
  when_expr jsonb NOT NULL,               -- expression AST
  then_expr jsonb NOT NULL,
  UNIQUE (model_version_id, name));

CREATE TABLE aggregate_constraint (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,
  target_column_id UUID NOT NULL REFERENCES column_def(id),
  over_link_id UUID NOT NULL REFERENCES link(id),
  child_amount_column_id UUID NOT NULL REFERENCES column_def(id),
  opening_column_id UUID REFERENCES column_def(id),
  mode text NOT NULL DEFAULT 'allocate',  -- allocate | derive
  guard_floor_expr text,                  -- e.g. '0 - OD_LIMIT'
  row_classes jsonb NOT NULL);            -- [{case, lo, hi, quantum, absorber, mean}]

CREATE TABLE scenario (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL, weight numeric NOT NULL,
  overrides jsonb NOT NULL DEFAULT '{}',  -- {"CORE_BANKING.CUSTOMER":{"SEGMENT":"RETAIL"}}
  coverage jsonb,                         -- {"mode":"pairwise","dims":["A.B","C.D"]}
  ui_color text,
  UNIQUE (model_version_id, name));

CREATE TABLE run (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id),
  run_number serial,
  status text NOT NULL,                   -- queued|generating|ingesting|verified|failed
  seed bigint NOT NULL,
  volumes jsonb NOT NULL,                 -- {"CORE_BANKING.CUSTOMER": 5000}
  target_env text NOT NULL,
  started_at timestamptz, finished_at timestamptz,
  report jsonb,                           -- RunReport (§ 9.7)
  error text);

CREATE TABLE run_artifact (
  id UUID PRIMARY KEY,
  run_id UUID NOT NULL REFERENCES run(id) ON DELETE CASCADE,
  system_name text NOT NULL, table_name text NOT NULL,
  kind text NOT NULL,                     -- insert | patch
  path text NOT NULL, row_count bigint NOT NULL);

CREATE TABLE drift_item (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  kind text NOT NULL,                     -- added|changed|removed|breaking
  target text NOT NULL,                   -- 'CUSTOMER.PREF_LANG'
  detail text NOT NULL, suggestion text,
  breaking boolean NOT NULL DEFAULT false,
  state text NOT NULL DEFAULT 'pending',  -- pending|accepted|skipped
  scanned_at timestamptz NOT NULL DEFAULT now());
```

**Indexes:** FK columns; `run(model_version_id, run_number desc)`;
`drift_item(model_version_id, state)`.

---

## 5. MDL — language specification

### 5.1 Grammar (`app/mdl/grammar.lark`)

Implement this grammar. It is deliberately small; extend only if a § 12 test
requires it.

```lark
start: statement*
statement: system_def | flow_def | link_def | rule_def | valueset_def
         | scenario_def | dataset_def | aggregate_def | param_def

system_def: "system" NAME "{" system_body* "}"
system_body: conn_def | table_def
conn_def: "connection" "profile" STRING
table_def: "table" NAME "{" column_def* bind_def* "}"

column_def: "column" NAME ":" generator sqltype? flag*
generator: NAME ("." NAME)? ("(" arglist? ")")?
sqltype: "sqltype" NAME ("(" NUMBER ("," NUMBER)? ")")?
flag: "pk" | "not_null" | "nullable"
bind_def: "bind" "(" NAME ("," NAME)* ")" "<-" "pick" NAME "(" NAME ("," NAME)* ")"

flow_def: "flow" NAME ("->" NAME)+

link_def: "link" qname "->" qname link_opt*
link_opt: "when" expr
        | "cardinality" NAME "(" range ")"
        | "via" "fn" STRING
        | "via" "valueset" NAME "(" NAME "->" NAME ")"
        | "back_reference" ("(" "two_pass" ")")?

rule_def: "rule" NAME "on" qname "{" "when" expr ("then"|"prefer") expr probability? "}"
probability: "probability" NUMBER "%"

valueset_def: "valueset" NAME "{" "fields" "(" NAME ("," NAME)* ")"
              "values" tuple ("," tuple)* weights? "}"
tuple: "(" STRING ("," STRING)* ")"
weights: "weights" "(" NUMBER ("," NUMBER)* ")"

aggregate_def: "aggregate" NAME "on" qname "{" agg_opt* "}"
agg_opt: "target" NAME | "over" qname "via" "link" NAME
       | "define" expr | "mode" NAME | "guard" expr

scenario_def: "scenario" STRING "weight" NUMBER "%" coverage? "{" override* "}"
coverage: "coverage" "(" NAME "on" "[" qname ("," qname)* "]" ")"
override: qname "{" assign ("," assign)* "}"
assign: NAME "=" value

dataset_def: "dataset" NAME "{" ds_opt* "}"
ds_opt: "seed" NUMBER | "volume" qname "=" NUMBER | "target" "env" STRING
      | "as_of" STRING | "scenarios" NAME

param_def: "param" NAME ":" NAME "=" "input" "(" STRING ("," "default" "=" value)? ")"

expr: or_expr
or_expr: and_expr ("or" and_expr)*
and_expr: cmp ("and" cmp)*
cmp: operand (COMPARATOR operand)?
   | operand "in" "(" value ("," value)* ")"
operand: qname | value | func_call
func_call: NAME "(" (expr ("," expr)*)? ")"
COMPARATOR: "==" | "!=" | ">=" | "<=" | ">" | "<"
qname: NAME ("." NAME)*
range: NUMBER ".." NUMBER
value: STRING | NUMBER | "null"
arglist: arg ("," arg)*
arg: (NAME "=")? (value | NAME | func_call | range)

NAME: /[A-Za-z_][A-Za-z0-9_]*/
STRING: /"[^"]*"/
NUMBER: /-?\d[\d_]*(\.\d+)?/
%import common.WS
%ignore WS
%ignore /\/\/[^\n]*/
```

### 5.2 Compiler pipeline

`compile(model_version_id) -> (GenerationPlan, list[Diagnostic])`

Stages, in order, each producing diagnostics rather than raising:

1. **parse** — Lark → AST (`app/mdl/ast.py` dataclasses).
2. **resolve** — bind every `qname` to a system/table/column id. Unresolved name
   → `ERR_UNRESOLVED`.
3. **typecheck** — generator arguments match the generator's declared signature;
   comparison operand types are compatible.
4. **fit check** — every generator's possible output fits the column's physical
   type. Cases to implement: `id`/`regex` pattern length vs `VARCHAR(n)`;
   longest `enum` or valueset tuple value vs `VARCHAR(n)`; `decimal` range vs
   `NUMBER(p,s)`. → `ERR_FIT`.
5. **flow conformance** — every cross-system link must run parent→child along
   the `system_flow` DAG, unless `back_reference`. → `ERR_FLOW_DIRECTION`.
6. **link checks** — conditional links into the same target column must have
   pairwise-disjoint `when` conditions (compare literal equality sets;
   non-literal conditions produce `WARN_DISJOINT_UNPROVEN`). Cardinality
   `min <= max`, `min >= 0`.
7. **cycle check** — table-level dependency graph must be acyclic after removing
   `two_pass` edges. → `ERR_CYCLE`.
8. **rule satisfiability (shallow)** — for each table, if two hard rules with
   overlapping `when` conditions narrow one column's domain to the empty set,
   report `ERR_RULE_CONFLICT` naming both rules.
9. **aggregate feasibility** — call the solver's `check_feasible` with the
   scenario-implied target range and row-class specs (§ 7.7). → `ERR_AGG_INFEASIBLE`.
10. **emit IR** — build `GenerationPlan`; compute `content_hash` = sha256 of the
    canonical JSON of the IR.

### 5.3 Diagnostic model

```python
@dataclass
class Diagnostic:
    severity: Literal["error", "warning"]
    code: str                 # 'ERR_FIT'
    message: str              # human-readable, names the fix
    file: str | None          # 'cards.mdl'
    line: int | None; col: int | None
    length: int | None        # for editor squiggles
```

The `/api/models/{id}/compile` endpoint returns these; the Monaco editor renders
them as markers (§ 10.4).

### 5.4 Round-trip requirement

`emitter.py` must render model objects back to MDL text such that
`parse(emit(model)) == model` structurally. The UI edits objects; the editor
edits text; both must converge. **Acceptance test:** `test_mdl_roundtrip`.

---

## 6. Backend service design

FastAPI app with routers per resource. Each router is thin: validate → call a
service function → return a pydantic response. Business logic lives in
`app/engine/`, `app/mdl/`, `app/importers/` — never in routers.

**Session handling:** one SQLAlchemy session per request via dependency.
Long-running generation does **not** hold a request session; `runs_api.create_run`
persists a `run` row with status `queued`, schedules the job on a background
task, and returns immediately. The frontend polls `GET /api/runs`.

**Background execution:** FastAPI `BackgroundTasks` for v1 (single process).
Wrap the entry point so a crash marks the run `failed` with the traceback in
`run.error`. Interface must be swappable for Celery/Temporal later:

```python
# app/engine/runner.py
def execute_run(run_id: UUID) -> None: ...       # the only entry point
```

---

## 7. Generation engine

### 7.1 Plan IR (`app/engine/plan.py`)

```python
@dataclass(frozen=True)
class ColumnPlan:
    name: str; dtype: str; length: int | None
    precision: int | None; scale: int | None; nullable: bool
    generator: dict                     # {"kind": "...", ...}
    valueset: str | None; valueset_field: str | None
    is_pk: bool

@dataclass(frozen=True)
class TablePlan:
    system: str; name: str
    columns: tuple[ColumnPlan, ...]
    parent_links: tuple[str, ...]       # link names that populate this table
    volume_expr: str | None             # explicit volume, else derived

@dataclass(frozen=True)
class LinkPlan:
    name: str; kind: str
    src_system: str; src_table: str; src_column: str
    tgt_system: str; tgt_table: str; tgt_column: str
    condition: dict | None; transform_fn: str | None
    card_min: int; card_max: int
    back_reference: bool; two_pass: bool

@dataclass(frozen=True)
class GenerationPlan:
    content_hash: str; seed: int; as_of: date | None
    system_order: tuple[str, ...]                 # flow-topological
    waves: tuple[tuple[str, ...], ...]            # each wave: fully-qualified table names
    tables: dict[str, TablePlan]                  # keyed 'SYSTEM.TABLE'
    links: dict[str, LinkPlan]
    rules: tuple[dict, ...]
    aggregates: tuple[dict, ...]
    valuesets: dict[str, dict]                    # {"fields":[...], "rows":[{values,weight}]}
    scenarios: tuple[dict, ...]
    volumes: dict[str, int]
```

### 7.2 Planner (`planner.py`) — ordering is a hard requirement

```python
def system_order(flows: list[tuple[str, str]], systems: list[str]) -> list[str]
def build_waves(plan_tables, links, system_rank) -> list[list[str]]
```

Algorithm:
1. Topologically sort **systems** by `system_flow`. Cycle → `ERR_FLOW_CYCLE`.
2. Build a table dependency graph: edge `A → B` when a non-`two_pass` link has
   source in A and target in B, or when B has an FK generator referencing A.
3. Topologically sort tables, **using the system rank as the primary sort key**
   so no child-system table is ever scheduled before a parent-system table it
   depends on. Tables with equal rank and no mutual dependency share a wave.
4. `two_pass` links are excluded from the graph and recorded for § 7.8.

**Acceptance test `test_planner_respects_flow`:** with flow
`CORE → CARDS → PAYMENTS`, no PAYMENTS table may appear in a wave before every
CORE table it transitively depends on.

### 7.3 Deterministic RNG (`rng.py`)

```python
def cell_rng(seed: int, table: str, row_index: int, column: str) -> random.Random:
    h = hashlib.blake2b(f"{seed}|{table}|{row_index}|{column}".encode(), digest_size=8)
    return random.Random(int.from_bytes(h.digest(), "big"))
```

Every draw in the engine must come from `cell_rng`. No module-level `random`.
**Acceptance test `test_determinism`:** two runs with the same plan hash + seed
produce byte-identical Parquet output.

### 7.4 Scenario allocation (`allocator.py`)

```python
def allocate_scenarios(total_rows: int, scenarios: list[dict], rng) -> list[int]
def pairwise_matrix(dims: dict[str, list[str]]) -> list[dict[str, str]]
```

* Weights are normalised then apportioned with **largest remainder** so the
  quotas sum exactly to `total_rows`.
* `pairwise_matrix` implements IPOG: seed with the two largest dimensions'
  cartesian product, then for each remaining dimension extend horizontally
  (choose the value covering most uncovered pairs) and vertically (add rows for
  pairs still uncovered). Assert every value pair appears at least once.
* Boundary injection: unless a scenario sets `boundaries=false`, mark
  `ceil(0.02 * quota)` rows per table as boundary rows; § 7.5 then draws min/max
  values for eligible columns.

**Acceptance test `test_pairwise_covers_all_pairs`** over 3 dims of sizes 4,4,3.

### 7.5 Value generation (`generators.py`)

Registry `GENERATORS: dict[str, Generator]`, each:

```python
class Generator(Protocol):
    def domain(self, spec: dict, col: ColumnPlan) -> Domain: ...
    def draw(self, spec: dict, col: ColumnPlan, rng, ctx: RowContext) -> Any: ...
```

Implement for v1: `id(pattern)` (`#`=digit, `A`=letter, literals kept),
`enum(values, weights)`, `int(lo..hi)`, `decimal(lo..hi, distribution)`,
`date(range | after=expr)`, `string(n)`, `regex(pattern)` (use `exrex`-style
generation or a hand-rolled generator for the limited syntax `[]{}|.` — keep it
simple), `sequence(start, step)`, `persona.name(locale)`, `persona.email`,
`fk(qname)`, `derived(template)`, `lookup(ref)`, `describe(text)` (v1: resolve to
a canned list from the copilot stub).

`RowContext` gives access to already-generated sibling values, the parent row,
and the row's scenario overrides.

**Column generation order within a row:** discriminator columns (those named in
any rule's `when` or any conditional link's condition) first, then columns whose
domains are narrowed by rules, then the rest. Compute this order once per table
at plan time.

### 7.6 Rules (`rules.py`)

```python
def narrow_domain(col: str, base: Domain, rules: list[dict], ctx: RowContext) -> Domain
```

Forward checking only: evaluate each rule's `when` against the partially-built
row; if true, intersect the target column's domain with the rule's `then` set.
Empty intersection → raise `RuleConflict` naming the rules (this should have been
caught at compile time; treat it as a bug surfaced at runtime).
Soft rules (`prefer ... probability p`) bias the draw instead of restricting it.

### 7.7 Aggregate constraints (`engine/aggregate/`)

**Copy `aggregate_engine/` from `aggregate-constraint-engine.zip` into
`app/engine/aggregate/` unchanged**, including its tests (move them under
`backend/tests/aggregate/`). It is already tested; do not reimplement.

Public functions used by the engine: `RowSpec`, `allocate`, `check_feasible`,
`Infeasible`, `repair_running_balance`, `balance_journal`, `rollup`, `schedule`.

Integration in `runner.py`, after child rows exist as templates but before their
amount column is finalised:

```python
for agg in plan.aggregates:                    # mode == 'allocate'
    for parent_row in parent_rows:
        target_minor = to_minor(parent_row[agg.target]) - to_minor(parent_row[agg.opening])
        specs = [row_spec_for(child, agg.row_classes) for child in children_of(parent_row)]
        amounts = allocate(target_minor, specs, cell_rng(seed, table, i, "AMOUNT"))
        if agg.guard_floor is not None:
            amounts = repair_running_balance(amounts, opening_minor, floor_minor)
        assign(children, amounts)
```

`Infeasible` during a run is a bug (compile stage 9 should have caught it) —
fail the run with the solver's message verbatim, which already names the fix.

### 7.8 Links, key vault, two-pass (`keyvault.py`, `links.py`, `twopass.py`)

* As each table completes, publish `{'SYSTEM.TABLE.COLUMN': polars.Series}` of
  generated values to the key vault.
* **Direct link:** sample from the source series honouring cardinality; track
  per-parent child counts so `one_to_many(1..4)` yields 1–4 children per parent.
* **Conditional link:** first generate the discriminator column; rows matching
  the condition draw from the linked series, others fall through to their own
  generator or another disjoint conditional link.
* **Function link:** apply the registered transform to the drawn source value.
  v1 transform registry is a Python dict of pure functions in
  `app/engine/transforms.py` (ship `identity`, `strip_prefix`, `mod97_check`).
* **Two-pass:** columns targeted by a `two_pass` back-reference are left null in
  pass 1 and recorded in a deferred registry. After all waves complete, pass 2
  resolves them from the key vault and writes a **patch artifact**
  (`kind='patch'`, columns = target PK + the deferred columns). Patches never
  create rows.

### 7.9 Schema import & drift (`importers/`)

```python
def import_sqlalchemy(url: str, schema: str | None) -> ImportedSchema
def import_openapi(spec_url_or_path: str) -> ImportedSchema
def diff(existing: list[ColumnDef], imported: ImportedSchema) -> list[DriftItem]
```

Drift classification: column present in source only → `added`; in model only →
`removed`; type/length/nullability differs → `changed`; a change that
invalidates a rule, link or enum domain → `breaking` (set `breaking=true` and
name the impacted objects in `detail`). Accepting a drift item applies it to the
model; `breaking` items require an explicit accept and re-run of compile.

### 7.10 Validator & report (`validator.py`)

After generation, re-evaluate every hard rule, link cardinality, aggregate
identity and fit constraint against the produced frames and emit `RunReport`
(§ 9.7). Hard rule pass rate below 100 % fails the run.

---

## 8. Ingestion adapters

```python
# app/adapters/base.py
class IngestionAdapter(ABC):
    name: str
    supports_patch: bool

    @abstractmethod
    def validate_target(self, profile: dict) -> list[str]: ...
    @abstractmethod
    def load(self, system: str, table: str, frame: "pl.DataFrame", profile: dict) -> int: ...
    def apply_patch(self, system: str, table: str, frame: "pl.DataFrame",
                    pk_cols: list[str], profile: dict) -> int:
        raise NotImplementedError
    @abstractmethod
    def verify(self, system: str, table: str, expected_rows: int, profile: dict) -> dict: ...
```

v1 adapters: `file` (writes CSV + Parquet under `runs/{run_id}/{system}/{table}.csv`,
`supports_patch=True` by emitting a `*.patch.csv`), `jdbc` (SQLAlchemy
`insert().executemany`, patches via keyed `UPDATE`), `rest` (POST per row or
batch, `PATCH` for patches, honouring a per-system rate limit).

**Ingestion order is the declared system flow order.** A child system's load must
not start until every parent system's load has been verified. Patch artifacts are
applied only after all inserts across all systems have been verified.
If a system's adapter has `supports_patch=False` but the plan contains a two-pass
link targeting it, compile stage 5 emits `WARN_NO_PATCH_SUPPORT`.

---

## 9. REST API contract

Base path `/api`. All responses JSON. Errors:
`{"detail": "...", "code": "ERR_..."}` with appropriate 4xx/5xx.

### 9.1 Bootstrap
`GET /api/bootstrap?model_version_id=...` → everything the Studio needs on load.
```jsonc
{
  "model": {"id":"...","name":"release_2026_R3","seed":84921,"env":"SIT2",
            "hash":"a41f9c","flow":["Core banking","Cards","Payments"]},
  "systems": [{"id":"...","name":"CORE_BANKING","displayName":"Core banking","lane":0}],
  "tables":  [{"id":"...","system":"core","name":"CUSTOMER","x":30,"y":60,
               "cols":[{"id":"...","name":"CUST_ID","dtype":"VARCHAR","length":12,
                        "nullable":false,"isPk":true,"tags":"pk · id","link":"cust-card",
                        "pick":null,"generator":{"kind":"id","pattern":"CIF#########"}}]}],
  "links":   [{"id":"cust-card","label":"CUSTOMER.CUST_ID → CARD_MASTER.HOLDER_REF",
               "type":"Direct","condition":null,"cardinality":"one_to_many(1..4)",
               "source":{"node":"CUSTOMER","col":"CUST_ID"},
               "target":{"node":"CARD_MASTER","col":"HOLDER_REF"}}],
  "valuesets":[{"id":"ENTITY_TYPES","fields":["code","description","category"],
                "rows":[{"values":["BR","Branch","INTERNAL"],"weight":50}]}],
  "scenarios":[{"id":"s1","name":"Happy path retail","weight":55,"color":"var(--purple-400)"}],
  "runs":    [ /* § 9.7 RunSummary[] */ ],
  "drift":   [{"id":"d1","kind":"added","what":"CUSTOMER.PREF_LANG  varchar(5)",
               "note":"copilot suggests: enum(...)","state":"accepted","breaking":false}],
  "files":   {"cards.mdl":"system CARDS {...}"}
}
```

### 9.2 Model objects
| Method | Path | Body / notes |
|---|---|---|
| `PUT` | `/api/tables/{tableId}/columns/{name}` | `{name,dtype,length,precision,scale,nullable,isPk,generator,pick}` → column |
| `POST` | `/api/tables/{tableId}/columns` | create |
| `DELETE` | `/api/tables/{tableId}/columns/{name}` | |
| `PUT` | `/api/tables/{tableId}/position` | `{x,y}` (canvas drag persistence) |
| `POST` | `/api/links` | full link object → link |
| `PUT` | `/api/links/{id}` | update |
| `DELETE` | `/api/links/{id}` | |
| `PUT` | `/api/valuesets/{id}` | `{fields, rows}` |
| `POST` | `/api/valuesets/{id}/import-csv` | multipart file → parsed valueset |
| `PUT` | `/api/scenarios` | array of scenarios (replace) |
| `PUT` | `/api/files/{name}` | `{content}` — MDL source, triggers re-parse |

### 9.3 Compile
`POST /api/models/{id}/compile` →
```jsonc
{"ok": false, "contentHash": null,
 "diagnostics":[{"severity":"error","code":"ERR_FIT",
   "message":"CARD_MASTER.LIMIT_AMT: decimal range min > max",
   "file":"cards.mdl","line":16,"col":34,"length":22}]}
```

### 9.4 Runs
`POST /api/runs` `{"modelVersionId":"...","volumes":{"CORE_BANKING.CUSTOMER":5000},
"targetEnv":"SIT2","seed":84921,"dryRun":false}` → `{"runId":"...","runNumber":2482}`
`GET /api/runs?modelVersionId=...` → `RunSummary[]`
`GET /api/runs/{id}` → full run incl. report
`GET /api/runs/{id}/artifacts/{artifactId}` → file download

### 9.5 Schema import
`POST /api/systems/{id}/scan` → `DriftItem[]`
`PATCH /api/drift/{id}` `{"state":"accepted"|"skipped"|"pending"}`
`POST /api/drift/apply` `{"modelVersionId":"..."}` → applies all accepted items

### 9.6 Copilot (stubbed in v1)
`POST /api/copilot/suggest` `{"kind":"rule"|"generator"|"valueset","context":"..."}`
→ `{"mdl":"rule kyc_gate on ...","explanation":"..."}`
v1 returns canned suggestions keyed by `kind`; the interface must not change when
a real model is wired in.

### 9.7 RunReport shape
```jsonc
{"id":"...","runNumber":2481,"when":"09 Jul 2026, 14:12","status":"verified",
 "rows":54650,"rulePass":"100%","coverage":"96%","elapsed":"6m 41s",
 "systems":[{"name":"Core banking","detail":"16,400 rows · JDBC · 1m 12s","ok":true}],
 "rules":[{"name":"kyc_gate","result":"12050/12050","ok":true,"soft":false}],
 "coverageMatrix":{"dims":["SEGMENT","ACC_TYPE"],
   "rows":["RETAIL","PREMIUM","NRI","CORP"],"cols":["SAV","CUR","OD","FD"],
   "counts":[[8210,3100,900,2400],[...]],"excluded":[[false,false,false,false],[...]]},
 "crossChecks":[{"name":"card holders exist in core banking","passed":500,"total":500}]}
```

---

## 10. Frontend specification

The React prototype in `dataforge-studio.zip` is the **visual source of truth**.
This section restates it precisely so it can be rebuilt without the archive.

### 10.1 Design tokens — exact values (`styles.css`)

```css
:root{
  --bg:#fafaf8; --surface:#ffffff; --surface-2:#f4f4f1;
  --border:#e4e3de; --border-strong:#cfcec8;
  --text:#1c1c1a; --text-2:#5f5e5a; --text-3:#93928c;
  --purple-50:#eeedfe; --purple-400:#7f77dd; --purple-600:#534ab7; --purple-800:#3c3489;
  --teal-50:#e1f5ee; --teal-200:#5dcaa5; --teal-400:#1d9e75; --teal-600:#0f6e56; --teal-800:#085041;
  --coral-50:#faece7; --coral-200:#f0997b; --coral-400:#d85a30; --coral-600:#993c1d; --coral-800:#712b13;
  --amber-50:#faeeda; --amber-600:#854f0b;
  --red-50:#fcebeb; --red-600:#a32d2d; --red-800:#791f1f;
  --green-50:#eaf3de; --green-800:#27500a;
  --mono:"SFMono-Regular",ui-monospace,Menlo,Consolas,monospace;
  --sans:"Inter",-apple-system,"Segoe UI",Roboto,sans-serif;
  --radius:8px;
}
```

System colour assignment: core banking = purple, cards = teal, payments = coral;
further systems cycle through the same families.

### 10.2 App chrome (all screens)

* **Shell**: max-width 1180px, centred, `--surface` card with 1px `--border`,
  radius 14px, `overflow:hidden`.
* **TopBar** (height ~52px, bottom border): 30px rounded logo tile
  (`--purple-50` bg, `--purple-800` glyph `{}`) · title "DataForge studio" 14px/600
  · subtitle `{modelName} · seed {seed} · {env}` 11.5px `--text-3` mono ·
  right group: validity pill, `Validate` button, primary `Generate {volume}`
  button (dark `--text` bg, white text). **The Generate button is disabled while
  compile diagnostics contain any error**, with tooltip "Fix the compile error in
  the MDL editor first".
* **Tabs**: `Linkage canvas · MDL editor · Valuesets · Scenarios · Runs · Schema
  import`. Active tab: 600 weight, 2px bottom border `--text`. Right-aligned
  flow note in mono 11.5px: `flow: Core banking → Cards → Payments`.
* **StatusBar** (top border, mono 11.5px `--text-3`): `{n} systems · {n} tables ·
  {n} links · {n} valuesets · {n} rules` | `models/{label} · #{hash}` | right:
  API base or `mock adapter`.
* **Pills**: `.ok` teal-50/teal-800, `.warn` amber-50/amber-600,
  `.err` red-50/red-800; 11px, radius 999px, padding 3px 10px.

### 10.3 Screen — Linkage canvas

Layout: canvas region 420px tall, then a two-column panel row (1.15fr / 1fr)
separated by a 1px border.

**Canvas.** Absolutely-positioned swimlane backdrop (one equal-width lane per
system, dashed `--border-strong` separators, lane badge pill top-left in the
system's 50/600 colours), with React Flow rendered transparently on top
(`Background` gap 22 colour `--border`, `Controls` without the interactive lock).
Lane order = declared system flow order, left to right.

**TableNode** (custom node, width 224px, radius 9px, 1px `--border-strong`,
subtle shadow):
* header bar: table name 12px/600 on the system's 50-tint, 600-tint text
* one row per column: `name` (left) and computed **type label** (right, mono
  11.5px `--text-3`) where the label is `VARCHAR(12)`, `NUMBER(18,2)`, `DATE`…
* React Flow `Handle` target on the left edge (7px, `--border-strong`, id
  `t:{col}`) and source on the right edge (7px, `--purple-400`, id `s:{col}`)
* clicking a column selects it → opens the **Column** inspector; selected column
  row gets `--purple-50` background
* final row `+ add column`, centred, `--text-3`

**Edges** are derived from the link list, styled by kind: Direct = solid
`--purple-400`; Conditional = dashed `6 4` `--coral-400`; Function/back-reference
= dotted `2 4` `--border-strong`. Selected edge stroke 2.4 vs 1.7. Labels are
mono 10.5px on a `--surface` rounded chip (radius 8, padding 7×3): cardinality
range for direct (`1..4`), `when CPTY_TYPE = "ACCOUNT"` for conditional,
`two-pass` for back-references. Arrowheads `ArrowClosed` 16px `#888780`.

**Interactions:** drag nodes (persist via `PUT /position`, debounce 500 ms);
drag from a source handle to a target handle creates a link (`POST /api/links`,
default kind Direct, cardinality `one_to_many(1..1)`) and selects it; click an
edge to open the Link inspector.

**Left panel — inspector** with a Link/Column segmented toggle:
* *Link mode*: link label in mono; segmented `Direct | Conditional | Function`;
  when Conditional → row `when [column ▾] [op ▾] [value input]`; when Function →
  `via fn [select]` + hint "sandboxed plugin"; always `cardinality [text input]`;
  helper text about drag-to-link.
* *Column mode*: `name` text input (upper-cases, strips non `[A-Z0-9_]`);
  `data type` select (VARCHAR, CHAR, NUMBER, INTEGER, DATE, TIMESTAMP, BOOLEAN);
  conditional `length` input for VARCHAR/CHAR, `precision`+`scale` for NUMBER;
  `nullable` checkbox; **`value source` select** (generator (default) | each
  valueset) and, when a valueset is chosen, a `field` select; a live binding note
  — when ≥2 columns of the same table bind the same valueset, render
  `one draw per row fills: ENTITY_CODE (code) + ENTITY_DESC (description)`;
  a live fit warning in `--red-600` when the longest bound value exceeds the
  declared length; footer `sqltype varchar(12) not_null — fit check runs at
  compile time` in mono `--text-3`.

**Right panel — scenario allocation:** one row per scenario with
`name` / `weight% · rowcount`, a 6px track (`--surface-2`) and fill in the
scenario colour; footer `pairwise coverage 96% · est. N accounts · N txns`.

### 10.4 Screen — MDL editor

Two columns: 172px file tree, then editor.
* **File tree** on `--bg`, header `models/{label}` mono 11px `--text-3`, one row
  per `.mdl` file; active file `--surface` bg, 600 weight, 2px left border
  `--text`; trailing `plugins/` row.
* **Monaco**, height 340px, language id `mdl` registered with a Monarch tokenizer
  (keywords → `--purple-600`, generators/types → `--teal-600`, strings →
  `--coral-600`, numbers → `--text`, comments → `--text-3`) and theme `mdl-light`
  (`editor.background:#ffffff`, `lineHighlightBackground:#f4f4f1`). Options:
  fontSize 13, mono family, `minimap:false`, `scrollBeyondLastLine:false`,
  padding top 10.
* **Diagnostics**: on change (debounced 400 ms) `PUT /api/files/{name}` then
  `POST /compile`; render returned diagnostics via
  `monaco.editor.setModelMarkers`. The error count drives the TopBar pill and the
  Generate button's disabled state.
* **Copilot card** below the editor: 1px `--purple-400` border, `--purple-50` bg,
  radius 10; header `✦ Copilot · from your note "…"` 11.5px/600 `--purple-800`;
  a white `pre` block with the proposed MDL; actions `Insert rule` (applies the
  edit to the open file and re-compiles), `Edit`, `Dismiss`.

### 10.5 Screen — Valuesets

Two columns: 172px list of valuesets (plus `+ new valueset`), then the editor
panel.
* Header row: valueset name (h3), a pill `{n} tuples · total weight {w}`, right
  group `Import CSV` (real file input → `POST /import-csv`) and
  `Sync from reference table`.
* **Tuple grid**: CSS grid `repeat(nFields, minmax(120px,1fr)) 84px 40px`; header
  row of field names in mono 11px `--text-3`; each row = one text input per field
  (mono) + weight input + `×` remove button. Footer `+ add tuple`.
* **Bindings** section: one `ListRow` per table binding this valueset, reading
  `one draw per row fills ENTITY_CODE (code) + ENTITY_DESC (description)`.
* **Fit check** block: red lines listing any bound column whose declared length
  is shorter than the longest value in its field; otherwise a teal
  `✓ fit check: all bound columns hold the longest values`.

### 10.6 Screen — Scenarios

Two panels. Left: one range slider per scenario (0–100, accent `--purple-600`)
with name and `{weight}%`; a `total {n}%` pill (`ok` at 100, else `warn`) and a
`Normalize to 100%` button that apportions by largest remainder. Right: live
allocation preview identical in style to § 10.3's right panel, plus downstream
estimates and a note that coverage scenarios expand to a pairwise covering array.

### 10.7 Screen — Runs

* **Run bar**: `Run [select ▾]` listing `#{n} · {when} · {status}`, a status pill,
  right group `Download report`, `Regenerate`.
* **Metric grid**: 4 cards (`--surface-2`, radius 9) — Rows generated, Hard rule
  pass (value in `--teal-800`), Pairwise coverage, Elapsed. Value 21px/600.
* **Left panel — Ingestion by system · flow order**: one ListRow per system in
  declared flow order with a tick and `16,400 rows · JDBC · 1m 12s`; the two-pass
  phase appears as a final row `Pass-2 patches → Core banking`. Footer line with
  cross-system spot-check results.
* **Right panel — Rule assertions** (tick teal for hard, `~` amber for soft, right
  aligned counts) then **Coverage heat map**: CSS grid `70px repeat(nCols,1fr)`,
  17px cells; colour ramp by row count `--teal-50 → --teal-200 → --teal-400`;
  rule-excluded combinations render as `--surface-2` with a dashed
  `--border-strong` border. Legend: `dashed = excluded by rules · darker = more rows`.
* While `status==='running'`, poll `GET /api/runs` every 1.5 s; show `…` in place
  of ticks and `—` for metrics.

### 10.8 Screen — Schema import

* Bar: system select, scan summary text, right group `{n} pending review` pill,
  `Re-scan`, primary `Apply {n} accepted`.
* **Drift list** (1px border, radius 10, rows separated by 1px `--border`): each
  row = a fixed-width 68px kind chip (`added` green-50/green-800, `changed`
  amber-50/amber-600, `removed` and `breaking` red-50/red-800), a body with the
  target in mono 12px and a note in 11.5px `--text-3` (`--red-600` when
  breaking), and right-aligned actions. Breaking rows get a `--red-50` row
  background while pending, and their accept button reads `Review + accept`.
  Accepted/skipped rows show a pill and an `Undo` button.
* Footer note: accepted changes are committed to a branch for review before merge.

### 10.9 State management

Single Zustand store `useStudio` holding `model, systems, tables, links,
valuesets, scenarios, runs, drift, files, diagnostics, selection`. All mutations
call the API and update the store optimistically, rolling back on error. The
store must expose `errorCount` derived from `diagnostics` — the TopBar and the
Generate button read only that.

---

## 11. Non-functional requirements

**Determinism.** `(content_hash, seed, volumes)` fully determines the output.
Enforced by § 7.3 and `test_determinism`.

**Performance (v1 target).** 1 million total rows generated and validated in
under 3 minutes on 4 cores. Generate per table into polars frames; parallelise
across tables within a wave using a process pool sized to `cpu_count()`.

**Safety.** Environment profiles carry an `allow_write: bool`; a run against a
profile without it is rejected. Volume cap per environment (`max_rows`). `dryRun`
produces plan + report with no adapter writes. All target credentials come from
env vars, never the database.

**Observability.** Structured JSON logs with `run_id` on every line; a
`GET /api/runs/{id}/log` endpoint streaming the run log.

**Data safety.** The platform generates synthetic data only. There is no code
path that reads rows from a target system except metadata (`importers/`) and
verification counts.

---

## 12. Test plan

### 12.1 Layers
* **Unit** — `mdl/`, `engine/`, `adapters/` in isolation.
* **Integration** — FastAPI + Postgres via `httpx.AsyncClient` and a
  testcontainer/`pytest-postgresql`.
* **Golden** — the sample model in `samples/retail_bank/` generated at a fixed
  seed; a checked-in fingerprint of the output must not change.
* **Frontend** — Vitest + Testing Library for the inspector logic
  (fit-check warning, binding note, weight normalisation).

### 12.2 Named acceptance tests (referenced by the milestones)

| Test | Asserts |
|---|---|
| `test_mdl_parse_sample` | all six sample `.mdl` files parse |
| `test_mdl_roundtrip` | `parse(emit(model))` equals `model` structurally |
| `test_fit_check_flags_short_varchar` | `id("CIF#########")` into `VARCHAR(8)` → `ERR_FIT` |
| `test_flow_conformance_rejects_reverse_link` | PAYMENTS→CORE link without `back_reference` → `ERR_FLOW_DIRECTION` |
| `test_conditional_links_must_be_disjoint` | two `when` clauses on the same target with overlapping literals → error |
| `test_planner_respects_flow` | § 7.2 |
| `test_pairwise_covers_all_pairs` | § 7.4 |
| `test_scenario_quotas_sum_exactly` | largest-remainder apportionment |
| `test_determinism` | identical output for identical inputs; different for a different seed |
| `test_valueset_pick_is_correlated` | for every generated row, `(ENTITY_CODE, ENTITY_DESC)` is a tuple that exists in the valueset |
| `test_cardinality_respected` | every customer has 1–4 cards |
| `test_conditional_link_only_binds_matching_rows` | `CPTY_VALUE ∈ ACC_NO` exactly where `CPTY_TYPE='ACCOUNT'` |
| `test_two_pass_patch_produced` | pass-1 column null; patch artifact contains PK + resolved value |
| `test_rule_narrows_domain` | `SEGMENT='CORP'` ⇒ `ACC_TYPE ∈ {CURRENT,OD}` for all rows |
| `test_aggregate_balances_exactly` | Σ child amounts == parent target, to the minor unit |
| `test_running_balance_never_below_floor` | § 7.7 guard |
| `test_ingestion_order_follows_flow` | recorded adapter call order matches system flow |
| `test_validator_fails_on_broken_rule` | injected bad row ⇒ run status `failed` |
| `test_api_bootstrap_shape` | response matches § 9.1 keys |
| `test_run_end_to_end` | POST run → poll → status `verified`, artifacts exist |

### 12.3 Definition of Done (whole project)
`pytest` green; `npm run build` clean; `docker compose up` yields a working
Studio at `localhost:5173` against the API at `localhost:8000`; the golden
sample generates and ingests to the `file` adapter with a verified run report.

### 12.4 Sample model (`samples/retail_bank/`)
Three systems — `CORE_BANKING` (CUSTOMER, ACCOUNT), `CARDS` (CARD_MASTER),
`PAYMENTS` (TXN) — with: `flow CORE_BANKING -> CARDS -> PAYMENTS`; a direct link
CUSTOMER.CUST_ID→CARD_MASTER.HOLDER_REF `one_to_many(1..4)`; a conditional link
ACCOUNT.ACC_NO→TXN.CPTY_VALUE `when CPTY_TYPE == "ACCOUNT"` `one_to_many(0..50)`;
a two-pass back-reference CARD_MASTER.CARD_STATUS→CUSTOMER.LATEST_CARD_STATUS;
valueset `ENTITY_TYPES` bound to CUSTOMER.ENTITY_CODE/ENTITY_DESC; rules
`kyc_gate`, `corporate_products`, `dormant_no_txn`; an aggregate constraint
`ACCOUNT.BALANCE = OPENING_BAL + sum(TXN.AMOUNT)` with SALARY/ATM/NEFT/POS row
classes; five scenarios summing to 100 % including one pairwise coverage
scenario. This model is the fixture for most acceptance tests.

---

## 13. Build plan

Each milestone is independently demoable. Do not proceed until its tests pass.

### M0 — Skeleton (0.5 day)
Repo layout per § 3; `docker-compose.yml` (postgres 16, api, web); FastAPI app
with `/health`; Alembic initialised; Vite React TS app with tokens from § 10.1,
app shell (TopBar, Tabs, StatusBar) and six empty tab bodies.
**DoD:** `docker compose up` serves both; `/health` returns 200.

### M1 — Model & persistence
All § 4 tables + Alembic migration; ORM models; pydantic schemas; CRUD routers
for tables/columns/links/valuesets/scenarios; `GET /api/bootstrap`; seed script
loading `samples/retail_bank` **as objects** (not yet MDL).
**DoD:** `test_api_bootstrap_shape`; bootstrap returns the sample model.

### M2 — MDL compiler
Grammar, AST, parser, resolver, checker (all ten stages of § 5.2 except 9),
emitter, `POST /compile`.
**DoD:** `test_mdl_parse_sample`, `test_mdl_roundtrip`,
`test_fit_check_flags_short_varchar`, `test_flow_conformance_rejects_reverse_link`,
`test_conditional_links_must_be_disjoint`.

### M3 — Generation engine core
Plan IR, planner, RNG, generators, valuesets, key vault, direct + conditional +
function links, cardinality, file adapter, run orchestration, artifacts.
**DoD:** `test_planner_respects_flow`, `test_determinism`,
`test_valueset_pick_is_correlated`, `test_cardinality_respected`,
`test_conditional_link_only_binds_matching_rows`, `test_run_end_to_end`.

### M4 — Rules, scenarios, aggregates, two-pass
Rule narrowing; scenario quotas + IPOG pairwise + boundary injection; drop in the
aggregate engine and wire § 7.7; two-pass deferred columns and patch artifacts;
validator and `RunReport`.
**DoD:** `test_rule_narrows_domain`, `test_scenario_quotas_sum_exactly`,
`test_pairwise_covers_all_pairs`, `test_aggregate_balances_exactly`,
`test_running_balance_never_below_floor`, `test_two_pass_patch_produced`,
`test_validator_fails_on_broken_rule`.

### M5 — Studio: canvas, inspectors, valuesets
React Flow canvas per § 10.3 with drag-to-link and position persistence; link and
column inspectors including physical types and valueset binding; valuesets screen
per § 10.5 with CSV import and fit check; Zustand store.
**DoD:** manual walkthrough matches § 10.3/§ 10.5; Vitest covers fit-check and
binding-note logic.

### M6 — Studio: editor, scenarios, runs
Monaco with the `mdl` language + theme + live markers from `/compile`; copilot
card wired to the stub; scenarios screen with sliders and normalisation; runs
screen with polling, metrics, flow-ordered ingestion list, rule assertions and
coverage heat map.
**DoD:** editing MDL surfaces a real squiggle; Generate is gated by error count;
a run completes and renders a full report.

### M7 — Ingestion & schema import
JDBC and REST adapters with `verify()` and `apply_patch()`; flow-ordered
ingestion orchestration with checkpointing; schema import + drift detection +
apply; schema import screen per § 10.8.
**DoD:** `test_ingestion_order_follows_flow`; a JDBC round-trip into a scratch
Postgres schema verifies; drift on a changed column is detected and applied.

---

## 14. Decisions, risks, migration

**D1 — Python over JVM for v1.** Reuses the tested aggregate solver and shortens
the path to a working system. Migration path: the MDL grammar (Lark → ANTLR4),
the Plan IR (already language-neutral JSON) and the adapter SPI are the only
contracts that must be preserved; the engine is a pure function of
(plan, seed, volumes) and can be ported table-generator by table-generator.

**D2 — Forward checking only, no CP-SAT in v1.** Interlocked rules are rare and
detectable; the compiler reports them rather than solving them. If a real model
needs it, add OR-Tools behind `rules.narrow_domain` without changing callers.

**D3 — Background tasks, not a workflow engine.** Keeps v1 single-process. The
single entry point `execute_run(run_id)` is the seam for Temporal/Celery later.

**D4 — Copilot stubbed.** The endpoint shape is fixed now so the UI never
changes when a model is wired in.

**R1 — Grammar churn.** The DSL will evolve. Mitigate by keeping the Plan IR
stable and versioned (`ir_version` field) so the engine is insulated.

**R2 — Cardinality explosion.** `one_to_many(0..50)` over 5,000 accounts is up to
250,000 transactions. Enforce the per-environment `max_rows` cap at plan time and
show the estimate in the UI before the run starts.

**R3 — Fit checks vs generator expressiveness.** Regex generation can be hard to
bound. If a generator cannot prove its maximum length, emit
`WARN_FIT_UNPROVEN` rather than a false error.

---
---

# PART B — Source intelligence, mapping and migration (DataForge 2.0)

## 15. Part B scope

### 15.1 Goal

Connect to an existing system version, learn its structure and meaning into a
knowledge graph of claims, map it through a shared business model to another
version whose structure may be completely different, then migrate the data with
proof: every row accounted for, every control total exact, and every mapping
approved by a named person and tested on synthetic data before real data moves.
The same learned model also drives synthetic data generation for either version.

### 15.2 In scope

Traceability to the architecture doc's review findings is given in brackets.

- Evidence Graph as a Postgres-backed knowledge graph of claims, evidence and activities.
- Profiling, semantic typing, constraint discovery, application-SQL mining, entity clustering.
- A data-quality assessment report produced from profiles (finding 2).
- Concepts, realisations (`from` / `into`) and migrations in MDL, with blocking decisions.
- The 14 structural change patterns, including representation changes and the
  migrate-or-recompute decision for derived values (finding 4).
- The mapping discovery pipeline: retrieval, LLM rerank, global solve, transforms,
  examples on demand, confidence bands, impact-ordered review.
- A golden mapping set and evaluation harness; pinned model versions (finding 5).
- Two executors (reference interpreter and production executor), key crosswalk,
  row-conservation ledger, quarantine, partitioned and restartable loads.
- Cleansing rules, reject categories with owners, reject tracking (finding 2).
- Cutover-state inventory for in-flight business items (finding 3).
- Rehearsals (synthetic, masked-copy, dress), rehearsal-to-rehearsal diff with
  attribution (finding 9), sizing estimates (finding 11).
- Point-of-no-return recording and post-PONR policy (finding 10; reverse sync itself is not built).
- Behaviour-equivalence *support only*: output comparator, risk-segmented test pack,
  target-shaped synthetic data, behaviour sign-off as a gate (finding 1).
- Governance: role matrix, separation of duties, four-eyes production runs (finding 8).
- Control plane / data plane split as two deployables.
- Learned synthetic generation with a privacy gate.

### 15.3 Out of scope for Part B

- **Running v2 business processes** (end-of-day, interest, statements). Owned by the
  v2 application or UAT team; DataForge compares their outputs only (§ 23.8).
- **Reverse sync** after the point of no return (policy is recorded, not executed).
- **Pending decisions** from the review, built only as extension points (§ 29):
  downstream consumer analysis (finding 6), history scope tiers (finding 7),
  concept versioning (finding 12).
- A graph database, RDF/OWL reasoning, Ontop/virtual knowledge graphs, FIBO import,
  graph neural networks, and row-level deep generative models over raw customer data.

---

## 16. Additional technology

All Part A choices stand. Part B adds:

| Need | Choice | Notes |
|---|---|---|
| Sketches | `datasketch` | MinHash (containment), HyperLogLog (distinct counts) |
| SQL parsing and lineage | `sqlglot` | Parse views, procedures and application SQL; extract joins |
| Graph algorithms | `networkx` | Arborescence, shortest paths; in-memory per migration project |
| Assignment | `scipy.optimize.linear_sum_assignment` | Global attribute assignment |
| Calibration | `scikit-learn` `IsotonicRegression` | Per claim predicate, once enough labels exist |
| Embeddings | `pgvector` + `sentence-transformers` | Default model `all-MiniLM-L6-v2` (384 dims), pinned |
| LLM | Provider interface (`app/llm/provider.py`) | Any approved provider; model ID pinned in config and recorded on every activity |
| Worker queue | Postgres `job` table with `SELECT … FOR UPDATE SKIP LOCKED` | No broker needed for v2 |

No new database engine is introduced.

---

## 17. Repository additions

```
backend/app/
├── worker/                       # DATA PLANE deployable (separate process/image)
│   ├── main.py                   # polls `job`, runs only approved spec hashes
│   └── handlers.py               # profile | rehearse | migrate | compare | learn
├── kg/                           # Evidence Graph (knowledge graph of claims)
│   ├── models.py                 # ORM for kg_node, kg_claim, kg_evidence, kg_activity
│   ├── store.py                  # claim CRUD, supersede, bitemporal queries
│   ├── calibrate.py              # bands → isotonic per predicate
│   ├── structure.py              # global structure solve (arborescence)
│   ├── paths.py                  # in-memory graph load, k-shortest join paths
│   └── prov_export.py            # PROV-O JSON-LD export of approvals
├── intel/                        # source intelligence (runs in data plane)
│   ├── profiler.py  sketches.py  semtypes.py  constraints.py
│   ├── codemine.py               # sqlglot over views/procs/app SQL → JOINS_ON claims
│   ├── entities.py               # table clustering into entities
│   └── dq_report.py              # data-quality assessment from profiles
├── llm/                          # control plane only
│   ├── provider.py  stub_provider.py  api_provider.py
│   ├── grounding.py              # k-hop subgraph → compact prompt context
│   ├── masking.py                # format-preserving masking of samples
│   ├── contracts.py              # JSON schemas for every LLM output
│   ├── validate.py               # deterministic claim validator + one repair round
│   ├── prompts/                  # versioned templates: relationships, rerank, transform
│   └── golden.py                 # golden set evaluation harness
├── mapping/
│   ├── concepts.py               # compiled concept model
│   ├── patterns.py               # 14-pattern classifier
│   ├── retrieve.py  rerank.py  assign.py  impact.py
│   ├── pbe.py                    # transforms from examples
│   └── transforms/               # bank function library (see § 21.5)
├── migrate/
│   ├── plan.py                   # MappingPlan IR
│   ├── compose.py                # realise-from ∘ realise-into → MappingPlan
│   ├── interpreter.py            # reference interpreter (row by row)
│   ├── executor.py               # production executor (polars, partitioned)
│   ├── crosswalk.py  ledger.py  quarantine.py  cleanse.py
│   ├── cutover.py                # in-flight state inventory and rules
│   ├── delta.py                  # watermark-based delta catch-up
│   ├── sizing.py                 # throughput estimate
│   └── rehearsal.py              # rehearsal runs and run-to-run diff
├── verify/
│   ├── spec_checks.py  differential.py  metamorphic.py  mutation.py
│   ├── reconcile.py              # counts, control totals (aggregate engine), round trip
│   ├── comparator.py             # behaviour-output comparator (finding 1)
│   └── testpack.py               # risk-segmented test pack export
├── learn/
│   ├── degrees.py  marginals.py  constraints_learned.py
│   ├── privacy.py                # k-threshold, distance-to-closest-record, membership test
│   ├── fidelity.py               # fidelity report (§ 24.5)
│   ├── sequences.py              # transaction sequence models (§ 24.6)
│   ├── edge_patterns.py          # rare-but-valid pattern mining (§ 24.7)
│   ├── scale.py                  # volume scaling (§ 24.8)
│   └── relearn.py                # versioned models and drift per release (§ 24.9)
└── governance/
    ├── roles.py                  # role matrix and checks
    ├── signoff.py                # sign-off records and gates
    └── audit.py                  # OpenLineage emission, audit trail queries
samples/legacy_v1_to_core_v2/     # Part B fixture, see § 27.4
```

Frontend additions under `src/screens/`: `SourcesScreen`, `EvidenceScreen`,
`ConceptsScreen`, `MappingReviewScreen`, `MigrationScreen`, `ReconcileScreen`,
`SignoffScreen` (specified in § 26).

---

## 18. Data model additions (PostgreSQL)

Conventions from § 4 apply (UUID keys, `created_at`, `updated_at`).
Enable `CREATE EXTENSION IF NOT EXISTS vector;`.

### 18.1 Versions and the Evidence Graph

```sql
CREATE TABLE system_version (
  id UUID PRIMARY KEY,
  system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  label text NOT NULL,                       -- 'LEGACY_V1', 'CORE_V2'
  role text NOT NULL,                        -- source | target
  connection_profile text NOT NULL,
  code_location text,                        -- path/URL of application code, optional
  frozen_at timestamptz,                     -- snapshot is immutable once set
  UNIQUE (system_id, label));

CREATE TABLE kg_activity (                   -- PROV-O: Activity + Agent
  id UUID PRIMARY KEY,
  type text NOT NULL,                        -- profiling | constraint_discovery | code_mining |
                                             -- llm_proposal | llm_rerank | review | calibration
  agent_kind text NOT NULL,                  -- algorithm | model | human
  agent_id text NOT NULL,                    -- 'profiler', 'claude-…', user id
  agent_version text NOT NULL,               -- algorithm version or pinned model id
  started_at timestamptz NOT NULL, ended_at timestamptz,
  inputs jsonb NOT NULL DEFAULT '{}');

CREATE TABLE kg_node (
  id UUID PRIMARY KEY,
  kind text NOT NULL,                        -- system_version | container | field | concept |
                                             -- concept_attr | value_domain | query | agent
  system_version_id UUID REFERENCES system_version(id) ON DELETE CASCADE,
  qualified_name text NOT NULL,              -- 'LEGACY_V1.CUST_MASTER.CUST_NO'
  attrs jsonb NOT NULL DEFAULT '{}',         -- dtype, length, nullable, json_path, eav_key …
  valid_from timestamptz NOT NULL,           -- when it held in the source
  valid_to timestamptz,
  recorded_at timestamptz NOT NULL DEFAULT now(),   -- when DataForge learned it
  UNIQUE (system_version_id, qualified_name, valid_from));

CREATE TABLE kg_claim (
  id UUID PRIMARY KEY,
  predicate text NOT NULL,                   -- see § 18.2
  subject_id UUID NOT NULL REFERENCES kg_node(id) ON DELETE CASCADE,
  object_id UUID REFERENCES kg_node(id) ON DELETE CASCADE,   -- null for unary claims (UNIQUE)
  params jsonb NOT NULL DEFAULT '{}',        -- field sets, role/discriminator, transform, pattern
  status text NOT NULL DEFAULT 'proposed',   -- proposed | accepted | rejected | superseded
  confidence numeric,                        -- calibrated 0..1, null until scored
  band text,                                 -- high | medium | low (shown in UI)
  calibrator_version text,
  supersedes_id UUID REFERENCES kg_claim(id),
  valid_from timestamptz NOT NULL, valid_to timestamptz,
  recorded_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX ON kg_claim (predicate, status);
CREATE INDEX ON kg_claim (subject_id); CREATE INDEX ON kg_claim (object_id);

CREATE TABLE kg_evidence (                   -- PROV-O qualified influence
  id UUID PRIMARY KEY,
  claim_id UUID NOT NULL REFERENCES kg_claim(id) ON DELETE CASCADE,
  kind text NOT NULL,                        -- minhash | ind | ucc | fd | semtype | embedding |
                                             -- sql_parse | llm | probe | example | human
  score numeric,                             -- raw signal strength
  payload jsonb NOT NULL DEFAULT '{}',       -- e.g. {"containment":0.994,"checked_rows":120000}
  activity_id UUID NOT NULL REFERENCES kg_activity(id));

CREATE TABLE column_profile (                -- aggregates only; produced in the data plane
  node_id UUID PRIMARY KEY REFERENCES kg_node(id) ON DELETE CASCADE,
  row_count bigint, null_frac numeric, distinct_est bigint,
  min_text text, max_text text,              -- masked if the semantic type is sensitive
  length_hist jsonb, format_hist jsonb,      -- format = char-class shape, e.g. 'AAAA0AAAAAA'
  top_values jsonb,                          -- only values with count >= k_threshold, masked
  numeric_hist jsonb,
  minhash bytea, hll bytea,
  activity_id UUID NOT NULL REFERENCES kg_activity(id));

CREATE TABLE node_embedding (
  node_id UUID REFERENCES kg_node(id) ON DELETE CASCADE,
  model text NOT NULL,
  vec vector(384) NOT NULL,
  PRIMARY KEY (node_id, model));
```

### 18.2 Claim predicates (closed list)

| Predicate | Subject → object | `params` |
|---|---|---|
| `CONTAINS` | container → field | `{ordinal}` |
| `HAS_SEMANTIC_TYPE` | field → value_domain | `{validator, match_rate}` |
| `UNIQUE` | container → (none) | `{fields:[…]}` |
| `INCLUDED_IN` | field → field | `{containment, fields_src:[…], fields_tgt:[…]}` (FK candidate) |
| `DETERMINES` | field → field | `{lhs:[…], error_rate}` (functional dependency) |
| `SIMILAR_TO` | field → field | `{name_sim, content_sim}` |
| `JOINS_ON` | field → field | `{query_node_id, join_type}` |
| `MEMBER_OF_ENTITY` | container → concept | `{role}` |
| `REALISES` | field/container → concept_attr/concept | `{direction: from|into, expr, pattern, role, discriminator}` |
| `MAPS_TO` | field → field | `{composed_from:[claim ids], expr, pattern}` (derived, never edited) |
| `DERIVED_BY` | field → field | `{smo: rename|split|merge|partition|decompose|join}` |
| `ALIGNED_TO` | concept → (external IRI in params) | `{scheme: iso20022|bian|fibo, iri}` |

Any predicate outside this list is a validation error.

### 18.3 Migration, decisions and governance

```sql
CREATE TABLE migration (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id),
  name text NOT NULL,
  source_version_id UUID NOT NULL REFERENCES system_version(id),
  target_version_id UUID NOT NULL REFERENCES system_version(id),
  spec_hash text,                            -- hash of the compiled MappingPlan; set on approval
  status text NOT NULL DEFAULT 'draft',      -- draft | specified | proven | ready | cutover | live
  ponr_at timestamptz,                       -- point of no return, once declared
  post_ponr_policy text,                     -- forward_fix | reverse_sync (recorded only)
  UNIQUE (model_version_id, name));

CREATE TABLE decision (                      -- every open decision blocks compilation
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  kind text NOT NULL,                        -- unmapped_source | missing_target | derived_value |
                                             -- lossy_expression | cutover_state | history_scope
  subject text NOT NULL,                     -- 'LEGACY_V1.CUST_MASTER.FAX_NO'
  options text[] NOT NULL,                   -- e.g. {drop,archive,extension}
  choice text,                               -- null = open
  rationale text, decided_by text, decided_at timestamptz);

CREATE TABLE reject_category (
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  code text NOT NULL, description text NOT NULL, owner text NOT NULL,
  UNIQUE (migration_id, code));

CREATE TABLE cleanse_rule (                  -- separate from mapping rules (finding 2)
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  name text NOT NULL, target_field text NOT NULL,
  condition text NOT NULL,                   -- MDL expression
  action text NOT NULL,                      -- fix | reject
  fix_expr text,
  reject_code text,                          -- must exist in reject_category for this migration
  owner text NOT NULL, approved_by text);

CREATE TABLE cutover_item (                  -- finding 3
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  concept text NOT NULL,
  item_class text NOT NULL,                  -- pending_payment | future_dated | standing_instruction |
                                             -- accrued_interest | hold | lien | other
  selector text NOT NULL,                    -- MDL expression identifying the items in v1
  rule text NOT NULL,                        -- migrate | settle_before_freeze | recompute
  reconcile_check text NOT NULL);            -- MDL assertion reconciled separately

CREATE TABLE job (                           -- control plane → data plane handoff
  id UUID PRIMARY KEY,
  kind text NOT NULL,                        -- profile | rehearse | migrate | delta | compare | learn
  migration_id UUID REFERENCES migration(id),
  spec_hash text,                            -- worker refuses jobs whose hash is not approved
  params jsonb NOT NULL DEFAULT '{}',
  requested_by text NOT NULL, approved_by text,   -- four-eyes for migrate/delta on production
  status text NOT NULL DEFAULT 'queued',     -- queued | approved | running | done | failed
  claimed_by text, started_at timestamptz, finished_at timestamptz, error text);

CREATE TABLE rehearsal (
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  kind text NOT NULL,                        -- synthetic | masked | dress | production
  spec_hash text NOT NULL, seed bigint NOT NULL,
  job_id UUID REFERENCES job(id),
  report jsonb,                              -- § 23.9 ReconciliationReport
  previous_id UUID REFERENCES rehearsal(id));

CREATE TABLE crosswalk (                     -- partition by concept in production
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  concept text NOT NULL, business_key text NOT NULL,
  old_key jsonb NOT NULL, new_key jsonb NOT NULL,
  rehearsal_id UUID NOT NULL REFERENCES rehearsal(id),
  PRIMARY KEY (rehearsal_id, concept, business_key));

CREATE TABLE ledger (                        -- row-conservation ledger
  rehearsal_id UUID NOT NULL REFERENCES rehearsal(id) ON DELETE CASCADE,
  source_table text NOT NULL, source_key jsonb NOT NULL,
  outcome text NOT NULL,                     -- migrated | merged | filtered | rejected
  target_keys jsonb, rule text, reason text,
  PRIMARY KEY (rehearsal_id, source_table, source_key));

CREATE TABLE quarantine (
  rehearsal_id UUID NOT NULL REFERENCES rehearsal(id) ON DELETE CASCADE,
  source_table text NOT NULL, source_key jsonb NOT NULL,
  reject_code text NOT NULL, error text NOT NULL,
  payload_ref text,                          -- pointer into data-plane storage, never the row itself
  PRIMARY KEY (rehearsal_id, source_table, source_key));

CREATE TABLE golden_mapping (                -- finding 5
  id UUID PRIMARY KEY,
  source_field text NOT NULL, target text NOT NULL,   -- target field or concept attribute
  pattern text NOT NULL, correct boolean NOT NULL,
  from_migration_id UUID REFERENCES migration(id));

CREATE TABLE eval_run (
  id UUID PRIMARY KEY,
  model_id text NOT NULL, prompt_version text NOT NULL, thresholds jsonb NOT NULL,
  precision_at_1 numeric, recall_at_10 numeric, mrr numeric,
  accepted boolean NOT NULL DEFAULT false, run_at timestamptz NOT NULL DEFAULT now());

CREATE TABLE comparison (                    -- behaviour comparator (finding 1)
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  name text NOT NULL,                        -- 'EOD balances 2026-11-30'
  concept text NOT NULL,                     -- keys joined through the crosswalk of this concept
  v1_artifact text NOT NULL, v2_artifact text NOT NULL,   -- uploaded output files (data plane)
  tolerance jsonb NOT NULL DEFAULT '{}',     -- per column, minor units; default exact
  result jsonb);

CREATE TABLE signoff (
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  rehearsal_id UUID REFERENCES rehearsal(id),
  kind text NOT NULL,                        -- mapping_spec | data_equivalence |
                                             -- behaviour_equivalence | cutover_readiness | ponr
  role text NOT NULL, user_id text NOT NULL,
  decision text NOT NULL,                    -- approve | reject
  note text, at timestamptz NOT NULL DEFAULT now());
```

`ledger` and `quarantine` hold keys, outcomes and pointers only. Row payloads stay
in data-plane storage (§ 25).

---

## 19. MDL additions

### 19.1 Grammar extension (`app/mdl/grammar.lark`)

Add to `statement` the alternatives `concept_def | realize_def | migration_def`, and:

```lark
concept_def: "concept" NAME "{" concept_item* "}"
concept_item: "identity" "business_key" "(" NAME ("," NAME)* ")"
            | "attr" NAME ("," NAME)*
            | "has_many" NAME ("roles" "(" NAME ("," NAME)* ")")?
            | "has_one"  NAME
            | "aligned_to" NAME STRING                    // scheme, IRI

realize_def: "realize" NAME ("from" | "into") NAME "{" realize_item* "}"
realize_item: ("table" | "tables") table_expr ("where" expr)?
            | "key" NAME "generated"?
            | NAME ("(" NAME ")")? ("<-" | "->") rexpr mapping_meta*
table_expr: NAME ("(" assign ("," assign)* ")")? ("+" NAME ("(" assign ("," assign)* ")")?)*
rexpr: expr ("," expr)*
     | "unpivot" "(" NAME ("," NAME)* ")" ("skip" "null")?
     | "pivot" "(" NAME "," NAME ")"                      // key column, value column
rexpr_tail: "via" "valueset" NAME "(" NAME "->" NAME ")"
          | "by_example" STRING
mapping_meta: rexpr_tail | "confidence" NAME | "approved_by" STRING

migration_def: "migration" NAME "->" NAME "{" migration_item* "}"
migration_item: "concepts" NAME ("," NAME)*
              | "crosswalk" NAME ":" NAME "->" NAME ("persist" STRING)?
              | "unmapped_source" qname ":" NAME                   // drop | archive | extension
              | "missing_target"  qname ":" target_fill
              | "derived" qname ":" ("migrate" | "recompute")
              | "represent" qname ":" repr_rule ("," repr_rule)*
              | "cleanse" qname "when" expr "->" cleanse_action "owner" STRING
              | "cutover" "{" cutover_rule* "}"
              | "reconcile" "{" reconcile_rule* "}"
              | "history" NAME ":" NAME                            // extension point, § 29
target_fill: "default" value | "derive" func_call | "flag"
repr_rule: "charset" STRING | "normalize" NAME | "timezone" STRING "->" STRING
         | "round" NAME NUMBER                                     // mode, scale
cleanse_action: "fix" expr | "reject" STRING
cutover_rule: NAME "select" expr "rule" NAME "check" expr
reconcile_rule: expr ("==" expr)?
              | "sum" "(" qname ")" "by" NAME ("," NAME)* ":" "exact"
              | "ledger" "every_source_row"
```

Extend this grammar only if a § 27 test requires it, and record the change in
`DECISIONS.md`.

### 19.2 Compiler additions (`app/mdl/checker.py`, `app/migrate/compose.py`)

New checks, run after the Part A stages:

1. **Concept resolution** — every `realize` names a known concept; every left/right
   side resolves to a field in its version or an attribute of the concept.
2. **Direction** — in a `from` block each expression must compute concept ← source;
   in an `into` block, target ← concept. An expression registered as lossy in the
   transform library (§ 21.5) in that direction requires `by_example` or a
   `lossy_expression` decision. → `ERR_LOSSY_UNRESOLVED`.
3. **Coverage** — every mandatory target field is filled by an `into` mapping or a
   `missing_target` rule; every source field is consumed by a `from` mapping or an
   `unmapped_source` rule. → `ERR_UNCOVERED_TARGET`, `ERR_UNCONSUMED_SOURCE`.
4. **Derived values** — a target field marked derived in the target profile or
   application code requires a `derived … : migrate|recompute` rule. → `ERR_DERIVED_UNDECIDED`.
5. **Open decisions** — any `decision` row with `choice IS NULL` for this
   migration. → `ERR_OPEN_DECISION` (blocks compilation; lists them all).
6. **Fit** — Part A fit checks applied to every `into` expression, including
   valueset translations and representation rules.
7. **Compose** — produce the `MappingPlan` (§ 22.1) and its `spec_hash`.

Each compiled realisation also writes `REALISES` claims, and each composed
mapping writes a derived `MAPS_TO` claim, so the graph always mirrors the spec.

---

## 20. Source intelligence (runs in the data plane, writes the graph)

### 20.1 Inventory and profiling (`intel/profiler.py`, `intel/sketches.py`)

```python
def inventory(version: SystemVersion) -> list[KgNode]            # tables, columns, views, procs
def profile_table(version, table: str, sample: int | None = None,
                  k_threshold: int = 20) -> list[ColumnProfile]
```

Per column: row count, null fraction, HLL distinct estimate, min/max (masked when
sensitive), length histogram, **format histogram** (each value reduced to its
character-class shape: digit → `0`, upper → `A`, lower → `a`, others kept),
top values with count ≥ `k_threshold` (masked by § 25.3), numeric histogram,
MinHash (128 permutations) over normalised distinct values.

Large tables: profile on a uniform sample (default 1,000,000 rows) and record the
sample size in the activity inputs. Exact checks in § 20.3 always use full data.

### 20.2 Semantic typing (`intel/semtypes.py`)

Deterministic validators first, each returning a match rate over non-null values:

| Domain | Rule |
|---|---|
| IBAN | ISO 13616 mod-97 |
| IFSC | `^[A-Z]{4}0[A-Z0-9]{6}$` |
| PAN (India) | `^[A-Z]{5}[0-9]{4}[A-Z]$` |
| Card number | 13–19 digits, Luhn |
| Currency code | ISO 4217 list |
| Country code | ISO 3166 alpha-2/3 |
| Date / timestamp | a configured list of formats; reports the winning format |
| Email, phone (E.164 or Indian 10-digit) | regex |
| Code set | values ⊆ a known valueset (from the model) |

Assign a type when match rate ≥ 0.98 (configurable). Residual columns get a
learned or LLM-assisted type with neighbouring columns as context, always as a
`proposed` claim. Write `HAS_SEMANTIC_TYPE` claims with `semtype` evidence.

### 20.3 Constraint discovery (`intel/constraints.py`)

```python
def discover_uccs(table, max_size: int = 3) -> list[Claim]        # UNIQUE
def discover_inds(version) -> list[Claim]                          # INCLUDED_IN
def discover_fds(table, max_lhs: int = 2, max_error: float = 0.01) -> list[Claim]
```

- **UCCs:** candidates by HLL distinct ≈ row count; confirm with exact `COUNT(DISTINCT …)`.
- **INDs:** candidate pairs by MinHash containment ≥ 0.9 and type compatibility; confirm
  with an exact anti-join (`child NOT IN parent` count) on full data. Record containment.
- **FDs:** on a sample, measure the g3 error (fraction of rows to remove for the FD to
  hold); keep FDs with error ≤ `max_error`.

### 20.4 Code mining (`intel/codemine.py`)

Parse view definitions, stored-procedure SQL and any application SQL found at
`code_location` with `sqlglot`. Each join predicate becomes a `JOINS_ON` claim with
`sql_parse` evidence and a `query` node. Unparseable statements are logged, never fatal.

### 20.5 LLM relationship proposals (`llm/…`, § 21.6 contract)

For each container, send the grounded context (§ 21.6) and ask for relationship
claims the statistics missed. Every proposal becomes a `proposed` claim with `llm`
evidence, then the validator (§ 21.7) tests it on data (containment, cardinality
shape, join success rate); evidence from those tests is attached either way.

### 20.6 Global structure solve (`kg/structure.py`)

```python
def solve_structure(version_id) -> list[ClaimDecision]
```

Build a directed graph child → parent from `INCLUDED_IN` candidates whose object is
on a `UNIQUE` field set, weighted by confidence. Take
`networkx.maximum_spanning_arborescence` per connected component so each foreign
key has one parent and the structure is consistent. Claims chosen become
`accepted` *only* in the high band; others stay `proposed` for review.

### 20.7 Entity clustering (`intel/entities.py`)

Cluster containers sharing a key (1:1 `INCLUDED_IN` both ways or a shared business
key), plus name stems. Each cluster yields a `MEMBER_OF_ENTITY` proposal against an
existing concept by embedding similarity, or a "new concept" suggestion for review.

### 20.8 Calibration (`kg/calibrate.py`)

Until a predicate has a configurable minimum of labelled outcomes (default 200, accept or reject), confidence is shown
as a band from fixed evidence rules (§ 21.8). After that, fit an
`IsotonicRegression` from evidence features to acceptance per predicate, store
`calibrator_version`, and show a reliability curve in the Evidence screen.

### 20.9 Data-quality assessment (`intel/dq_report.py`) — finding 2

Produced at the end of profiling, before any mapping work:
nulls in fields that are mandatory in the target, format violations against the
detected semantic type, orphans (`INCLUDED_IN` containment < 1), duplicate business
keys, out-of-range dates, and free text in coded fields. Each issue class is
proposed as a `reject_category` with an estimated count, for an owner to accept.

---

## 21. Mapping discovery (control plane)

### 21.1 Pipeline entry point

```python
# app/mapping/__init__.py
def discover(migration_id: UUID) -> DiscoveryResult
```

Stages, in order: align entities → retrieve candidates → LLM rerank → global
assignment → classify pattern and propose transform → band confidence → order for
review. Every stage writes claims and evidence; nothing is held only in memory.

### 21.2 Entity alignment (`mapping/retrieve.py`)

Align source entity clusters to concepts, and concepts to target clusters, before
any attribute. Score = weighted sum of: key-structure similarity, relationship-shape
similarity (degree and fan-out pattern), semantic-type overlap, name/description
embedding similarity, and LLM judgement over both applications' code summaries.
Weights live in config; record them in the activity inputs.

### 21.3 Candidate retrieval

```python
def candidates(concept_attr: KgNode, side: Literal["source","target"], k: int = 10) -> list[Candidate]
```

Rank fields within aligned entities by: embedding similarity (pgvector), semantic
type compatibility, format-histogram similarity, code-set overlap (only where both
sides have values or reference data), and key-shape compatibility. Never send whole
schemas to the LLM.

### 21.4 Pattern classification (`mapping/patterns.py`)

```python
class Pattern(StrEnum):
    RENAME_RETYPE = "rename_retype"; SPLIT_MERGE = "split_merge"
    CODE_TRANSLATION = "code_translation"; REPEATING_TO_CHILD = "repeating_to_child"
    TABLE_SPLIT_JOIN = "table_split_join"; ENTITY_MERGE = "entity_merge"
    KEY_REGENERATION = "key_regeneration"; GRAIN_CHANGE = "grain_change"
    TEMPORAL_CHANGE = "temporal_change"; KEY_VALUE = "key_value"
    DOCUMENT = "document"; NEW_MANDATORY = "new_mandatory"; DROPPED = "dropped"
    REPRESENTATION = "representation"      # finding 4: charset, normalisation, time zone, rounding

def classify(candidate_set) -> Pattern
```

`NEW_MANDATORY`, `DROPPED`, and any derived target field create `decision` rows
instead of transforms. `REPRESENTATION` is detected from charset metadata, the
presence of non-ASCII scripts in profiles, time-zone-bearing types, and differing
numeric precision or scale.

### 21.5 Transform library (`mapping/transforms/`)

Each function is pure, typed, registered with its direction properties:

```python
@transform(name="split_address", inverse=None, lossy_forward=False, lossy_inverse=True)
def split_address(s: str) -> dict[str, str]: ...
```

Ship: `to_date(fmt)`, `to_timestamp(fmt, tz)`, `tz_convert`, `round_money(mode, scale)`,
`normalize_unicode(form)` (NFC default), `transcode(charset)`, `concat`, `split_name`
(lossy inverse), `split_address` (lossy inverse), `iban_format`, `ifsc_upper`,
`valueset_lookup`, `unpivot`, `pivot`, `nest_json(path)`, `flatten_json(path)`,
`coalesce`, `default`. Money is always integer minor units (reuse `app/engine/aggregate/money.py`).

### 21.6 LLM contract (`llm/provider.py`, `llm/contracts.py`, `llm/grounding.py`)

```python
class LLMProvider(Protocol):
    model_id: str                                   # pinned; recorded on every activity
    def complete_json(self, prompt: str, schema: dict, max_tokens: int) -> dict: ...

def grounded_context(task: Task, hops: int = 2, budget_tokens: int = 6000) -> str
```

- **Context:** the subgraph within `hops` of the task's nodes: names, types,
  descriptions, profiles (aggregates), masked samples (§ 25.3), existing claims with
  bands, and relevant parsed SQL. Serialised as compact lines keyed by node id.
- **Output:** JSON validated against a schema. Every referenced entity must be an
  existing node id; `predicate` from the closed list (§ 18.2); `pattern` from § 21.4;
  a one-line `reason`. Invalid JSON or unknown ids → rejected, not repaired by guessing.
- **Prompts** live in `llm/prompts/` as versioned files; the version is recorded on
  the activity. A prompt change is a golden-set evaluation event (§ 21.9).
- `StubProvider` returns canned outputs keyed by task and is used in all tests.

### 21.7 Validator (`llm/validate.py`)

```python
def validate(claim: Claim) -> ValidationResult      # passes | fails(reasons)
```

Checks, against accepted claims and profiles: type and length compatibility (fit),
containment for relationship claims, cardinality consistency with `UNIQUE` and
`DETERMINES`, no conflict with an accepted claim on the same field, direction rules
for transforms. A failing LLM proposal gets one repair round with the reasons; if it
still fails it is stored as `rejected` with the reasons as evidence.

### 21.8 Assignment, bands and review order

- **Assignment** (`mapping/assign.py`): per aligned entity pair, build a score matrix
  of candidates and solve with `linear_sum_assignment`; then enforce grain and
  cardinality, dropping assignments that would break them.
- **Bands** (until calibrated): *high* = deterministic evidence agrees (type + format
  + containment or code-set overlap) and LLM agrees; *medium* = two independent
  signals agree; *low* = otherwise. Below *low*, the tool abstains and asks.
- **Review order** (`mapping/impact.py`): entity alignments and keys first, then
  claims by the number of downstream mappings that depend on them; plain renames in
  the high band are offered for bulk approval.

### 21.9 Examples on demand and golden set (`mapping/pbe.py`, `llm/golden.py`)

- **Examples:** the reviewer supplies 2–10 source → target examples (CSV). `pbe.py`
  searches the transform library and compositions up to depth 2 for a program
  consistent with all examples; failing that, asks the LLM for an expression in the
  MDL expression subset and tests it. Examples are stored and become tests.
- **Golden set** (finding 5): every reviewer decision on a mapping is appended to
  `golden_mapping`. `golden.py` replays discovery against the golden set and records
  precision@1, recall@10 and MRR in `eval_run`. A change of model, prompt or
  threshold may be deployed only if its `eval_run` does not fall below the last
  accepted run on any metric (thresholds configurable).

---

## 22. Migration execution

### 22.1 MappingPlan IR (`migrate/plan.py`)

```python
@dataclass(frozen=True)
class FieldMap:
    target: str                       # 'CORE_V2.PERSON.FIRST_NM'
    expr: dict                        # expression AST over concept attributes
    pattern: str
    lossy: bool

@dataclass(frozen=True)
class ConceptPlan:
    concept: str
    read: dict                        # source tables, joins, filters, unpivots → concept rows
    write: tuple[FieldMap, ...]       # concept rows → target tables
    identity: tuple[str, ...]         # business key attributes
    key_strategy: dict                # {"table":..., "column":..., "mode":"generated"|"carried"}
    depends_on: tuple[str, ...]       # concepts whose crosswalk this one needs

@dataclass(frozen=True)
class MappingPlan:
    spec_hash: str; seed: int
    order: tuple[str, ...]            # concepts in dependency order (flow ordering)
    concepts: dict[str, ConceptPlan]
    cleanse: tuple[dict, ...]; representation: tuple[dict, ...]
    derived: dict[str, str]           # target field → migrate | recompute
    cutover: tuple[dict, ...]; reconcile: tuple[dict, ...]
```

### 22.2 Two executors, one plan

```python
# migrate/interpreter.py — the oracle
def interpret(plan: MappingPlan, source_rows: Iterable[dict]) -> TargetRows
# migrate/executor.py — production
def execute(plan: MappingPlan, partition: Partition, ctx: RunContext) -> PartitionResult
```

- **Reference interpreter:** pure Python, row by row, straight from the IR, no
  optimisation, no shared code with the executor beyond the transform library and
  the IR. Used on fixtures only.
- **Production executor:** extracts each partition to Parquet in data-plane storage,
  transforms with polars (vectorised, compiled from the same IR), loads through the
  Part A adapter SPI. Cleanse rules run first; failures go to quarantine with a
  `reject_code`; every source row gets a ledger outcome.

The transform library is the only shared code, and it has its own unit tests.

### 22.3 Key crosswalk (`migrate/crosswalk.py`)

```python
def build(plan, concept, rehearsal_id) -> int        # rows written
def resolve(concept, old_key) -> new_key             # used by dependent concepts
```

Built for a concept before any dependent concept loads. Generated keys are
deterministic: sort by business key, allocate from a configured start offset per
target sequence, so two rehearsals with the same plan and seed produce identical keys.
Kept after go-live and exported for support and downstream teams.

### 22.4 Partitions, checkpoints, idempotency

Partition each concept by business-key range (configurable count). Each partition
is a unit of work: load is idempotent (delete rows tagged with the run and partition,
then insert; or MERGE where the adapter supports it), checkpointed in the `job`
params, and restartable. Load engineering per adapter: optional deferred index and
constraint creation, then a validation pass after load (finding 11).

### 22.5 Sizing (`migrate/sizing.py`) — finding 11

```python
def estimate(plan, profiles, sample_run: PartitionResult) -> SizingReport
```

Rows per concept from profiles × measured rows/second from a sampled partition →
estimated duration per concept and in total, with the critical path through the
dependency order. Shown before any dress rehearsal and compared afterwards.

### 22.6 Cutover state (`migrate/cutover.py`) — finding 3

Each `cutover_item` is evaluated against v1 at freeze: items with rule `migrate`
go through the plan; `settle_before_freeze` items must count zero at freeze or the
cutover gate fails; `recompute` items are excluded from load and listed for the v2
team. Each class has its own reconcile check in the report.

### 22.7 Delta catch-up (`migrate/delta.py`)

For bulk-then-delta cutover: each source table declares a watermark (timestamp or
monotonic id). The delta job selects rows changed since the bulk watermark and runs
them through the same plan, updating crosswalk and ledger. Deletes in v1 need a
soft-delete flag or a log source; if neither exists, the compiler emits
`WARN_DELTA_DELETES_UNTRACKED`.

### 22.8 Rehearsals and run-to-run diff (`migrate/rehearsal.py`) — finding 9

```python
def run(migration_id, kind: Literal["synthetic","masked","dress","production"]) -> Rehearsal
def diff(current: Rehearsal, previous: Rehearsal) -> RehearsalDiff
```

`diff` joins target rows of two rehearsals through deterministic keys and
attributes every difference to one cause: `spec_changed` (the field's `MAPS_TO`
claim or expression differs between the two `spec_hash`es), `data_changed` (the
source row differs), or `unexplained` (neither). Any `unexplained` difference fails
the rehearsal.

### 22.9 Point of no return — finding 10

`ponr` is a sign-off kind. When signed, `migration.ponr_at` is set and
`post_ponr_policy` is recorded (`forward_fix` or `reverse_sync`). Part B does not
build reverse sync; the cutover-readiness gate requires the policy to be recorded.

---

## 23. Verification

### 23.1 Spec checks
The § 19.2 compiler checks. A migration cannot reach `specified` status with any error.

### 23.2 Differential testing (`verify/differential.py`)

```python
def differential(plan, fixtures: SyntheticFixtures) -> DiffReport
```
Run `interpret` and `execute` on the same synthetic source fixtures; compare target
rows field by field through the crosswalk. Any difference fails.

### 23.3 Fixtures aimed at risk (`engine` scenario reuse)

Fixtures come from the Part A scenario engine with the source version's learned or
declared model, plus generated edge cases derived from the plan: each valueset code
including unmapped ones, null and empty in every join key, duplicate business keys,
maximum-length values for every target field, non-ASCII names, time-zone and
date boundaries, rounding boundaries (half-cent cases), and each cutover item class.

### 23.4 Metamorphic tests (`verify/metamorphic.py`)

| Relation | Check |
|---|---|
| Idempotence | Re-running a partition leaves the target unchanged |
| Partition independence | Different partition counts give identical output |
| Order independence | Shuffling source rows gives identical output |
| Filter neutrality | Adding a row the plan filters out changes nothing but the ledger |
| Money conservation | Control totals equal before and after, in minor units |

### 23.5 Row-conservation ledger (`migrate/ledger.py`)

```python
def check_conservation(rehearsal_id) -> ConservationResult
```
Per source table: `migrated + merged + filtered + rejected == source row count`, and
zero rows without an outcome. Where grain changes, the expected target count is
computed from the plan (for example child rows = filled repeating slots).

### 23.6 Control totals and round trip (`verify/reconcile.py`)

- Control totals: sums of every money field by the dimensions named in `reconcile`
  (product, currency, branch, GL account), computed with the Part A aggregate
  engine's integer arithmetic; must match exactly.
- Round trip: for a stratified sample (by segment and risk), read each entity from
  v1 into the concept and from v2 back into the concept through the inverse of the
  `into` realisation, then compare. Money fields are compared in full, not sampled.

### 23.7 Mutation testing of the suite (`verify/mutation.py`)

Apply mutations to a copy of the plan (swap two codes in a valueset, drop a filter,
off-by-one on a date, flip a rounding mode, drop a join condition) and run the
fixture suite. Report the kill rate; the target is that every mutation is killed.

### 23.8 Behaviour support — finding 1 (out of scope to run, in scope to enable)

- **Comparator** (`verify/comparator.py`): the v2 or UAT team uploads the outputs of
  a business process run on both versions (for example end-of-day balances, interest
  postings, statement lines) as CSV or Parquet. DataForge joins them through the
  concept's crosswalk and diffs them with per-column tolerances (default exact, in
  minor units). Results go to `comparison.result`.
- **Test pack** (`verify/testpack.py`): crosswalk extract plus migrated samples
  stratified by risk segment (dormant, overdraft, multi-currency, each cutover item
  class, each reject category that was fixed rather than rejected).
- **Synthetic v2 data**: § 24.3.
- **Gate**: the `behaviour_equivalence` sign-off is required for cutover readiness;
  DataForge records it but does not produce it.

### 23.9 ReconciliationReport (stored in `rehearsal.report`)

```jsonc
{"rehearsalId":"…","kind":"dress","specHash":"…","durationSec":5410,
 "ledger":{"CUST_MASTER":{"source":120430,"migrated":120102,"merged":211,
           "filtered":96,"rejected":21,"unexplained":0}},
 "controlTotals":[{"field":"ACCOUNT.balance","by":["product","currency"],
                   "mismatches":0}],
 "roundTrip":{"sampled":5000,"mismatches":0},
 "rejectsByCategory":{"BAD_DOB":14,"ORPHAN_ACCOUNT":7},
 "cutover":[{"class":"pending_payment","rule":"settle_before_freeze","remaining":0}],
 "diffVsPrevious":{"spec_changed":1840,"data_changed":12,"unexplained":0},
 "sizing":{"estimatedSec":5200,"actualSec":5410}}
```
(The numbers are illustrative of the shape only.)

---

## 24. Learned synthetic generation

### 24.1 What is learned (`learn/…`, data plane)

```python
def learn_degrees(version_id) -> dict[str, DegreeDist]           # children per parent per relation
def learn_marginals(version_id, k_threshold=20, epsilon: float | None = None) -> dict[str, Marginal]
def learn_constraints(version_id) -> list[Claim]                  # validated LLM + discovered rules
```

Degree distributions per accepted relationship; one- and two-way marginals of
attributes given parent context; code frequencies (become valueset weights); time
patterns (inter-event gaps, month-end and salary-day peaks). Counts below
`k_threshold` are suppressed. If `epsilon` is set, Laplace noise is added to counts.
Identities, keys, free text and rare exact combinations are never learned.

### 24.2 Use in generation

Learned distributions are emitted as MDL generator specs `learned("<model_id>")`
so Part A scenarios, rules and the aggregate solver apply on top. Structure (keys,
cardinalities, ordering) comes from the graph, never from a learned model.

### 24.3 Target-shaped data

Generate concept instances, then write them through the target version's `into`
realisation with the production executor's transform code. Output: synthetic v2
data for the v2 team, before any migration runs.

### 24.4 Privacy gate (`learn/privacy.py`)

Before a learned model is used outside the data plane: verify no released category
below `k_threshold`; compute distance-to-closest-record between a synthetic sample
and a real holdout versus real-to-real distances; run a simple membership test
(train/holdout distinguisher). Results are stored on the activity; failure blocks use.

### 24.5 Fidelity report (`learn/fidelity.py`)

```python
def fidelity(model_id: UUID, synthetic: SyntheticDataset) -> FidelityReport
```

Computed in the data plane against the real data the model was learned from; only
scores leave. The report is advisory until a project sets thresholds from its
first accepted baseline (`config/fidelity.yaml`); after that, it is a gate.

| Check | Measure |
|---|---|
| Column distributions | Total variation distance (categorical), Kolmogorov–Smirnov statistic (numeric), per column |
| Pairwise relationships | Mean absolute difference of association matrices: Cramér's V for categorical pairs, Spearman for numeric pairs |
| Children per parent | Kolmogorov–Smirnov statistic per accepted relationship |
| Time patterns | Inter-event gap distribution and day-of-month profile |
| Discriminator | Cross-validated AUC of a `HistGradientBoostingClassifier` separating real from synthetic parent rows enriched with child aggregates; 0.5 means indistinguishable |
| Utility | Part A rule pass rates and reject-category rates on synthetic versus real, within tolerance |

### 24.6 Transaction sequences (`learn/sequences.py`)

```python
def learn_sequences(version_id, segment_by: list[str], k_threshold=20) -> SequenceModel
def generate_sequences(model, accounts, as_of: date, seed: int) -> TransactionFrame
```

Per segment: a first-order Markov chain over transaction states (channel ×
direction × category), an inter-arrival gap distribution per state, an amount
distribution per state, and calendar factors (weekday, day of month, salary day,
month end) as intensity multipliers. Segments below `k_threshold` back off to their
parent segment. Generation runs each account from its open date, or its Part A
lifecycle `ACTIVE` intervals when a lifecycle is declared, to `as_of`. When a
scenario pins a balance, the sequence supplies the order and classes and the
aggregate solver supplies exact amounts, with the running-balance guard applied.

### 24.7 Edge-case pattern mining (`learn/edge_patterns.py`)

```python
def mine_patterns(version_id, k_threshold=20) -> list[EdgePattern]
```

From profiles and claims, find rare-but-valid patterns: low-frequency codes, long
dormancy, tail account ages, maximum-length values, accepted dependency exceptions,
and source codes absent from the target valueset. Each becomes a named scenario
template (`scenario "edge:<name>"`) with a count. Values are always generated to
satisfy the pattern, never copied. A pattern with fewer than `k_threshold` real
occurrences is described by structure only (for example "dormancy above 10 years
exists"), with no values. Patterns also feed the risk fixtures in § 23.3.

### 24.8 Volume scaling (`learn/scale.py`)

```python
def scale_plan(model, factor: float) -> GenerationPlan       # e.g. 0.01 to 10
```

Root-entity counts scale by `factor`; children-per-parent distributions and
per-account sequences keep their shape. Scenario-pinned totals stay pinned unless
the scenario marks them `scales`. Before generating, the compiler checks every
unique field's value space (from its pattern or generator) against the required
count → `ERR_VALUE_SPACE` if it cannot fit. Keys stay deterministic, so scaled runs
remain reproducible and collision-free.

### 24.9 Re-learning per release (`learn/relearn.py`)

```sql
CREATE TABLE learned_model (
  id UUID PRIMARY KEY,
  system_version_id UUID NOT NULL REFERENCES system_version(id),
  version int NOT NULL,                      -- 1, 2, 3 … per system version lineage
  learned_at timestamptz NOT NULL,
  k_threshold int NOT NULL, epsilon numeric,
  profile_activity_id UUID NOT NULL REFERENCES kg_activity(id),
  fidelity_report jsonb, privacy_report jsonb, drift_report jsonb,
  status text NOT NULL DEFAULT 'candidate',  -- candidate | approved | retired
  UNIQUE (system_version_id, version));
```

Re-learn on each release's profiling run, or when Part A schema import detects
drift. Every re-learn creates a new `learned_model` version with a drift report
against the previous one (per-column distribution shift, degree shift, sequence
shift). `learned("<model_id>")` references stay pinned to their version until a
modeller moves them, so generation never changes silently. A version is usable
only once its privacy gate passes and, where thresholds exist, its fidelity gate.

---

## 25. Planes, security and governance

### 25.1 Two deployables

| Plane | Process | Has | Never has |
|---|---|---|---|
| Control | `app.main` (API, UI, compiler, mapping, LLM) | Metadata, aggregates, masked samples, specs, synthetic data, reports | Source or target credentials; real rows |
| Data | `app.worker.main` | Connector credentials (from a vault), profiler, executor, crosswalk, quarantine payloads | Network access to any LLM provider |

The two share the Postgres metadata database only. The worker polls `job` with
`SELECT … FOR UPDATE SKIP LOCKED`, and refuses any `rehearse`, `migrate` or `delta`
job whose `spec_hash` does not match an approved `mapping_spec` sign-off.

### 25.2 Roles and separation of duties — finding 8

| Role | May | May not |
|---|---|---|
| Modeller | Edit MDL, concepts, cleanse rules; run discovery | Approve own mappings; approve production jobs |
| Reviewer | Approve or reject claims and mappings; supply examples | Run production jobs |
| Data owner | Own reject categories; approve cleanse rules for their data | — |
| Approver | Sign off `mapping_spec`, `data_equivalence`, `cutover_readiness`, `ponr` | Request the job they approve |
| Operator | Request rehearsal and migration jobs | Edit specs |
| Behaviour owner (v2/UAT team) | Upload comparator outputs; sign off `behaviour_equivalence` | — |
| Auditor | Read everything; export PROV-O and OpenLineage | Change anything |

Enforced in `governance/roles.py`: `job.requested_by != job.approved_by` for
`migrate` and `delta` against a production profile; a reviewer cannot approve a
claim whose latest evidence is their own edit.

### 25.3 What crosses from data plane to control plane

- Profiles above `k_threshold` only.
- Samples for the LLM through `llm/masking.py`: format-preserving masking with a
  per-project secret key (each digit → a keyed-pseudorandom digit, each letter →
  letter of the same case; separators and length preserved). Checksums are not
  preserved; semantic typing on real values happens in the data plane first.
- Never: row payloads, quarantine payloads, crosswalk business keys of real
  customers (the control plane shows counts and hashed keys).

### 25.4 Audit and lineage

- Every claim traces to evidence → activity → agent with version.
- `kg/prov_export.py` exports approvals and their evidence as PROV-O JSON-LD.
- The worker emits OpenLineage run events (start, complete, fail) per job, with
  column-level lineage from the plan's `MAPS_TO` claims.
- Sign-offs are append-only; corrections are new rows.

---

## 26. API and UI additions

### 26.1 API (base `/api`)

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/systems/{id}/versions` | Register a system version (source or target) |
| `POST` | `/versions/{id}/profile` | Queue a profiling job |
| `GET` | `/versions/{id}/dq-report` | Data-quality assessment |
| `GET` | `/graph/nodes?version=&kind=&q=` | Search nodes |
| `GET` | `/graph/nodes/{id}/neighbourhood?hops=2` | Subgraph with claims and bands |
| `GET` | `/graph/claims?predicate=&status=&band=` | Claim list for review |
| `POST` | `/graph/claims/{id}/review` | `{decision: accept|reject, note}` → human evidence |
| `POST` | `/migrations` | Create a migration |
| `POST` | `/migrations/{id}/discover` | Run mapping discovery |
| `GET` | `/migrations/{id}/review-queue` | Impact-ordered review items |
| `POST` | `/migrations/{id}/examples` | Upload examples for a field (CSV) |
| `GET` / `PATCH` | `/migrations/{id}/decisions` | List and decide open decisions |
| `POST` | `/migrations/{id}/compile` | Compile; returns diagnostics and `spec_hash` |
| `POST` | `/migrations/{id}/rehearsals` | `{kind}` → queues a job |
| `GET` | `/rehearsals/{id}` | Report, ledger summary, diff vs previous |
| `GET` | `/rehearsals/{id}/rejects?category=` | Reject triage (hashed keys, codes, counts) |
| `POST` | `/migrations/{id}/comparisons` | Upload v1/v2 process outputs; run comparator |
| `GET` | `/migrations/{id}/testpack` | Download the test pack (data plane delivers the file) |
| `POST` | `/migrations/{id}/signoffs` | Record a sign-off |
| `POST` | `/jobs/{id}/approve` | Four-eyes approval |
| `GET` | `/eval/runs` · `POST /eval/runs` | Golden-set evaluations |
| `POST` | `/versions/{id}/learn` | Queue a learning job; creates a candidate `learned_model` |
| `GET` | `/learn/models?version=` | Model versions with status |
| `GET` | `/learn/models/{id}/reports` | Fidelity, privacy and drift reports |
| `POST` | `/learn/models/{id}/approve` | Approve a model version for use |

### 26.2 Screens (Part A design tokens and chrome apply)

- **Sources** — system versions, profiling status, the data-quality report as a list
  of issue classes with counts and proposed reject categories.
- **Evidence** — search box, node detail with its claims; each claim shows predicate,
  band pill (`ok` high, `warn` medium, `err` low), the evidence list (kind, score,
  agent, time) and accept/reject buttons. Reliability curve per predicate once calibrated.
- **Concepts** — concept list, attributes, identity, aligned-to links; the
  realisations per version shown side by side (from / into).
- **Mapping review** — the impact-ordered queue, built on the Part A drift-review
  pattern: pattern label, source → target, band, one-line reason, evidence
  breakdown, examples upload, bulk approve for high-band renames. Open decisions in
  a separate list that must reach zero.
- **Migration** — rehearsal list with kind, spec hash and status; per rehearsal the
  ledger table, reject categories with owners and counts across rehearsals (trend to
  zero), cutover item classes, sizing estimate versus actual, diff versus previous
  with the three causes.
- **Reconcile** — control totals table, round-trip results, comparator results
  uploaded by the behaviour owner.
- **Learned models** — model versions per system version with status; fidelity
  report as a check table (pass, fail or advisory per measure, discriminator AUC
  highlighted), privacy report, drift versus the previous version, and an approve
  action.
- **Sign-offs** — the gate checklist for the migration: mapping spec, data
  equivalence, behaviour equivalence, cutover readiness, point of no return; who
  signed, when, and which rehearsal.

---

## 27. Part B test plan

### 27.1 Principles
All Part B tests run against the fixture in § 27.4 with `StubProvider` as the LLM.
Tests that need a real model are marked `@pytest.mark.llm` and excluded from CI;
they run in the golden-set evaluation instead.

### 27.2 Named acceptance tests

| Milestone | Test | Asserts |
|---|---|---|
| M8 | `test_claim_requires_evidence` | A claim cannot be accepted without at least one evidence row |
| M8 | `test_bitemporal_query` | Graph "as known at T" returns what was recorded by T |
| M8 | `test_worker_refuses_unapproved_spec` | A `migrate` job with an unsigned `spec_hash` is refused |
| M8 | `test_prov_export_roundtrip` | Exported approvals parse as JSON-LD and keep agent and time |
| M9 | `test_profile_k_threshold` | Top values below `k_threshold` are never stored |
| M9 | `test_semtype_validators` | IFSC, PAN, IBAN, card Luhn, ISO 4217 typed correctly on the fixture |
| M9 | `test_ind_finds_undeclared_fk` | `ACCT_MASTER.CUST_NO` → `CUST_MASTER.CUST_NO` discovered with containment evidence |
| M9 | `test_codemine_joins` | The fixture view yields a `JOINS_ON` claim |
| M9 | `test_structure_one_parent` | Every FK has exactly one accepted parent after the structure solve |
| M9 | `test_dq_report_seeded_issues` | Bad dates, orphans and duplicates seeded in the fixture are all reported |
| M10 | `test_llm_unknown_ids_rejected` | LLM output naming a non-existent node is rejected |
| M10 | `test_validator_containment` | A proposed FK with containment below threshold is rejected with reasons |
| M10 | `test_masking_format_preserved` | Masked values keep length, case and separators; no original digit sequence survives |
| M10 | `test_golden_eval_gate` | A worse `eval_run` cannot be marked accepted |
| M11 | `test_mdl_concepts_parse` | Fixture concepts, realisations and migration parse and round-trip |
| M11 | `test_lossy_requires_examples` | `full_name -> FIRST_NM, LAST_NM` without examples → `ERR_LOSSY_UNRESOLVED` |
| M11 | `test_open_decision_blocks` | Any open decision → `ERR_OPEN_DECISION` listing it |
| M11 | `test_coverage_checks` | Uncovered `RISK_RATING` and unconsumed `FAX_NO` are reported |
| M11 | `test_derived_requires_rule` | `ACCRUED_INTEREST_MINOR` without `derived` rule → `ERR_DERIVED_UNDECIDED` |
| M11 | `test_graph_mirrors_spec` | Every compiled mapping has a matching `MAPS_TO` claim |
| M12 | `test_discovery_recall_fixture` | Every golden mapping appears in the top-10 candidates |
| M12 | `test_patterns_fixture` | PHONE1–3 → repeating_to_child; CUST_MASTER → table_split; names → representation |
| M12 | `test_review_order` | Entity alignments and keys precede attribute mappings in the queue |
| M12 | `test_pbe_name_split` | Name split learned from the fixture examples reproduces all examples |
| M13 | `test_interpreter_equals_executor` | Differential test passes on all fixtures |
| M13 | `test_crosswalk_deterministic` | Two rehearsals, same plan and seed → identical new keys |
| M13 | `test_ledger_conservation` | Outcomes sum to source counts; zero unexplained |
| M13 | `test_metamorphic` | All five relations in § 23.4 hold |
| M13 | `test_mutation_kill_rate` | Every listed mutation is killed by the suite |
| M13 | `test_grain_expected_counts` | CONTACT_POINT rows equal filled PHONE slots |
| M14 | `test_control_totals_exact` | Balance totals by product and currency match to the minor unit |
| M14 | `test_round_trip` | Sampled entities round-trip with zero mismatches |
| M14 | `test_cleanse_routes_rejects` | Seeded bad rows land in quarantine under the right `reject_code` |
| M14 | `test_cutover_settle_gate` | A non-zero `settle_before_freeze` class fails cutover readiness |
| M14 | `test_rehearsal_diff_attribution` | A spec change and a data change are attributed correctly; none unexplained |
| M14 | `test_comparator_crosswalk_join` | Uploaded v1/v2 outputs join through the crosswalk; a planted difference is found |
| M14 | `test_testpack_strata` | Every risk stratum and cutover class is present in the pack |
| M14 | `test_four_eyes` | Requester cannot approve their own production `migrate` job |
| M14 | `test_signoff_gates` | Cutover readiness requires all five sign-off kinds |
| M14 | `test_sizing_report` | Estimate is produced and compared with actual after a rehearsal |
| M15 | `test_learned_k_threshold` | No learned category below `k_threshold` |
| M15 | `test_target_shaped_valid` | Synthetic v2 data passes v2 constraints and fit checks |
| M15 | `test_privacy_gate` | A deliberately leaky model is blocked |
| M15 | `test_fidelity_report_complete` | All six check families are reported, including discriminator AUC |
| M15 | `test_fidelity_detects_bad_generator` | A generator with independently shuffled columns fails the relationship and discriminator checks |
| M15 | `test_sequences_match_learned` | Synthetic inter-arrival gaps per segment match the learned distribution; month-end and salary-day peaks are present |
| M15 | `test_sequences_with_solver` | With pinned balances, sequences reconcile exactly and never breach the running-balance floor |
| M15 | `test_edge_patterns_not_copied` | Every mined pattern is reproduced; no synthetic value equals a real value seen fewer than `k_threshold` times |
| M15 | `test_scale_preserves_shape` | At 10× volume, distribution and degree measures stay within thresholds; no key collisions |
| M15 | `test_value_space_check` | A unique field too small for the requested volume → `ERR_VALUE_SPACE` |
| M15 | `test_relearn_pinned` | Re-learning creates a new version with a drift report; existing references are unchanged until moved |

### 27.3 Definition of Done (Part B)
All Part A and Part B tests green; the fixture migration runs synthetic, masked
(using the fixture as "real") and dress rehearsals with zero differential diffs,
zero unexplained ledger rows and exact control totals; every sign-off recorded.

### 27.4 Fixture `samples/legacy_v1_to_core_v2/`

Two Postgres schemas plus seed data, deliberately different in structure:

**LEGACY_V1** (flat, coded, partly undeclared):
- `CUST_MASTER(CUST_NO varchar(10) PK, CUST_NAME varchar(80), DOB_TXT varchar(10) 'DD/MM/YYYY', CUST_TYPE char(1) {I,C,N}, KYC_FLG char(1) {Y,N,E}, ADDR varchar(200), PHONE1, PHONE2, PHONE3 varchar(15), FAX_NO varchar(15), REC_STATUS char(1) {A,P}, BRANCH_IFSC char(11))`
- `ACCT_MASTER(ACCT_NO varchar(12) PK, CUST_NO varchar(10)` *(no declared FK)*`, PROD_CD varchar(4), CCY char(3), BAL_AMT numeric(15,2), ACCR_INT numeric(15,2), STATUS char(1) {A,D,C}, OPEN_DT date)`
- `TXN_HIST(TXN_ID bigint PK, ACCT_NO varchar(12), TXN_DT date, AMT numeric(15,2), DR_CR char(1), NARRATION varchar(100))`
- `STANDING_INSTR(SI_ID bigint PK, ACCT_NO varchar(12), AMT numeric(15,2), NEXT_DT date, FREQ char(1))`
- `PENDING_PMT(PMT_ID bigint PK, ACCT_NO varchar(12), AMT numeric(15,2), VALUE_DT date)`
- view `V_CUST_ACCT` joining `ACCT_MASTER.CUST_NO = CUST_MASTER.CUST_NO` (for code mining)

**CORE_V2** (party-role, minor units, generated keys):
- `PARTY(PARTY_ID bigint generated PK, EXTERNAL_REF varchar(20) UNIQUE, PARTY_TYPE varchar(12))`
- `PERSON(PARTY_ID bigint PK FK, FIRST_NM varchar(60), LAST_NM varchar(60), BIRTH_DT date, RISK_RATING varchar(10) NOT NULL)`
- `PARTY_ROLE(PARTY_ID bigint FK, ROLE_TYPE varchar(12), SEGMENT_CD varchar(8))`
- `CONTACT_POINT(PARTY_ID bigint FK, TYPE varchar(8), VALUE varchar(20), SEQ smallint)`
- `ADDRESS(PARTY_ID bigint FK, ROLE varchar(12), LINE1 varchar(80), LINE2 varchar(80), CITY varchar(40), PIN char(6))`
- `ACCOUNT(ACCOUNT_ID bigint generated PK, PARTY_ID bigint FK, PRODUCT_CODE varchar(8), CURRENCY char(3), BALANCE_MINOR bigint, STATUS_CD varchar(10), OPENED_ON date, ACCRUED_INTEREST_MINOR bigint)` *(derived in v2)*
- `POSTING(POSTING_ID bigint generated PK, ACCOUNT_ID bigint FK, VALUE_DT date, AMOUNT_MINOR bigint, DIRECTION char(2), DESCRIPTION varchar(140))`
- `STANDING_ORDER(SO_ID bigint generated PK, ACCOUNT_ID bigint FK, AMOUNT_MINOR bigint, NEXT_DT date, FREQUENCY varchar(10))`
- Reference table `SEGMENT_REF(SEGMENT_CD, NAME)`; a small application code folder with
  one entity class showing `RISK_RATING` validation and `ACCRUED_INTEREST_MINOR` as computed.

**Seeded issues** (generated with Part A, seed 84921): about 2% unparseable `DOB_TXT`;
orphan accounts; duplicate customers by name and date of birth; names in Tamil and
Devanagari scripts; empty and partially filled phone slots; one `PROD_CD` with no
v2 equivalent; pending payments and standing instructions at the freeze date.

**`golden.csv`**: the correct field mappings with patterns, plus the expected
decisions: `FAX_NO` → archive; `RISK_RATING` → derive from segment; `ACCRUED_INTEREST_MINOR`
→ recompute; `PENDING_PMT` → settle before freeze; `STANDING_INSTR` → migrate.

---

## 28. Part B build plan

Milestones map to the architecture roadmap's phases. Do not begin a milestone until
its tests pass; each phase gate is recorded as a sign-off or a recorded check.

| Milestone | Builds | Tests (§ 27.2) | Roadmap phase |
|---|---|---|---|
| **M8 — Graph and planes** | § 18 DDL + migrations; `kg/` store, bitemporal queries, PROV-O export; worker process and `job` handoff; role checks skeleton | M8 tests | Phase 1 |
| **M9 — Source intelligence** | § 20: inventory, profiling, sketches, semantic types, UCC/IND/FD, code mining, structure solve, entities, DQ report; Sources and Evidence screens | M9 tests | Phase 1 · gate: known keys and links recovered on one real system |
| **M10 — Grounded LLM** | § 21.6–21.7, § 21.9 golden harness, § 25.3 masking, § 20.8 calibration bands; provider interface with stub and real provider | M10 tests | Phase 1–2 |
| **M11 — Concepts and specs** | § 19 grammar and checks, decisions, compose to `MappingPlan`, `REALISES`/`MAPS_TO` claims; Concepts screen | M11 tests | Phase 2 |
| **M12 — Discovery and review** | § 21.1–21.5, 21.8: alignment, retrieval, patterns, transforms, assignment, bands, review order, examples; Mapping review screen | M12 tests | Phase 2 · gate: one version change fully specified, no open decisions |
| **M13 — Prove on synthetic data** | § 22.1–22.4: interpreter, executor, crosswalk, partitions; § 23.2–23.5, 23.7: differential, fixtures, metamorphic, ledger, mutation | M13 tests | Phase 3 · gate: zero diffs, zero unexplained rows |
| **M14 — Migrate** | § 22.5–22.9: sizing, cutover, delta, rehearsals and diff, PONR; § 23.6, 23.8: reconciliation, comparator, test pack; cleanse rules and reject triage; four-eyes; Migration, Reconcile and Sign-offs screens | M14 tests | Phase 4 · gate: dress rehearsal reconciles, fits the window, behaviour signed off |
| **M15 — Learn** | § 24: learned degrees and marginals, `learned()` generators, target-shaped data, privacy gate, fidelity report, transaction sequences, edge-pattern mining, volume scaling, versioned re-learning; Learned models screen | M15 tests | Phase 5 · gate: privacy audit passes; fidelity within thresholds once set |

---

## 29. Pending decisions, open questions and risks

### 29.1 Review findings not yet decided (built only as extension points)

| Finding | Extension point left in Part B | To build when decided |
|---|---|---|
| 6 — Downstream consumers | `JOINS_ON`/`READS` claims from code mining already record consumers | A consumer-impact report per changed field, with cutover action and test |
| 7 — History scope | `history <concept>: <scope>` parses; compiler records it as a `history_scope` decision | Archive target, tiered extraction, retention checks |
| 12 — Concept versioning | Concepts carry the model version they were compiled in | Concept change impact across realisations and migrations |
| 13 — Document gaps | — | Sponsor summary, effort and team sizing in the architecture doc |

### 29.2 Open questions from the architecture doc (answers change configuration, not design)

Typical table and row counts per version change; whether both codebases are
available (`code_location`); allowed freeze window; whether v1 has watermarks or
logs for delta; approved LLM deployment (in-perimeter or zero-retention API); who
owns concept definitions.

### 29.3 Part B decisions log (seed entries for `DECISIONS.md`)

- **D5 — Knowledge graph in Postgres, not a graph database.** Claims as rows give
  edge properties, competing hypotheses, provenance and bitemporal history. Revisit
  above about 10 million edges with open-ended interactive traversals.
- **D6 — Two executors, shared transform library only.** Independence of the oracle
  matters more than code reuse.
- **D7 — LLM proposes, data verifies.** No LLM output becomes an accepted claim
  without deterministic validation and, for mappings, human approval.
- **D8 — Behaviour equivalence is enabled, not executed.** DataForge compares
  outputs and gates on the sign-off; the v2 or UAT team runs the processes.
- **D9 — Masking before any LLM call.** Format-preserving, keyed, irreversible from
  the control plane.

### 29.4 Part B risks

| Risk | Mitigation in this design |
|---|---|
| A wrong spec passes differential tests (both paths read the spec) | Round trip, control totals, behaviour comparator, reviewer examples |
| Reviewer fatigue | Impact ordering, bulk approval only for high band, sign-off audit |
| Concept model sprawl | Concepts created only from aligned clusters in an active migration |
| LLM drift after a provider update | Pinned model ids; golden-set gate before any change |
| Data-plane approvals delay the programme | M8–M13 run on fixtures and synthetic rehearsals without production access |

---
---

# PART C — Agentic layer (DataForge 3.0)

## 30. Part C scope and principles

### 30.1 Goal

Let users create mock-data models and migrations by conversation. Specialist
agents connect to sources, draft concepts, realisations, rules and scenarios in
MDL, test them on synthetic samples, repair them, and ask people only what cannot
be inferred. A person can watch, steer, edit or take over at any point.

Every workflow starts from **system models**: the user uploads the DDL or JSON
Schema of each system, source and target, and the schema agent turns them into
DataForge systems, tables or documents, keys, links and flow order (§ 42). Mock
data and migration authoring build on those models; nothing starts from a blank page.

### 30.2 The governing rule

**Agents drive the deterministic core; they never replace it.** Every agent
action goes through the same tools a person uses: the compiler, the validator, the
sandbox test runner, the claim store, the decision table and the job queue. An
agent's output is only ever a *proposal*: an MDL commit on a workspace branch, a
`proposed` claim, a proposed decision option, or a question. Nothing an agent does
can accept a claim, decide a decision, sign off a gate, approve a job or touch the
data plane.

Authoring happens only in the **authoring tier**, on development machines that
hold no real data (§ 44). There, agents may also write and run scripts and
commands like a coding assistant (§ 43.5). Only MDL leaves the authoring tier, in a
signed promotion bundle that each runtime tier verifies by recompiling and
re-testing; runtime tiers run no agents and call no LLM.

### 30.3 Traceability

| Improvement agreed | Where it is specified |
|---|---|
| 1. Few agents, organised by job; migration is a workflow | § 31 |
| 2. Shared state through the model, not chat | § 32 |
| 3. Ask only what cannot be inferred | § 33 |
| 4. Separate critic agent | § 34 |
| 5. Test-first loops with bounded repair | § 35 |
| 6. Agents are modellers, never approvers | § 36 |
| 7. DataForge as tools over MCP | § 37 |
| 8. Durable orchestration | § 38 |
| Risk: prompt injection from data | § 39.1 |
| Risk: compounding errors | § 39.2 |
| Start from source and target models (DDL, JSON Schema) | § 42 |
| Read attached spreadsheets, e.g. mapping sheets; scripts and commands | § 43 |
| Authoring on development machines; only MDL is promoted | § 44 |
| Sequencing: one loop first | § 41: M16, then the schema agent loop (M17), before the rest |

### 30.4 Out of scope for Part C

- Agents acting in the data plane, holding credentials, or reading real rows.
- Agents approving, deciding, signing off or requesting production jobs.
- Autonomous runs with no human in the workspace: every workflow has a human owner.
- Agent-written code becoming part of a migration or generator. Agents deliver MDL
  only; executable code is generated by the compiler from approved MDL. Scripts and
  commands are allowed in the authoring tier (§ 43.5); they never travel in a
  promotion bundle.
- Agents, LLM calls, scripts or the MCP server in runtime tiers (§ 44).
- Multi-tenant or cross-bank agent sharing.

---

## 31. Agent roster (improvement 1)

Seven agents. System modelling, a migration or a mock-data model is a **workflow** the orchestrator
runs across them, not an agent of its own. Each agent has one job, a fixed tool
allow-list (§ 37.2) and a structured output contract.

| Agent | Job | Reads | Writes (always as proposals) | Stops when |
|---|---|---|---|---|
| **Orchestrator** | Plans the workflow, creates tasks, enforces gates, routes questions, tracks budgets | Workspace, task board, gates, decisions | Tasks, questions (routing only) | Workflow complete, or paused by the owner |
| **Intake** | Turns the user's goal into a scoped workspace; collects each system's schema files or connection profile; requests profiling where a connection exists; asks scope questions | User messages, schema uploads, approved connection profiles, profiles, DQ report | Workspace scope, system list, profile job requests, questions | Systems collected and scope recorded |
| **Schema** | Turns each uploaded DDL or JSON Schema into a DataForge system model; proposes keys, links, flow order, semantic types, generators and code-description valuesets | Schema IR, import issues, existing system models, valuesets | MDL system files, `proposed` claims, flow and valueset proposals, questions | Every schema element is covered or excluded with a reason, the model compiles, and a generated sample validates against the uploaded schema |
| **Modeller** | Drafts concepts and `realize from` / `realize into` blocks; aligns entities; turns attached mapping sheets into proposals (§ 43.3) | Evidence graph, profiles, concepts, examples, mapping-sheet rows, diagnostics, test reports | MDL commits, `proposed` claims | All mapped concepts compile and pass sandbox tests, or budget exhausted |
| **Rules** | Drafts cleanse rules, representation rules, cutover items, proposed decision options and reconcile rules | DQ report, decisions, cutover inventory, profiles | MDL commits, proposed options on decisions | Every open decision has at least one proposed option with evidence |
| **Critic** | Independently tries to break the spec | Compiled spec, concepts, profiles. **Never** the other agents' reasoning | Adversarial fixtures, findings | Fixture budget used, or no new failing case in two rounds |
| **Generator** | Authors Part A models for mock data: systems, links, valuesets, rules, scenarios, `learned()` references; produces samples and iterates with the user | Schema registry, learned models, scenarios, user feedback | MDL commits, sample runs | User accepts the sample, or budget exhausted |

Four workflows are defined in § 38.2. **SystemModelling** (Intake → Schema →
Critic) is the entry point: it turns schema files into approved system models.
**MigrationAuthoring** (Modeller → Rules → Critic, looping) and
**MockDataAuthoring** (Generator → Critic) both start by ensuring the systems they
need are modelled, running SystemModelling first when they are not.
**DriftRevision** re-runs the affected agents when a re-uploaded schema or a live
schema change touches an approved model or migration.

**Files, scripts and commands.** Intake, schema, modeller, rules and generator
agents read attachments through the file tools (§ 43.2). Schema, modeller, rules,
generator and critic agents may write and run scripts and shell commands in the
workspace under the authoring permission policy (§ 43.5). The modeller owns
mapping-sheet interpretation (§ 43.3).

Agent definitions live in `app/agents/definitions/<agent>.yaml`:

```yaml
name: modeller
version: 1.3.0                  # bump on any prompt, tool or contract change
model: ${LLM_MODEL_MODELLER}    # pinned model id from config
prompt: prompts/modeller.v7.md
tools: [graph.search, graph.neighbourhood, profiles.get, concepts.read,
        mdl.read, mdl.write, mdl.compile, sandbox.test, examples.read,
        files.read_workbook, mapping_sheet.interpret, code.run, shell.run, scratch.keep,
        claims.propose, question.ask]
output_contract: contracts/modeller_result.schema.json
budget: {max_iterations: 6, max_tool_calls: 80, max_tokens: 400000, max_minutes: 30}
```

---

## 32. Shared state: the workspace blackboard (improvement 2)

Agents never hand work to each other through conversation. They hand it over
through **durable, typed artifacts**: MDL files on a workspace branch, claims in
the evidence graph, decision rows, questions, and task briefs. Any agent task can
be restarted from its brief and the referenced artifacts alone.

### 32.1 Workspace

A **workspace** is one authoring effort: a migration or a mock-data model. It owns
a git branch in the model store (`agents/<workspace-slug>`), created from the
current approved model. Agents commit to the branch; humans can commit to it too.
The branch merges to the approved model only through human review (§ 36.4).

### 32.2 Tables

```sql
CREATE TABLE workspace (
  id UUID PRIMARY KEY,
  kind text NOT NULL,                        -- migration | mock_data
  name text NOT NULL,
  owner_user text NOT NULL,                  -- the human who launched it; ceiling for agent rights
  migration_id UUID REFERENCES migration(id),
  model_version_id UUID NOT NULL REFERENCES model_version(id),
  branch text NOT NULL, base_commit text NOT NULL, head_commit text,
  goal text NOT NULL,                        -- the user's goal, in their words
  scope jsonb NOT NULL DEFAULT '{}',         -- concepts, systems, volumes, history scope …
  status text NOT NULL DEFAULT 'active',     -- active | paused | waiting_human | ready_for_review |
                                             -- merged | abandoned
  workflow_id text,                          -- durable-orchestration handle (§ 38)
  UNIQUE (model_version_id, name));

CREATE TABLE agent_task (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  parent_id UUID REFERENCES agent_task(id),
  agent text NOT NULL, agent_version text NOT NULL,
  kind text NOT NULL,                        -- e.g. model_concept, realise_from, realise_into,
                                             -- draft_rules, critique, generate_sample
  brief jsonb NOT NULL,                      -- structured input, see § 32.3
  depends_on_claims UUID[] NOT NULL DEFAULT '{}',   -- gated claims this task builds on (§ 39.2)
  status text NOT NULL DEFAULT 'queued',     -- queued | running | waiting_human | done |
                                             -- failed | budget_exhausted | invalidated
  attempt int NOT NULL DEFAULT 1,
  budget jsonb NOT NULL, usage jsonb NOT NULL DEFAULT '{}',
  result jsonb,                              -- structured output, validated against the contract
  started_at timestamptz, finished_at timestamptz);

CREATE TABLE agent_step (                    -- every model call and tool call
  id UUID PRIMARY KEY,
  task_id UUID NOT NULL REFERENCES agent_task(id) ON DELETE CASCADE,
  seq int NOT NULL,
  kind text NOT NULL,                        -- model_call | tool_call | tool_result | note
  tool text, input jsonb, output_ref text,   -- large outputs stored by reference
  commit_sha text,                           -- set when the step changed the branch
  tokens_in int, tokens_out int, duration_ms int,
  untrusted_spans int NOT NULL DEFAULT 0,    -- count of untrusted blocks in context (§ 39.1)
  at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (task_id, seq));

CREATE TABLE question (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  task_id UUID REFERENCES agent_task(id),
  anchor_kind text NOT NULL,                 -- decision | claim | diagnostic | scope |
                                             -- import_issue | document_key | system_flow | system_boundary |
                                             -- sheet_layout | sheet_row
  anchor_id text NOT NULL,                   -- the row or diagnostic the question resolves
  kind text NOT NULL,                        -- choice | confirm | examples | free_text
  prompt text NOT NULL,
  options jsonb,                             -- for choice: [{value, label, evidence_ref}]
  evidence jsonb NOT NULL,                   -- what the agent already knows, with references
  impact int NOT NULL,                       -- downstream mappings affected (§ 21.8)
  status text NOT NULL DEFAULT 'open',       -- open | answered | withdrawn | superseded
  answer jsonb, answered_by text, answered_at timestamptz);

CREATE TABLE critic_finding (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  task_id UUID NOT NULL REFERENCES agent_task(id),
  spec_commit text NOT NULL,
  severity text NOT NULL,                    -- blocking | major | minor
  category text NOT NULL,                    -- see § 34.3
  description text NOT NULL,
  fixture_ref text,                          -- the failing fixture, stored in the workspace
  status text NOT NULL DEFAULT 'open',       -- open | fixed | disputed | accepted_risk
  resolution text, resolved_by text);
```

### 32.3 Task brief contract

A brief is JSON validated against `contracts/brief.schema.json`. It holds only
references and structured facts, never another agent's free-form reasoning:

```jsonc
{"workspace":"…","kind":"realise_into","concept":"Customer",
 "target_version":"CORE_V2",
 "inputs":{"concept_file":"concepts/customer.mdl@a41f9c0",
           "accepted_claims":["c-91…","c-92…"],
           "open_decisions":["d-17…"],
           "examples":["examples/name_split.csv"],
           "critic_findings":["f-4…"]},
 "acceptance":{"compile":"no errors","sandbox":"all fixtures pass",
               "coverage":"every mandatory CORE_V2 field for Customer is covered or decided"},
 "budget":{"max_iterations":6}}
```

### 32.4 Human edits are first-class

A person may edit any MDL file in the workspace through the Studio editor; the edit
is a commit on the branch with the person as author. Before each iteration, an
agent rebases on the branch head and re-reads the files it depends on. An agent
must not revert a human commit; if a human edit breaks compilation, the agent asks
rather than undoing it.

### 32.5 Changes to Part B tables

```sql
-- agents are a fourth agent kind on activities, and a new evidence kind
-- kg_activity.agent_kind: algorithm | model | human | agent
-- kg_evidence.kind: … | agent | declared | mapping_sheet | script
--   declared      = stated in an uploaded DDL or JSON Schema
--   mapping_sheet = a row of an attached mapping sheet (file, sheet, row)
--   script        = a script or command result (tool_run id and code hash)
ALTER TABLE eval_run ADD COLUMN kind text NOT NULL DEFAULT 'mapping';   -- mapping | agent
ALTER TABLE eval_run ADD COLUMN metrics jsonb NOT NULL DEFAULT '{}';    -- § 40.1 metrics
ALTER TABLE job ADD COLUMN requested_by_agent text;                     -- agent principal, if any
```

The value lists in Part B are enforced in code; extend them there.

---

## 33. Intake: ask only what cannot be inferred (improvement 3)

### 33.1 Flow

1. **Goal.** The user states the goal in plain language ("Migrate customers and
   accounts from LEGACY_V1 to CORE_V2 for the R3 cutover").
2. **Systems.** Intake lists the systems the goal needs and, for each, its role
   (source, target or standalone) and how it will be described: **uploaded schema
   files** (DDL in a named dialect, or JSON Schema, as files or a zip bundle; § 42)
   or an **approved connection profile** (§ 25.1), or both. Systems that already
   have an approved model are offered for reuse. Intake never accepts credentials
   in chat; a missing connection profile becomes a request to an administrator.
3. **Model and learn.** Uploaded files go to the schema agent through the
   SystemModelling workflow (§ 42). Where a connection exists, Intake also requests
   profiling and code mining (Part B § 20); the first profile of a new system version
   needs a human approval of the job. Without a connection, everything up to a
   synthetic rehearsal works from the schema files alone; data-dependent steps (DQ
   report, learned models, masked and dress rehearsals) wait for a connection.
4. **Scope.** From the DQ report and entity clusters, Intake proposes a scope (which
   concepts, history scope, volumes) as a `choice` question with evidence, rather
   than asking open questions.
5. **Hand off.** When the system models are merged and scope is answered, the
   orchestrator starts migration or mock-data tasks.

### 33.2 The question rules (enforced, not advisory)

`question.ask` (§ 37.2) rejects a question unless:

- **It is anchored.** `anchor_kind` and `anchor_id` point to an open decision, a
  claim in the low band or abstained, a blocking compiler diagnostic whose fix
  needs intent, a scope field, or a schema-import item (an import issue, a document
  with no key, an ambiguous system boundary or flow order; § 42.6). Free-floating
  questions are refused.
- **It is not derivable.** The tool runs a derivability check: if the anchor is a
  claim and the claim's evidence already meets the high-band rule, or if the anchor
  is a decision whose options are all eliminated but one by validated evidence, the
  question is refused with the reason, and the agent must record the inference as a
  proposal instead.
- **It carries evidence.** `evidence` lists what is already known, with references,
  so the person sees why it is being asked.
- **It offers choices where possible.** `free_text` is allowed only for scope goals
  and examples requests; everything else is `choice`, `confirm` or `examples`.

### 33.3 Batching and order

Open questions are shown in impact order (§ 21.8), at most five at a time per
workspace, grouped by concept. Answering a question re-runs the derivability check
on the rest, and questions that became derivable are withdrawn automatically.

### 33.4 Examples: good and refused

| Question | Outcome |
|---|---|
| "Which address is primary when `COMM_PREF` is empty? Options: MAILING › RESIDENTIAL › OFFICE (found in v1 code), RESIDENTIAL first, reject the row." Anchor: decision `d-21`. | Allowed |
| "What tables are in LEGACY_V1?" | Refused: no anchor; derivable from inventory |
| "Is `ACCT_MASTER.CUST_NO` a reference to the customer?" with containment 0.995, unique parent and a view join | Refused: claim already high band; propose instead |
| "Please give 5 examples of splitting `CUST_NAME` into first and last name." Anchor: diagnostic `ERR_LOSSY_UNRESOLVED`. | Allowed (`examples`) |

---

## 34. Critic agent (improvement 4)

### 34.1 Independence

The critic is the agent equivalent of the reference interpreter: its value comes
from not sharing the author's assumptions.

- Its context is built **only** from the compiled spec at a given commit, the
  concept model, profiles, the DQ report and the test fixtures already in the
  suite. It never sees the modeller's or rules agent's prompts, reasoning, steps or
  task results.
- It uses its own prompt and may be configured to use a different model
  (`LLM_MODEL_CRITIC`).
- It cannot write MDL. It writes fixtures and findings only.

### 34.2 What it produces

- **Adversarial fixtures**, as Part A scenario templates in the workspace
  (`fixtures/critic/<finding>.mdl`), each designed to make the spec fail an
  invariant: an unmapped code, a duplicate business key, a non-ASCII value at the
  maximum length, a date on a boundary, a missing parent, a partition boundary.
- **Findings** (`critic_finding`), each pointing at the failing fixture and the
  invariant or rule it breaks. A finding without a reproducing fixture is allowed
  only for category `ambiguity`, and is then routed as a question.

### 34.3 Finding categories

`uncovered_value` (a source value with no mapping), `invariant_break` (ledger,
round trip, one-primary rule), `fit` (value does not fit target type),
`grain` (unexpected row multiplication or loss), `temporal` (interval or time-zone
errors), `money` (control total or rounding), `ambiguity` (two readings of a rule).

### 34.4 Resolution protocol

1. Each blocking or major finding becomes a task for the modeller or rules agent,
   with the fixture attached.
2. The author agent may fix the spec, or **dispute** the finding with evidence.
3. If the critic still reproduces the failure after two rounds, or the author
   disputes it, the orchestrator raises a question to the human owner with both
   positions.
4. Accepted fixtures join the workspace's permanent test suite once the branch is
   merged; they become regression tests for every future revision.

### 34.5 Measuring the critic

The agent evaluation suite (§ 40) seeds known faults into fixture migrations and
measures the critic's **catch rate**. A new critic version cannot be deployed if
its catch rate falls below the last accepted version.

---

## 35. Test-first loops with bounded repair (improvement 5)

### 35.1 The sandbox runner

Agents test drafts that are not yet approved, so they cannot use rehearsals (the
data-plane worker refuses unapproved specs, § 25.1, and that does not change). A
**sandbox runner** runs in the control plane on synthetic data only:

```python
# app/sandbox/runner.py
def sandbox_test(workspace_id: UUID, commit: str, scope: SandboxScope) -> TestReport
```

- Compiles the workspace branch at `commit`.
- Builds fixtures from the Part A scenario engine using the source version's
  learned or declared model, plus the workspace's example files and critic fixtures.
- Runs the reference interpreter and the production executor's transform path on
  the fixtures, then the differential check, the ledger check, the Part B
  invariants and the example assertions.
- Never opens a connector. Has no network access. Target: under 60 seconds on the
  Part B fixture.

`TestReport` is structured:

```jsonc
{"commit":"…","compile":{"errors":[…],"warnings":[…]},
 "examples":{"passed":12,"failed":[{"file":"name_split.csv","row":4,
             "expected":{"FIRST_NM":"Ananya"},"actual":{"FIRST_NM":"Ananya R."}}]},
 "differential":{"diffs":0},
 "ledger":{"unexplained":0},
 "invariants":[{"name":"one_primary_address","status":"fail","violations":3,
                "sample_fixture_keys":["SYN-00412"]}],
 "regressions":[]}
```

### 35.2 Loop state machine (schema, modeller, rules and generator agents)

```
PLAN → WRITE_EXPECTATIONS → WRITE_MDL → COMPILE → SANDBOX_TEST → DONE
                                ↑                        │ fail
                                └──── DIAGNOSE ← REPAIR ←┘
```

- **WRITE_EXPECTATIONS first.** Before writing MDL, the agent records what must
  hold: example rows (from users or derived from accepted claims), invariants
  for the concept (one primary address, counts per grain rule), and coverage targets.
  These are committed as test files, so the spec is written to pass them, not the
  other way round.
- **DIAGNOSE** reads only structured outputs: compiler diagnostics (code, location,
  related nodes, hint) and the `TestReport`. Free-text log scraping is not allowed.
- **REPAIR** commits a change with a message naming the diagnostic or failing test
  it addresses.

### 35.3 Stopping rules

The loop stops and asks a human when any of these is true:

| Rule | Detection |
|---|---|
| Budget exhausted | Iterations, tool calls, tokens or minutes over the agent's budget |
| No progress | The set of failing diagnostics and tests is identical to two iterations ago |
| Regression | A test that passed at an earlier commit now fails; the agent must revert its own last commit first |
| Disagreement with evidence | The only remaining fix contradicts an accepted claim or a human commit |

On stopping, the agent writes a **stop report** into its task result: the attempts,
the remaining failures, and its best hypothesis; the orchestrator turns it into an
anchored question.

### 35.4 Compiler diagnostic additions

Extend `Diagnostic` (§ 5.3) with `related: list[str]` (node ids or file positions)
and `hint: str | None` (a deterministic suggestion, e.g. "add `by_example` or a
`lossy_expression` decision"). Agents rely on these; people benefit too.

---

## 36. Roles, delegation and governance (improvement 6)

### 36.1 Agent principals

Each agent task runs as the principal `agent:<name>@<version>` with role
**modeller** (§ 25.2). Agents can never hold reviewer, data owner, approver,
operator, behaviour owner or auditor roles.

### 36.2 Delegation ceiling

An agent acts on behalf of the workspace owner. Its effective permissions are the
**intersection** of the modeller role and the owner's own permissions: an agent
started by someone without access to a system version cannot read it either.

### 36.3 What agents may and may not do

| Action | Agent | Notes |
|---|---|---|
| Read graph, profiles, DQ report, concepts, MDL | Yes | Within the delegation ceiling |
| Commit MDL to its workspace branch | Yes | Never to the approved model |
| Propose claims; add evidence of kind `agent` | Yes | Status always `proposed` |
| Propose options on a decision | Yes | Never set `choice` |
| Ask questions | Yes | Subject to § 33.2 |
| Run sandbox tests | Yes | Synthetic only |
| Request a profiling job | Yes | First profile of a version needs human approval |
| Write and run scripts and shell commands in the workspace | Yes | Authoring tier only, under the permission policy; anything outside it asks the developer (§ 43.5) |
| Request rehearsal or migration jobs | No | Humans only |
| Request or approve promotion | No | Humans only (§ 44.5) |
| Accept or reject claims, decide decisions, sign off, approve jobs | No | Humans only |
| Merge a branch | No | Humans only, § 36.4 |

`governance/roles.py` enforces this table; the tool layer (§ 37) calls it on every
invocation, so the rule holds whether a tool is called in-process or over MCP.

### 36.4 Merge review and four-eyes

- A workspace reaches `ready_for_review` when its acceptance criteria pass and no
  blocking critic finding is open.
- The Studio shows the branch diff (MDL), new claims, proposed decision options,
  critic findings and the last `TestReport`. A reviewer accepts or rejects claims
  and decisions there, then merges.
- **Four-eyes on agent work:** the workspace owner may review claims their agents
  proposed, but the `mapping_spec` sign-off for a migration produced by a workspace
  must come from someone other than the workspace owner. The owner launched the
  agents, so they count as an author.

### 36.5 Audit

Every agent step is a `kg_activity` row with `agent_kind = 'agent'`, `agent_id` =
the agent name, `agent_version` = agent definition version + prompt version + model
id. Evidence written by agents uses kind `agent` and links to the step. The PROV-O
export (§ 25.4) therefore shows which agent proposed what, under whose workspace,
and which human accepted it.

---

## 37. Tool layer and MCP server (improvement 7)

### 37.1 One registry, two transports

All agent capabilities are **tools** in a single registry, `app/tools/registry.py`.
The same registry serves two transports:

- **In-process**, for DataForge's own agents (no network hop, same audit).
- **MCP server** (`app/mcp_server/`), for external clients such as Claude Code or
  the bank's own assistants, using the official MCP Python SDK. Transports: stdio
  for local use, streamable HTTP inside the bank perimeter. The MCP server runs in
  the control plane only.

```python
@tool(name="mdl.compile", effect="read", roles={"modeller","reviewer","approver"})
def mdl_compile(ctx: ToolContext, workspace_id: UUID, commit: str | None = None) -> CompileResult: ...
```

Every tool declares its `effect` (`read`, `propose`, `request`, `decide`) and the
roles allowed. `decide` tools exist for human clients only; no agent principal can
ever hold a role that permits them.

### 37.2 Tool catalogue (v1)

| Tool | Effect | Purpose |
|---|---|---|
| `graph.search`, `graph.neighbourhood` | read | Find nodes; k-hop subgraph with claims and bands |
| `profiles.get`, `dq.report` | read | Aggregate profiles; data-quality report |
| `concepts.read`, `mdl.read`, `mdl.diff` | read | Model files and diffs on a workspace branch |
| `mdl.write` | propose | Write or patch an MDL file on the workspace branch (one commit per call) |
| `mdl.compile` | read | Compile a commit; returns diagnostics with hints |
| `discover.run` | propose | Run Part B mapping discovery for a concept |
| `sandbox.test` | read | § 35.1 |
| `fixtures.generate` | propose | Add a fixture template to the workspace |
| `examples.read`, `examples.request` | read / propose | Read example files; ask for examples (via `question.ask`) |
| `claims.propose` | propose | Create a proposed claim with agent evidence |
| `decisions.list`, `decisions.propose_option` | read / propose | Read decisions; add an option with evidence |
| `question.ask`, `question.withdraw` | propose | § 33.2 |
| `critic.file_finding` | propose | Critic only |
| `samples.generate` | read | Part A engine at small volume (≤ 1,000 roots) on synthetic data, for the generator agent |
| `jobs.request_profile` | request | Profiling job (approval rule in § 36.3) |
| `schema.import` | propose | Parse uploaded DDL or JSON Schema deterministically into the Schema IR; returns import issues (§ 42.2) |
| `schema.ir.read` | read | Read a parsed Schema IR with source locations |
| `schema.coverage` | read | Compare an MDL system file with its IR; list uncovered elements |
| `schema.validate_sample` | read | Generate a small sample from a draft model in the sandbox and validate it against the uploaded schema (§ 42.7) |
| `systems.propose_flow` | propose | Propose flow ordering between systems |
| `valuesets.propose` | propose | Propose a valueset and its column bindings |
| `files.list` | read | Attachments in the workspace with kind, scan result and status |
| `files.read_workbook` | read | Structured read of an `.xlsx` or `.csv` attachment: sheets, detected tables, headers, values, formulas, comments, dropdown lists, hidden flags (§ 43.2) |
| `files.read_range` | read | One sheet range, for large sheets |
| `mapping_sheet.interpret` | propose | Turn a mapping sheet into normalised rows, resolved references, translated rules and proposed claims (§ 43.3) |
| `mapping_sheet.export` | read | Write the reviewed mapping back to Excel in the original layout with added status columns |
| `code.run` | propose | Write a script to the task's scratch folder and run it under the permission policy (§ 43.5) |
| `shell.run` | propose | Run a command in the workspace under the permission policy |
| `scratch.keep` | propose | Keep a scratch script under `tools/` for reuse |
| `promotion.request`, `promotion.approve` | decide | Human clients only (§ 44.5) |
| `bundle.verify` | read | Runtime tiers: verify a promotion bundle (§ 44.5) |
| `claims.review`, `decisions.decide`, `signoffs.record`, `jobs.approve`, `workspace.merge` | decide | Human clients only |

### 37.3 MCP specifics

- **Authentication:** every MCP session maps to a bank user identity; tool calls
  run under that user's roles. An external agent connected over MCP is therefore
  bound by exactly the same rules as a DataForge agent.
- **Resources:** MDL files, test reports and the DQ report are exposed as MCP
  resources (read-only) under `dataforge://workspace/<id>/…`.
- **Untrusted output marking:** tool results that contain source-derived text are
  returned with the § 39.1 untrusted markers, for internal and external clients
  alike.
- No tool reaches the data plane. `jobs.request_*` only inserts a `job` row.

---

## 38. Durable orchestration (improvement 8)

### 38.1 Engine

Agent workflows can wait days for a human answer, a profiling job or a review.
They run on **Temporal** (self-hosted, Python SDK), behind an interface so the
engine can be swapped:

```python
# app/orchestration/runner.py
class DurableRunner(Protocol):
    def start(self, workflow: str, workspace_id: UUID) -> str: ...    # returns workflow_id
    def signal(self, workflow_id: str, name: str, payload: dict) -> None: ...
    def pause(self, workflow_id: str) -> None: ...
    def resume(self, workflow_id: str) -> None: ...
```

If Temporal is not approved for deployment, implement `PostgresRunner` on the
`agent_task` table and a resumable state machine; workflow definitions stay the
same. Record the choice in `DECISIONS.md`.

Rules for workflow code: workflows are deterministic and contain no model or tool
calls. Every agent task runs as a Temporal **activity** with heartbeats; model and
tool calls happen inside activities only. Retries apply to infrastructure failures;
`budget_exhausted` and `no_progress` are non-retryable.

### 38.2 Workflows

**SystemModelling** (the entry point)

```
intake: systems, roles, formats ─► wait: files uploaded (signal per system)
       ─► per upload: schema.import (deterministic) ─► blocking import issues → questions
       ─► per system, in parallel: schema: model_system
       ─► schema: link_systems (cross-system links, flow order) once every system compiles
       ─► critic: critique_models
       ─► wait: open questions answered
       ─► ready_for_review ─► wait: merge (signal) ─► register system versions (§ 42.8)
```

**MigrationAuthoring**

```
intake: goal, source and target
       ─► ensure_models(source, target): reuse approved versions, else run
          SystemModelling as a child workflow and wait for its merge
       ─► wait: scope answered (and profiles done, where a connection exists)
       ─► modeller: propose_concepts (§ 38.3) ─► critic: critique_concepts
       ─► gate: concept set, entity alignment and key strategies accepted by a
          human in ONE review (§ 39.2)
       ─► for each concept in dependency order:
            ─► modeller: realise_from ─► modeller: realise_into
            ─► rules: draft_rules for the concept
       ─► critic: critique (whole spec)
       ─► loop findings → author tasks (max 2 rounds per finding) → critic
       ─► wait: open questions answered (signals)
       ─► workspace status = ready_for_review ─► wait: merge (signal)
```

**MockDataAuthoring**

```
intake: goal, systems ─► ensure_models(systems)
       ─► generator: draft scenarios, rules and links on the system models
       ─► samples.generate ─► show sample to user
       ─► loop: user feedback (signal) → generator revises → new sample
       ─► critic: critique (rules, fit, scenario coverage)
       ─► ready_for_review ─► wait: merge
```

**DriftRevision** — started when a re-uploaded schema file or Part A / Part B drift
detection changes a system that approved models or migrations depend on: re-runs
the schema agent for the changed system, then the affected modeller or generator
tasks and the critic on a new branch, then waits for review.

### 38.3 Concepts are drafted, never asked for

The user is never asked to create or write a concept. Concepts are a modeller
output, derived from the two approved system models, not an input to the workflow.

`propose_concepts(source_model, target_model, attachments)` runs once per
migration, after `ensure_models`, and:

1. **Reuses** concepts already in the repository (`concepts/*.mdl`, approved in an
   earlier migration) whose `realize` blocks reference either system; reused
   concepts are only re-aligned, not redrafted.
2. **Clusters** each model into entities (tables or document roots plus their
   shredded children, § 42.4) and runs entity alignment (§ 21.2) between source
   and target clusters.
3. **Drafts one concept per aligned group.** The concept takes the target's shape
   by default (the target is the durable model), with attributes that exist only
   in the source added so nothing is silently dropped. Splits (1 source → n
   target) and merges (n → 1) become one concept with several realisations.
   Clusters that align with nothing become `unmapped_source` / `missing_target`
   candidates, not concepts.
4. **Uses a mapping sheet** (§ 43.3) when one is attached: its entity-level rows
   are strong evidence for the grouping (D18).
5. **Proposes key strategy** per concept (carry, crosswalk or regenerate) and the
   dependency order, from the link graph of both models.
6. Writes `concepts/*.mdl` to the workspace branch through `mdl.write`, compiles,
   and records `REALISES` and key-strategy claims as **gated**.

The human then reviews the whole concept set on one screen (Concepts view): rename,
merge, split or reject a concept, and accept alignments and key strategies. Only
accepted concepts enter the per-concept loop. Asking the user to author a concept is
a refused question (§ 33.2: derivable from the models).

### 38.4 Signals and timers

Signals: `question_answered`, `examples_uploaded`, `human_commit`,
`claim_reviewed`, `job_finished`, `sample_feedback`, `pause`, `resume`,
`merge`, `abandon`. Timers: remind the owner after 2 working days of waiting;
escalate to the project lead after 5; neither changes the work.

---

## 39. Safety

### 39.1 Prompt injection from data

Source metadata is attacker-reachable: anyone who can create a column comment, a
stored procedure, a document or a data value can write text an agent will read.

1. **Untrusted marking.** `llm/grounding.py` wraps every span derived from source
   systems (names, comments, view and procedure text, masked samples, uploaded
   documents, critic-visible fixtures) in nonce-delimited blocks with provenance,
   for example `<<untrusted id=8f2c source=LEGACY_V1.CUST_MASTER.comment>> … <<end 8f2c>>`.
   The agent system prompts state that text inside these blocks is data and never
   instructions.
2. **Least privilege, by tier.** Agents have no credentials and no `decide` tools.
   In the authoring tier they may run scripts and commands under the permission
   policy of § 43.5, with runtime tiers unreachable; runtime tiers run no agents at
   all (§ 44). The worst a manipulated agent can do is propose something wrong on
   its own branch or damage its own scratch space, which the compiler, tests,
   critic, human review and the promotion gate stand between.
3. **Argument provenance checks.** Tools that change state (`mdl.write`,
   `claims.propose`, `decisions.propose_option`) reject arguments that reference
   node ids not present in the task's grounded context, and refuse writes outside
   the workspace's scope.
4. **Instruction-like content flag.** The profiler and code miner flag metadata
   that reads like instructions to a model ("ignore", "you must", role-play cues,
   tool names). Flagged spans are shown to reviewers and still marked untrusted.
5. **Canary tests.** The agent evaluation suite includes a fixture with malicious
   comments and values; the test passes only if no claim, decision option or MDL
   change is influenced by them (§ 40.2).

### 39.2 Compounding errors

1. **Gated claims.** Entity alignments (`MEMBER_OF_ENTITY`, concept-level
   `REALISES`) and key strategies (`key_regeneration` mappings, crosswalk
   identity) are **gated**: the orchestrator does not start downstream tasks for a
   concept until a human has accepted them.
2. **Dependency tracking.** Each task records the claims it built on
   (`depends_on_claims`). If one of those claims is later rejected or superseded,
   every dependent task is marked `invalidated`, its commits are flagged in the
   branch, and the orchestrator re-plans those tasks.
3. **Small blast radius.** Agents work one concept at a time, in dependency order,
   so an error stays within a concept until review.

---

## 40. Agent evaluation

### 40.1 Trajectory evaluation

Extend the golden set (Part B § 21.9) from single mappings to whole workflows.
`app/agents/eval/` runs a workflow end to end on a fixture migration with a
**simulated human** that answers questions from `golden.csv` and the expected
decisions, and records:

| Metric | Meaning |
|---|---|
| Mapping accuracy | Approved-equivalent mappings matching golden, per pattern |
| Questions asked | Count, and the share that were necessary (anchored to a golden decision or a genuinely ambiguous claim) |
| Refused questions | Questions the derivability check refused (should trend down) |
| Iterations and tokens | Per concept, per agent |
| Critic catch rate | Share of seeded faults found with a reproducing fixture |
| Canary result | Pass or fail (§ 39.1) |
| Human edits needed | Commits the simulated human had to make |

### 40.2 Fixtures for agent evaluation

- The Part B fixture `legacy_v1_to_core_v2`.
- An **address fixture**: three fixed address column groups with a preference flag
  in v1, and a primary element plus `others[]` array in v2 (the case in the
  architecture review).
- A **seeded-faults** variant of each, with documented faults for the critic.
- A **canary** variant with injected instructions in column comments, a view
  definition and sample values.
- **Schema-import fixtures** (`samples/schema_import/`, § 42.10): LEGACY_V1 as
  Oracle, PostgreSQL and SQL Server DDL; CORE_V2's customer as a JSON Schema bundle
  with `$ref`s and the primary-plus-`others[]` address structure; a three-system DDL
  set (core banking, cards, payments) for mock data; and a canary JSON Schema with
  instructions hidden in `description` fields.

### 40.3 Gate

An agent definition version, prompt version or model change is deployable only if
its evaluation run is no worse than the last accepted run on mapping accuracy and
critic catch rate, the canary passes, and questions asked do not rise by more than
a configured margin. Results are stored in `eval_run` with `kind = 'agent'`.

---

## 41. Repository, API, UI, tests and build plan

### 41.1 Repository additions

```
backend/app/
├── agents/
│   ├── runtime.py              # tool-calling loop over LLMProvider; budgets; stop rules
│   ├── definitions/            # orchestrator, intake, schema, modeller, rules, critic, generator (.yaml)
│   ├── prompts/                # versioned system prompts per agent
│   ├── contracts/              # brief and result JSON schemas
│   ├── loop.py                 # § 35.2 state machine shared by authoring agents
│   ├── critic.py               # context builder enforcing § 34.1 isolation
│   └── eval/                   # trajectory evaluation, simulated human, fixtures
├── importers/                  # extends Part A § 7.9
│   ├── schema_ir.py            # Schema IR dataclasses with source spans (§ 42.3)
│   ├── ddl_importer.py         # sqlglot, per dialect, with fallback CREATE TABLE parse
│   ├── jsonschema_importer.py  # drafts 07, 2019-09, 2020-12; in-bundle $ref resolution
│   ├── shred.py                # documents → root and child containers (§ 42.4)
│   ├── typemap.py              # dialect and JSON types → DataForge dtypes
│   └── coverage.py             # IR ↔ MDL coverage check
├── files/
│   ├── workbook.py             # xlsx/csv reader: tables, merged cells, headers, formulas (§ 43.2)
│   ├── scan.py                 # sensitive-value scan and format-preserving masking
│   └── layouts.py              # sheet layout detection and saved layouts
├── mapping_sheet/
│   ├── interpret.py            # rows → normalised MappingRow (§ 43.3)
│   ├── rules.py                # rule-text classification and translation to MDL expressions
│   ├── resolve.py              # fuzzy resolution of names against system models
│   └── export.py               # write-back in the original layout
├── scratch/
│   ├── runner.py               # code.run, shell.run, scratch folders and cleanup (§ 43.5)
│   ├── permissions.py          # policy evaluation: allow, ask, deny; permission cards
│   └── os_sandbox.py           # bubblewrap, Seatbelt or container wrapper
├── promotion/
│   ├── bundle.py               # deterministic bundle build (§ 44.4)
│   ├── sign.py                 # client for the build service's signing step
│   └── verify.py               # runtime verification: signature, recompile, test re-run
├── intel_pack/
│   ├── export.py               # runtime data plane: aggregates-only pack (§ 44.3)
│   └── import_pack.py          # authoring tier: verify and load read-only
├── modelling/
│   ├── heuristics.py           # deterministic generator, link, flow and valueset proposals (§ 42.5)
│   ├── validate_sample.py      # IR constraints, DuckDB load, jsonschema validation (§ 42.7)
│   └── register.py             # merge-time registration of versions, registry rows, claims (§ 42.8)
├── tools/
│   ├── registry.py             # @tool decorator, effect and role checks
│   └── catalogue/              # one module per tool family (§ 37.2)
├── mcp_server/                 # MCP transport over the registry
├── sandbox/runner.py           # § 35.1
├── orchestration/
│   ├── runner.py               # DurableRunner protocol
│   ├── temporal_runner.py      # workflows and activities
│   ├── postgres_runner.py      # fallback
│   └── workflows/              # system_modelling, migration_authoring, mock_data_authoring, drift_revision
└── workspace/
    ├── branches.py             # git branch per workspace, rebase, human-commit detection
    └── questions.py            # anchoring, derivability, batching (§ 33)
samples/agent_eval/             # address, seeded-faults and canary fixtures (§ 40.2)
samples/schema_import/          # DDL and JSON Schema fixtures (§ 42.10)
samples/attachments/            # mapping-sheet and canary workbooks (§ 43.8)
deploy/
├── authoring/                  # workstation docker-compose; shared dev server variant (§ 44.2)
└── runtime/                    # SIT, UAT, pre-prod and prod profiles: no agents, no LLM
```

`LLMProvider` (§ 21.6) gains a tool-use method; `StubProvider` gains scripted
tool-call sequences so every Part C test runs without a real model:

```python
class LLMProvider(Protocol):
    def run_tools(self, system: str, messages: list[dict], tools: list[ToolSpec],
                  max_tokens: int) -> ModelTurn: ...    # text and/or tool calls
```

### 41.2 API additions

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/workspaces` | `{kind, goal}` → creates workspace and starts the workflow |
| `GET` | `/workspaces/{id}` | Status, scope, branch head, task board, gates |
| `POST` | `/workspaces/{id}/messages` | User message to the orchestrator (routed as a signal) |
| `POST` | `/workspaces/{id}/pause` · `/resume` · `/abandon` | Steering |
| `GET` | `/workspaces/{id}/questions` · `POST /questions/{id}/answer` | Question queue |
| `GET` | `/workspaces/{id}/tasks/{taskId}/steps` | Timeline of model and tool calls |
| `GET` | `/workspaces/{id}/findings` · `PATCH /findings/{id}` | Critic findings |
| `GET` | `/workspaces/{id}/samples/{n}` | Generator samples with validator report |
| `POST` | `/workspaces/{id}/systems` | `{name, role, format, dialect?, version_label}` plus files (`.sql`, `.json`, or a `.zip` bundle) → a `schema_upload` |
| `GET` | `/workspaces/{id}/systems` | Uploads with parse status, issue counts and modelling progress |
| `GET` | `/schema-uploads/{id}/ir` · `/schema-uploads/{id}/issues` | Parsed IR with source locations; import issues |
| `POST` | `/workspaces/{id}/attachments` | Upload `.xlsx` or `.csv` (kind optional; detected) → scanned, masked attachment |
| `GET` | `/workspaces/{id}/attachments` · `/attachments/{id}/scan` | Attachments; scan findings (masked cells, hidden sheets) |
| `POST` | `/attachments/{id}/layout` | Confirm or correct a detected sheet layout; optionally save it for reuse |
| `GET` | `/attachments/{id}/rows` | Normalised mapping rows with outcomes |
| `POST` | `/workspaces/{id}/mapping-sheet/export` | Download the reviewed mapping as Excel |
| `GET` | `/workspaces/{id}/scripts` · `/scripts/{id}` | Scripts and commands run, with code, permission decision, result and resource use |
| `GET` | `/workspaces/{id}/permission-requests` · `POST /permission-requests/{id}` | Pending permission cards; `{allow_once \| allow_workspace \| deny}` |
| `POST` | `/workspaces/{id}/promotions` · `POST /promotions/{id}/approve` · `GET /promotions/{id}` | Build, approve and inspect a promotion bundle (authoring tier) |
| `POST` | `/bundles` · `GET /bundles/{id}` | Runtime tiers: submit a signed bundle for verification; acceptance report |
| `POST` | `/intelligence-packs` | Authoring tier: import a signed intelligence pack |
| `POST` | `/workspaces/{id}/merge` | Human merge after review |
| `POST` | `/eval/agent-runs` | Trajectory evaluation |

### 41.3 UI: Agent workspace screen

Part A design tokens and chrome apply. Layout, wide screens: three columns that
stack on a phone.

- **Systems step** (the first step of every workspace): one card per system with
  name, role (source, target or standalone) and description method: DDL with a
  dialect picker, JSON Schema, or an approved connection profile, with a drop zone
  for files or a zip bundle. Systems with an approved model show "Reuse v3" instead.
  After parsing, each card opens a tree of tables or documents, arrays and columns
  with types and lengths; badges distinguish declared from inferred keys and links;
  import issues are listed with file and line. A cross-system view shows proposed
  links and the flow order, and the sample tab shows generated rows or documents
  with the result of validating them against the uploaded schema.
- **Conversation** (left): the user's goal, messages, and the question queue
  rendered as choice cards with evidence; answering a card sends the signal.
- **Plan and progress** (centre): the workflow as a task board, with each task's
  agent, status, iteration count and budget used; gates shown as locked steps
  with "Review alignment" actions; a timeline of agent steps per task.
- **Attachments** (in the Systems step and the conversation): drop `.xlsx` or `.csv`
  files; each shows its detected kind, the masked-cell warning if any, hidden
  sheets, and for mapping sheets the detected layout as a confirmable column-role
  strip ("A: source table · B: source column · … · F: rule"). Below it, a row table
  with each row's outcome (translated, conflict, unresolved, decision, not migrated)
  and a link to the claim or decision it produced. An "Export to Excel" action
  writes the reviewed mapping back in the original layout.
- **Artifacts** (right): tabs for MDL diff on the branch, latest `TestReport`,
  sample rows (mock-data), critic findings, and proposed claims.
- **Controls:** Pause, Resume, Take over (pauses agents and opens the MDL editor on
  the branch), Send to review, Merge (reviewer only), Abandon.
- **Mock-data loop:** the sample tab shows generated rows with per-column
  annotations; the user can comment on a column or row ("salary credits should be
  monthly", "add dormant NRI accounts"), which is sent as `sample_feedback`.

A **Scripts** tab in Artifacts lists every script and command an agent ran: purpose,
code or command line, permission decision, result and run time, with Re-run, Keep
and Download actions for people, like a coding assistant's tool log. When a call
needs permission, a card in the conversation shows the exact command, path or host
with **Allow once**, **Allow for this workspace** and **Deny**.

A **Promotion** screen (authoring tier) shows a bundle's contents (MDL files, tests,
evidence summary), its spec hashes, who requested and approved it, and its
acceptance status in each runtime tier.

Existing screens gain small hooks: Mapping review shows which items an agent
proposed, and for sheet-derived items the source ("Mapping v4.xlsx › Customer ›
row 37"); Evidence shows agent evidence and the step that wrote it.

### 41.4 Named acceptance tests

| Milestone | Test | Asserts |
|---|---|---|
| M16 | `test_tool_roles_enforced` | An agent principal calling any `decide` tool is refused, in-process and over MCP |
| M16 | `test_mcp_same_rules` | An MCP session as a reviewer can review claims; as a modeller it cannot |
| M16 | `test_sandbox_no_network` | The sandbox runner cannot open sockets or connectors |
| M16 | `test_sandbox_report_structured` | A failing example and a failing invariant appear in `TestReport` with fixture keys |
| M16 | `test_untrusted_marking` | Source-derived text in tool results is wrapped with nonce markers |
| M17 | `test_ddl_import_dialects` | The LEGACY_V1 fixture in Oracle, PostgreSQL and SQL Server DDL parses to the same IR: types, lengths, keys, foreign keys, CHECK lists and comments |
| M17 | `test_ddl_issues_reported` | An unsupported statement and an unsupported type become import issues with file and line; nothing is skipped silently |
| M17 | `test_jsonschema_refs` | Local and in-bundle `$ref`s resolve; a remote `$ref` is refused as an import issue |
| M17 | `test_jsonschema_shredding` | Nested objects flatten with paths; arrays of objects become child containers with ordinals and item bounds; `oneOf` with a discriminator becomes variants with rules |
| M17 | `test_schema_coverage` | Every IR element is in the MDL or excluded with a reason; deleting a column from the MDL fails the check |
| M17 | `test_declared_vs_inferred` | Declared keys register as accepted with `declared` evidence on merge; inferred links stay proposed and never exceed the medium band without data or human evidence |
| M17 | `test_sample_validates_ddl` | A generated sample satisfies every IR constraint and loads into DuckDB from the transpiled DDL |
| M17 | `test_sample_validates_json` | Reassembled documents validate against the uploaded JSON Schema |
| M17 | `test_code_desc_valueset` | `ENTITY_CODE` and `ENTITY_DESC` produce one valueset proposal binding both columns |
| M17 | `test_cross_system_flow` | Three uploaded systems produce cross-system links and a flow-order proposal; a cycle raises a `system_flow` question |
| M17 | `test_reimport_new_version` | Re-uploading a changed DDL creates a new version with drift items; the frozen version is untouched |
| M17 | `test_schema_agent_loop` | With the stub script, the schema agent commits coverage expectations before MDL and finishes with a compiling model and a validating sample |
| M18 | `test_modeller_test_first` | Test files are committed before the first MDL commit in a task |
| M18 | `test_modeller_fixture_customer` | With the stub provider script, Customer `from`/`into` compile and pass sandbox tests |
| M18 | `test_stop_no_progress` | Identical failures two iterations apart stop the loop with a stop report |
| M18 | `test_stop_regression_reverts` | A regression causes the agent to revert its own commit before stopping |
| M18 | `test_human_commit_respected` | The agent never reverts a human commit and asks when one breaks compilation |
| M18 | `test_workspace_restart` | Killing a task mid-loop and restarting from its brief reaches the same result |
| M19 | `test_workbook_reader` | Merged cells, two-row headers, formulas (cached value and formula text), comments, dropdown lists and hidden sheets are read into the structured result |
| M19 | `test_sensitive_cells_masked` | PAN, account and card-like values in a sample-value column are masked; the stored copy holds only masked values; the uploader is told which cells |
| M19 | `test_layout_detection_and_reuse` | The first sheet raises one `sheet_layout` question; a second sheet with the same headers uses the saved layout with no question |
| M19 | `test_rule_classification` | Fixture rules of every kind in § 43.3 are classified correctly |
| M19 | `test_code_tab_to_valueset` | A code-mapping tab becomes a valueset with its tuples and the mapping row references it |
| M19 | `test_sheet_resolution` | A misspelt column resolves with fuzzy-match evidence; a non-existent column is reported with sheet and row |
| M19 | `test_sheet_conflict_flagged` | A row whose types cannot fit becomes a `conflict` with both positions, neither dropped nor accepted |
| M19 | `test_sheet_coverage_report` | Missing mandatory targets, unmapped sources, duplicate targets and TBD rows are reported; TBD rows become decisions |
| M19 | `test_mapping_export_roundtrip` | Export keeps the original layout and adds status columns; re-importing it changes nothing |
| M19 | `test_dev_permissions_policy` | Writing in the workspace is allowed; reading `~/.ssh` is denied; an unknown host raises a permission card; a runtime-tier host is denied; agents cannot edit `.dataforge/` |
| M19 | `test_scratch_cleanup_and_keep` | A task's scratch folder is deleted when it ends; a kept script moves to `tools/`; every run is in `tool_run` |
| M19 | `test_script_generated_mdl` | MDL written by a script enters the branch only through `mdl.write`, and is refused there if it does not compile |
| M19 | `test_no_runtime_reach` | The authoring tier holds no runtime credentials, and connections to configured runtime hosts are denied |
| M19 | `test_code_run_disabled` | With `code.run` disabled, mapping-sheet interpretation still completes through the deterministic tools |
| M19 | `test_script_output_untrusted` | Script output reaches the agent wrapped in untrusted markers and cannot call tools |
| M19 | `test_sheet_canary` | Instructions hidden in a cell, a comment and a hidden sheet influence no claim, decision option, script or MDL change |
| M20 | `test_critic_isolation` | The critic's context contains no author steps, prompts or task results |
| M20 | `test_critic_finding_has_fixture` | Non-ambiguity findings without a reproducing fixture are refused |
| M20 | `test_critic_catch_rate` | On the seeded-faults fixture the critic finds every documented fault |
| M20 | `test_dispute_escalates` | A disputed finding unresolved after two rounds becomes a question |
| M21 | `test_question_requires_anchor` | Unanchored questions are refused |
| M21 | `test_question_derivability` | A question about a high-band claim is refused with a reason |
| M21 | `test_questions_batched` | At most five open questions are shown, in impact order |
| M21 | `test_no_credentials_in_chat` | Intake refuses credential-like input and offers approved profiles |
| M22 | `test_gate_blocks_downstream` | Modeller tasks for a concept do not start before its alignment and key claims are accepted |
| M22 | `test_invalidation` | Rejecting a gated claim invalidates dependent tasks and re-plans them |
| M22 | `test_workflow_survives_restart` | Restarting the orchestration engine mid-wait resumes without repeating finished tasks |
| M22 | `test_four_eyes_workspace` | The workspace owner cannot record the `mapping_spec` sign-off for it |
| M22 | `test_agent_cannot_request_rehearsal` | Rehearsal and migration job requests from agents are refused |
| M22 | `test_concepts_drafted_not_asked` | On the address fixture with no `concepts/` directory, MigrationAuthoring drafts the concepts itself; no question asks the user to create a concept, and the run waits only at the concept-set gate |
| M22 | `test_concepts_reused` | A second migration touching an already-approved concept reuses it and re-aligns instead of redrafting |
| M22 | `test_models_first` | A MigrationAuthoring run whose systems have no approved model runs SystemModelling as a child workflow first |
| M22 | `test_models_reused` | A run whose systems already have approved models skips SystemModelling |
| M23 | `test_generator_sample_loop` | Sample feedback produces a revised model and a new sample that reflects it |
| M23 | `test_address_fixture_end_to_end` | Starting from the v1 DDL and the v2 JSON Schema files, MigrationAuthoring on the address fixture reaches `ready_for_review` with the invariants of the concept passing |
| M23 | `test_migration_from_mapping_sheet` | With the fixture mapping sheet attached, MigrationAuthoring translates its rows, raises its planted conflict and TBD rows, and reaches review with sandbox tests passing |
| M23 | `test_mock_data_from_ddl` | MockDataAuthoring on the three-system DDL set produces linked samples in flow order that validate against the uploaded DDL |
| M23 | `test_canary` | The canary fixture influences no claim, option or MDL change |
| M23 | `test_agent_eval_gate` | A worse agent evaluation run cannot be marked accepted |
| M24 | `test_bundle_mdl_only` | A bundle holds MDL, expectations, examples, critic fixtures, reports and an evidence summary; no scripts, scratch, attachments or transcripts |
| M24 | `test_bundle_reproducible` | Two builds of the same commit produce the same bundle hash |
| M24 | `test_bundle_signature_required` | Unsigned, wrongly signed or modified bundles are rejected by every runtime tier |
| M24 | `test_runtime_recompile_match` | A bundle whose MDL does not recompile to its recorded spec hash is rejected |
| M24 | `test_runtime_reruns_tests` | The runtime tier re-runs the bundle's tests on synthetic data and rejects on any failure |
| M24 | `test_runtime_profile_no_agents` | The runtime profile exposes no agent, LLM, MCP or discovery endpoints |
| M24 | `test_worker_accepts_only_accepted_bundles` | The data-plane worker refuses jobs whose spec hash is not in an accepted bundle for that tier |
| M24 | `test_promotion_four_eyes` | The person who requests a promotion cannot approve it |
| M24 | `test_intelligence_pack_aggregates_only` | A pack holds no rows and nothing below the minimum group size; its signature is checked on import |
| M24 | `test_same_bundle_across_tiers` | SIT and UAT accept the same bundle hash without a rebuild |

### 41.5 Build plan

| Milestone | Builds | Notes |
|---|---|---|
| **M16 — Tools and sandbox** | Tool registry with effects and roles, tool catalogue, MCP server, sandbox runner, untrusted marking, diagnostic hints, `run_tools` on the provider and stub | No agents yet; everything usable by people and external MCP clients |
| **M17 — Model from schema files (the first loop)** | Schema IR; DDL importer (sqlglot dialects, fallback parse) and JSON Schema importer (bundle `$ref`s); shredding; MDL `document`, `array` and `path`; coverage checker; sample validator; `schema_upload`; agent runtime, budgets and stop rules; workspace and branches; `agent_task` and `agent_step`; the schema agent; a minimal workspace screen with the Systems step, MDL diff and test report | **Proves the agent pattern on the smallest loop, with an exact oracle: the uploaded schema itself** |
| **M18 — Modeller** | Modeller agent and test-first loop for concepts and realisations, on the M17 runtime | Builds on models created in M17 |
| **M19 — Attachments, mapping sheets, scripts and commands** | `attachment`, scan and masking, workbook reader, layout detection and saved layouts, mapping-sheet interpretation (classification, resolution, translation, coverage, conflicts), Excel export, `code.run`, `shell.run` and `scratch.keep` with the permission policy, OS sandboxing, permission cards and `tool_run`, the Attachments and Scripts UI | Authoring tier only |
| **M20 — Critic** | Critic context isolation, adversarial fixtures, findings, dispute protocol, critique of system models, seeded-faults fixture | |
| **M21 — Intake and questions** | Intake agent, question rules (anchor, derivability, batching), question cards in the workspace screen | |
| **M22 — Orchestration** | DurableRunner (Temporal, Postgres fallback), SystemModelling, MigrationAuthoring and DriftRevision workflows, `ensure_models`, gates and invalidation, rules agent, merge review and four-eyes | |
| **M23 — Generator and evaluation** | Generator agent and MockDataAuthoring, sample feedback loop, trajectory evaluation with simulated human, address, canary and schema-import fixtures, agent evaluation gate | |
| **M24 — Tiers and promotion** | Authoring and runtime deployment profiles, intelligence-pack export and import, deterministic promotion bundles, build-service signing, runtime verification (signature, recompile, test re-run), per-tier acceptance, the worker rule, the Promotion screen | May be built any time after M17; required before any agent-authored model is used in SIT |

### 41.6 Decisions (seed entries for `DECISIONS.md`)

- **D10 — Agents deliver MDL only.** All executable code in a migration or
  generator is generated by the compiler from approved MDL, so agent output is
  always reviewable as a spec diff. Scratch scripts (§ 43.5) are analysis aids whose
  results are evidence; they never become part of what runs.
- **D11 — Shared state over messages.** Hand-offs are artifacts on a branch and in
  the graph; agent transcripts are audit records, never inputs to other agents.
- **D12 — Sandbox in the control plane, synthetic only.** Agents get fast
  feedback without weakening the data-plane rule that only approved specs run.
- **D13 — One tool registry for agents, people and MCP clients.** Permissions live
  in tools, not in prompts.
- **D14 — Durable engine behind an interface.** Temporal by default; Postgres
  fallback keeps the design deployable if Temporal is not approved.
- **D15 — Parse deterministically; agents interpret.** Parsers turn DDL and JSON
  Schema into the Schema IR; agents never parse files themselves, so nothing in the
  input is lost or invented, and coverage can be checked exactly.
- **D16 — Documents are shredded internally.** JSON documents become root and
  child containers with paths, so the generator, concepts and migrations treat
  documents and tables alike; adapters reassemble documents on output.
- **D17 — Schema-only evidence is capped at medium.** Without data, an inferred
  relationship is a hypothesis; data or a person must confirm it.
- **D18 — Mapping sheets are strong evidence, not truth.** A sheet row is
  human-authored and can reach the high band, but only after it resolves against
  the models, fits the target types and passes sandbox tests; disagreements are
  surfaced as conflicts, never resolved silently.
- **D19 — Scripts and commands in the authoring tier.** Agents write and run
  scripts and commands like a coding assistant, under a developer-controlled
  permission policy with OS-level sandboxing, because the authoring tier holds no
  real data and no runtime credentials. Scratch is deleted when a task ends unless a
  script is kept; MDL produced by scripts enters the branch only through `mdl.write`.
- **D20 — Two tiers; only MDL moves up.** Agents, LLM calls and scripts exist only
  in the authoring tier. Runtime tiers run Parts A and B without agents or LLMs and
  accept nothing but signed promotion bundles.
- **D21 — Verify by recompiling.** A runtime tier recompiles the bundle's MDL with
  the pinned compiler and requires the same spec hash, then re-runs the bundle's
  tests, so it trusts the MDL, not the authoring tooling.
- **D22 — Intelligence flows down as aggregates only.** Runtime tiers export signed
  packs of profiles, data evidence and learned-model parameters; no rows ever reach
  the authoring tier.

### 41.7 Part C risks

| Risk | Mitigation |
|---|---|
| Agents look productive but shift work to reviewers | Track human edits and review minutes per workspace; question-necessity metric; gate releases on them |
| Cost and latency of long agent loops | Budgets per task; one concept at a time; cache grounded contexts per commit |
| Model or provider changes alter behaviour | Pinned models; agent evaluation gate before any change |
| Over-trust in agent proposals | Proposals are visually distinct; gated claims; critic findings shown beside every proposal |
| Temporal not approved | Postgres runner fallback behind `DurableRunner` |
| DDL dialect features the parser does not support | Reported as import issues with file and line; fallback CREATE TABLE parse; never skipped silently |
| JSON Schemas without lengths or keys | Unbounded length allowed with a warning; a missing document key becomes an anchored question |
| Mapping sheets are stale or contradict the models | Every row is resolved and tested; conflicts and coverage gaps are listed for review; the export returns findings to the sheet's owners |
| Real customer data inside attached spreadsheets | Sensitive-value scan; only a masked copy is stored; policy can reject such files outright |
| A manipulated agent runs a harmful script or command | No real data or runtime credentials in the authoring tier; permission policy with OS sandbox; runtime hosts denied; all runs logged; only reviewed, signed, recompiled MDL is promoted |
| A developer loosens the permission policy | Policy changes are reviewed commits; runtime tiers do not rely on authoring-tier hygiene because they verify by recompiling and re-testing |
| A bundle is tampered with between tiers | Signed by the build service with a key no developer holds; signature and recompile checked in every tier |
| Schema files drift from the live system | Where a connection exists, profiling compares file and live schema and raises drift items |

---

## 42. Model creation from schema files (the entry point)

### 42.1 Inputs and outputs

Every agent workflow starts here. For each system it needs, the user provides one of:

- **DDL** in a named dialect: one or more `.sql` files, or a zip bundle. Supported
  dialects are those `sqlglot` parses (Oracle, PostgreSQL, SQL Server, MySQL,
  Teradata and others); other dialects use a fallback `CREATE TABLE` parser and
  report what it cannot read.
- **JSON Schema** (drafts 07, 2019-09 and 2020-12): one or more `.json` files, or a
  zip bundle, with `$ref`s between files in the bundle.
- **A data-dictionary spreadsheet** (`.xlsx` or `.csv`) read through the layout
  detection of § 43.4.
- **An approved connection profile** (Part B § 20), or a connection **and** files,
  in which case the two are compared (§ 42.8).

The output, after human review and merge, is a **system model** per system: a
system and version, tables or documents with arrays, columns with physical types,
declared keys and links, proposed undeclared links, flow order between systems,
semantic types, generator proposals and valueset bindings, all as MDL on the
workspace branch and, on merge, as registry rows and claims (§ 42.8).

```sql
CREATE TABLE schema_upload (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  system_name text NOT NULL,
  role text NOT NULL,                        -- source | target | standalone (mock data only)
  version_label text NOT NULL,
  format text NOT NULL,                      -- ddl | json_schema
  dialect text,                              -- ddl only: oracle | postgres | tsql | mysql | …
  files jsonb NOT NULL,                      -- [{name, sha256, bytes, storage_ref}]
  ir_ref text,                               -- stored Schema IR (§ 42.3)
  status text NOT NULL DEFAULT 'uploaded',   -- uploaded | parsed | parse_failed | modelled |
                                             -- merged | superseded
  issues jsonb NOT NULL DEFAULT '[]',
  uploaded_by text NOT NULL,
  uploaded_at timestamptz NOT NULL DEFAULT now());
-- system_version.role gains 'standalone'
```

Technology added: `jsonschema` and `referencing` (validation with the bundle as the
only `$ref` registry), `duckdb` (in-process constraint check in the sandbox).
`sqlglot` is already in the stack.

### 42.2 Pipeline: parse deterministically, then interpret

```
upload ─► schema.import (deterministic) ─► Schema IR + import issues + coverage expectations
       ─► schema agent: model_system (loop § 42.7) ─► MDL system file on the branch
       ─► schema agent: link_systems ─► cross-system links, flow order
       ─► critic: critique_models ─► human review ─► merge ─► registration (§ 42.8)
```

The parsers do everything that has a single right answer; the agent does only what
needs judgement. Agents never read raw files: they read the IR (D15).

### 42.3 Schema IR (`importers/schema_ir.py`)

```python
@dataclass(frozen=True)
class SourceSpan:
    file: str; line: int | None; col: int | None
    pointer: str | None                       # JSON Pointer for JSON Schema elements
    sheet: str | None = None                  # spreadsheets: sheet name; line = row

@dataclass(frozen=True)
class IRField:
    name: str                                 # valid MDL name (sanitised)
    path: str | None                          # exact JSON path for document fields
    dtype: str                                # DataForge dtype (§ 42.4)
    length: int | None; precision: int | None; scale: int | None
    nullable: bool; default: str | None
    enum: tuple[str, ...] | None; pattern: str | None; format: str | None
    minimum: str | None; maximum: str | None
    checks: tuple[str, ...]                   # CHECK expressions (untrusted text)
    description: str | None                   # comment or description (untrusted text)
    attrs: dict                               # dialect type, time zone flag, identity, json flag …
    source: SourceSpan

@dataclass(frozen=True)
class IRContainer:
    name: str
    kind: Literal["table", "document", "array", "key_value"]
    parent: str | None; path: str | None
    fields: tuple[IRField, ...]
    primary_key: tuple[str, ...] | None
    uniques: tuple[tuple[str, ...], ...]
    items: tuple[int, int | None] | None      # arrays: min and max items
    variants: tuple[dict, ...]                # oneOf/anyOf with discriminator
    source: SourceSpan

@dataclass(frozen=True)
class IRForeignKey:
    from_container: str; from_fields: tuple[str, ...]
    to_container: str; to_fields: tuple[str, ...]
    source: SourceSpan

@dataclass(frozen=True)
class ImportIssue:
    code: str                                 # e.g. UNSUPPORTED_TYPE, REMOTE_REF, PARSE_ERROR
    severity: Literal["blocking", "warning"]
    message: str; source: SourceSpan

@dataclass(frozen=True)
class SchemaIR:
    system: str; format: str; dialect: str | None
    containers: tuple[IRContainer, ...]
    foreign_keys: tuple[IRForeignKey, ...]
    views: tuple[dict, ...]                   # view SQL, kept for code mining
    issues: tuple[ImportIssue, ...]
    file_hashes: dict[str, str]
```

Every element carries a `SourceSpan`, so coverage, review and questions can always
point at the exact line or JSON Pointer in the user's file.

### 42.4 Mapping rules

**Part A dtype list gains `TEXT`, `UUID` and `BINARY`.** Fit checks treat `TEXT` as
unbounded; `BINARY` columns are generated as random bytes and left out of sample
displays.

**DDL types (`importers/typemap.py`)**

| Source type | DataForge dtype | Note |
|---|---|---|
| VARCHAR2(n), VARCHAR(n), NVARCHAR(n), CHARACTER VARYING(n) | VARCHAR(n) | Byte or character semantics recorded in `attrs` |
| CHAR(n), NCHAR(n) | CHAR(n) | |
| NUMBER(p,s), NUMERIC(p,s), DECIMAL(p,s) | NUMBER(p,s) | |
| INT, INTEGER, BIGINT, SMALLINT, NUMBER(p,0) with p ≤ 18 | INTEGER | Range recorded |
| NUMBER without precision (Oracle), MONEY (SQL Server) | NUMBER(38,10) or NUMBER(19,4) | Warning: precision assumed |
| DATE | DATE; **TIMESTAMP for Oracle DATE** | Oracle DATE carries a time; warning |
| TIMESTAMP, DATETIME, DATETIME2, TIMESTAMP WITH TIME ZONE | TIMESTAMP | Time-zone flag in `attrs` |
| BOOLEAN, BIT, NUMBER(1) with CHECK IN (0,1) | BOOLEAN | |
| CLOB, TEXT, NVARCHAR(MAX), LONG | TEXT | |
| UUID, UNIQUEIDENTIFIER | UUID | |
| BLOB, BYTEA, VARBINARY, RAW | BINARY | |
| JSON, JSONB | TEXT with a `json` flag | A JSON Schema for the column, if supplied, models it as a document |
| Spatial, XML, user-defined and array types | — | Import issue `UNSUPPORTED_TYPE` |

Read from DDL: `CREATE TABLE` (columns, defaults, identity), `PRIMARY KEY`,
`UNIQUE`, `FOREIGN KEY`, `CHECK`, `NOT NULL`, `ALTER TABLE … ADD CONSTRAINT`,
`CREATE UNIQUE INDEX`, `COMMENT ON`, `CREATE SEQUENCE`, `CREATE VIEW` (kept for code
mining). Grants, storage clauses and other statements are ignored and listed once as
a warning.

**JSON Schema (`importers/jsonschema_importer.py`, `importers/shred.py`)**

| JSON Schema | Model |
|---|---|
| Root object | Container `document`, path `$` |
| `string` with `maxLength` n | VARCHAR(n); no `maxLength` → TEXT with warning `LENGTH_UNKNOWN` |
| `format: date` / `date-time` / `uuid` / `email` | DATE / TIMESTAMP / UUID / VARCHAR with `persona.email` proposal |
| `pattern` | Kept as a regex constraint and generator proposal |
| `integer`, `minimum`, `maximum` | INTEGER, bounds as generator range |
| `number`, `multipleOf: 0.01` | NUMBER(p,2), p from `maximum` or 18 |
| `boolean` | BOOLEAN |
| `enum`, `const` | Enum constraint and generator; valueset candidate |
| Not in `required`, or type includes `null` | Nullable |
| Nested object | Flattened into its parent container; column names joined with `_`; `path` keeps the exact JSON location |
| Array of objects | Child container `array`: parent key, ordinal `_ORD`, `items(minItems..maxItems)` |
| Array of scalars | Child container `array` with one column `VALUE` |
| Map (`additionalProperties` with a schema) | Child container `key_value` with `KEY` and `VALUE` |
| `oneOf`/`anyOf` with a discriminator (a shared property with `const` or `enum`) | One container: discriminator column, variant fields nullable, one rule per variant making its required fields mandatory |
| `oneOf`/`anyOf` without a discriminator | Blocking import issue `NO_DISCRIMINATOR` (question, § 42.6) |
| `allOf` | Merged |
| `$ref` | Resolved inside the bundle only; recursion cut at depth 3 with a warning |
| `title`, `description`, `examples` | Column description and hints (untrusted); never copied verbatim into generated data |
| `x-primary-key`, `x-foreign-key` (optional extensions) | Declared keys and links |

**MDL additions (`app/mdl/grammar.lark`)**

```lark
system_body: conn_def | table_def | document_def | array_def | imported_def
imported_def: "imported_from" NAME STRING ("dialect" NAME)? "sha256" STRING
document_def: "document" NAME ("key" "(" NAME ("," NAME)* ")")? "{" doc_item* "}"
array_def: "array" NAME "of" NAME "path" STRING ("items" "(" items_range ")")? "{" doc_item* "}"
items_range: NUMBER ".." (NUMBER | "*")
doc_item: column_def | bind_def | variant_def
variant_def: "variant" STRING "when" NAME "==" value "requires" "(" NAME ("," NAME)* ")"
// column_def gains an optional trailing: ("path" STRING)?
```

The compiler turns a `document` into a `TablePlan` with `shape = "document"`, and an
`array` into a child `TablePlan` with `shape = "array"`, the parent key, `_ORD`, an
implicit link to the parent with cardinality from `items`, and the JSON path.
Variants compile to Part A rules. Adapters reassemble documents on output: the file
adapter writes one JSON document per root (`<document>.jsonl`), and the REST and
Kafka adapters send assembled documents (D16).

**Worked example — the address case as JSON Schema**

```json
{"$schema": "https://json-schema.org/draft/2020-12/schema",
 "$id": "customer.schema.json", "type": "object",
 "required": ["customerId", "addresses"],
 "properties": {
   "customerId": {"type": "string", "pattern": "^CUS[0-9]{10}$"},
   "name": {"type": "object", "properties": {
       "first": {"type": "string", "maxLength": 60},
       "last":  {"type": "string", "maxLength": 60}}},
   "segment": {"enum": ["RETAIL", "PREMIUM", "CORP"]},
   "addresses": {"type": "object", "required": ["primary"], "properties": {
       "primary": {"$ref": "address.schema.json"},
       "others":  {"type": "array", "maxItems": 4, "items": {"$ref": "address.schema.json"}}}}}}
```

becomes, after the schema agent's proposals (key, generators):

```
system CORE_V2 {
  imported_from json_schema "customer.schema.json" sha256 "9c41…"

  document CUSTOMER_DOC key (customerId) {
    column customerId : regex("^CUS[0-9]{10}$") sqltype varchar(13) pk path "$.customerId"
    column name_first : persona.name(part = "first") sqltype varchar(60) nullable path "$.name.first"
    column name_last  : persona.name(part = "last")  sqltype varchar(60) nullable path "$.name.last"
    column segment    : enum("RETAIL","PREMIUM","CORP") sqltype varchar(7) nullable path "$.segment"
    column addresses_primary_role  : enum("RESIDENTIAL","OFFICE","MAILING") sqltype varchar(12) path "$.addresses.primary.role"
    column addresses_primary_line1 : describe("street line of an Indian address") sqltype varchar(80) path "$.addresses.primary.line1"
    column addresses_primary_pin   : regex("^[1-9][0-9]{5}$") sqltype char(6) path "$.addresses.primary.pin"
  }

  array CUSTOMER_DOC_ADDRESSES_OTHERS of CUSTOMER_DOC path "$.addresses.others" items(0..4) {
    column role  : enum("RESIDENTIAL","OFFICE","MAILING") sqltype varchar(12) path "role"
    column line1 : describe("street line of an Indian address") sqltype varchar(80) path "line1"
    column pin   : regex("^[1-9][0-9]{5}$") sqltype char(6) path "pin"
  }
}
```

### 42.5 What the schema agent proposes

Deterministic heuristics (`modelling/heuristics.py`) run first; the agent reviews
their output and fills the residue with LLM proposals. All proposals are claims or
MDL on the branch; declared constraints are not proposals (§ 42.8).

| Signal | Proposal | Evidence | Highest band |
|---|---|---|---|
| Declared PK, UNIQUE, FK, `x-primary-key`, `x-foreign-key` | Keys and links | `declared` | Accepted on merge |
| CHECK IN list, `enum`, `const` | Enum generator; valueset candidate | `declared` | — |
| Column with the same name, type and length as another table's key (`ACCT_MASTER.CUST_NO` ↔ `CUST_MASTER.CUST_NO`) | `INCLUDED_IN` link | heuristic | Medium |
| A join in a view or procedure in the bundle | `INCLUDED_IN` link | `sql_parse` | Medium |
| Code and description columns sharing a stem (`_CD`/`_CODE` with `_DESC`/`_DESCRIPTION`/`_NAME`) in one container | A valueset with fields (code, description), both columns bound | heuristic | Proposal; tuples requested |
| Name or pattern matching a semantic validator (IFSC, PAN, IBAN, email, currency, PIN code) | Semantic type and generator | `semtype` (pattern only) | Medium |
| Money-like NUMBER(p,2) by name and context | Decimal generator with money flag (minor units downstream) | heuristic | Medium |
| Text column with a clear comment or description | `describe("…")` generator | heuristic | Medium |
| Primary key of character type | `id(pattern)` from the regex or from the length | heuristic | Medium |
| Same business key name and type in two systems | Cross-system link; flow from the referenced to the referencing system | heuristic | Medium |
| Document with no declared key | Key candidates ranked: required, unique-looking, id-like | heuristic | Question if more than one candidate |
| Residue | Generator, semantic type or link proposal from names and descriptions | `llm` | Medium |

Schema-only evidence never reaches the high band for an inferred relationship
(D17). Profiling, when a connection exists, or a human acceptance can raise it.

### 42.6 Questions the schema agent may ask

All follow § 33.2: anchored, not derivable, with evidence and choices.

| Anchor | Typical question | Options |
|---|---|---|
| `import_issue` | "`ADDR_GEO` uses an unsupported spatial type (core.sql, line 88)." | Exclude with reason · treat as TEXT · supply a JSON Schema for it |
| `import_issue` | "`address.schema.json` is referenced but not in the bundle." | Upload the file · treat the property as TEXT |
| `document_key` | "Which property identifies a `CUSTOMER_DOC`?" | Ranked candidates with reasons |
| `system_boundary` | "core.sql defines schemas `CBS` and `CRM`. One system or two?" | One system · two systems |
| `system_flow` | "Links run both ways between CORE and CARDS. Which system creates the data first?" | CORE → CARDS · CARDS → CORE (two-pass back-reference) |
| `import_issue` (`NO_DISCRIMINATOR`) | "`payment` is `oneOf` three shapes with no shared type field. Which property tells them apart?" | Property candidates · model as separate documents |
| valueset (via `examples.request`) | "`ENTITY_CODE` and `ENTITY_DESC` look like a code list. Upload the reference list, or confirm codes from the CHECK constraint?" | Upload CSV · use CHECK codes, descriptions pending |

### 42.7 The loop and its oracle

The schema agent uses the § 35.2 loop with two deterministic checks as its oracle.
The uploaded schema itself is the specification, which makes this the most
reliable agent loop in the platform and the right one to prove first (M17).

1. **Expectations first, written by the importer.** `schema.import` commits
   `expectations/<system>.coverage.json`, listing every container, field and
   constraint with its source span. Agents cannot write or edit this file; the tool
   refuses. The agent adds `expectations/<system>.inferred.json` for what it infers,
   for example that both columns bound to a proposed valueset must agree.
2. **Coverage** (`schema.coverage`): every IR element appears in the MDL with the
   same type, length, precision, scale and nullability, or is excluded with a reason
   from a closed list (`unsupported_type`, `generated_by_target`, `deprecated`,
   `out_of_scope`). Primary keys and required fields cannot be excluded.
   Exclusions are shown in review.
3. **Sample validation** (`schema.validate_sample`), in the sandbox:
   - Generate 100 roots plus boundary rows: maximum lengths, numeric bounds, every
     enum value, every variant, arrays at minimum and maximum items, and a null in
     every nullable field.
   - Check every IR constraint: type, length, precision, nullability, enum, unique,
     foreign key, and CHECK expressions that `sqlglot` can turn into predicates.
   - **DDL:** transpile the uploaded DDL to DuckDB with `sqlglot`, create it in an
     in-memory DuckDB, and load the sample; any constraint violation fails. If a
     statement cannot be transpiled, the report marks the DuckDB check as partial.
   - **JSON Schema:** reassemble documents and validate each with the `jsonschema`
     validator for the declared draft, using the bundle as the only `$ref` registry.

A model is done when it compiles, coverage is complete and the sample validates.

### 42.8 Merge, registration and versions

On merge, a human approves the system model as a set, and `modelling/register.py`
(not an agent) writes:

1. The `system` (created or reused) and a new frozen `system_version` with its role
   and label; the uploaded files and their hashes become the version's record.
2. Part A registry rows: `table_def` with shape and path, `column_def` with dtype,
   length, precision, scale, nullability, key flag, generator spec and valueset
   binding; links and `flow` statements accepted in review.
3. Part B graph: `kg_node` rows for containers and fields; `CONTAINS`, and declared
   `UNIQUE` and `INCLUDED_IN` claims as accepted, with `declared` evidence plus the
   merging reviewer's human evidence; inferred claims stay `proposed` for the
   Evidence screen.

**Re-import.** An upload for a system that already has a version creates a new
version label; a frozen version is never overwritten. The IR is diffed against the
previous version into Part A drift items, and anything built on the old version
starts DriftRevision (§ 38.2).

**Files and a live connection.** When both exist, the file IR is compared with the
inventory read over the connection. Differences become drift items of kind
`file_vs_live`, and the user decides per item which is authoritative.

### 42.9 Security of uploaded files

- Uploads are untrusted input: size limits per file and per bundle (configurable;
  default 20 MB and 200 MB); zip extraction rejects absolute paths, `..` and links.
- **No data in schema files.** Files containing data statements (`INSERT`, `COPY`,
  `MERGE`, bulk-load blocks) are rejected before storage, with a request for a
  schema-only export. The control plane never stores rows.
- Remote `$ref`s (`http`, `https`, `file`) are never fetched; each becomes an import
  issue asking for the file.
- Parsing and validation run in the sandbox, with no network. Uploaded DDL is never
  executed against any database other than the in-process DuckDB check.
- Comments, descriptions, CHECK text, view text and `examples` are marked untrusted
  (§ 39.1) and checked for instruction-like content; the canary fixture covers this.

### 42.10 Fixtures (`samples/schema_import/`)

| Fixture | Contents | Exercises |
|---|---|---|
| `legacy_v1.oracle.sql`, `legacy_v1.postgres.sql`, `legacy_v1.tsql.sql` | The Part B LEGACY_V1 schema in three dialects: `COMMENT ON`, CHECK IN lists, an Oracle DATE, one undeclared key (`ACCT_MASTER.CUST_NO`), the `V_CUST_ACCT` view, `ENTITY_CODE`/`ENTITY_DESC`, address column groups | Dialect parity, inferred links, valuesets |
| `core_v2/` JSON Schema bundle | `customer.schema.json` and `address.schema.json` with `$ref`s, primary address plus `others[]`, a `oneOf` payment with a discriminator | Shredding, `$ref`, variants, document keys |
| `three_systems/` | `core.sql`, `cards.sql`, `payments.sql` (PostgreSQL) with cross-system business keys and no declared cross-system links | Cross-system links, flow order, mock-data authoring |
| `canary.schema.json` | Instructions hidden in `description` fields and an `examples` value | Prompt-injection resistance |
| `bad_inputs/` | A remote `$ref`, an unsupported spatial type, a `oneOf` with no discriminator, a DDL file with `INSERT`s | Import issues, upload rejection |

---

## 43. Attachments, mapping sheets, scripts and commands

Users can attach spreadsheets to a workspace, and agents read and interpret them.
The main case is a **mapping sheet**: the source-to-target mapping a bank's
analysts already maintain in Excel. In the authoring tier, agents can also write
and run scripts and shell commands, like a coding assistant (§ 43.5). Both follow
the governing rule (§ 30.2): files are read by deterministic tools, agents
interpret what those tools return, and nothing an agent produces is accepted
without validation and human review.

### 43.1 Attachments

| Kind | Typical content | Becomes |
|---|---|---|
| `mapping_sheet` | Source system, table and column; target system, table and column; rule; comments; status | Proposed realisations, claims and decisions (§ 43.3) |
| `code_mapping` | Old code, new code, description (often a tab of the mapping sheet) | Valuesets with tuples (§ 43.4) |
| `data_dictionary` | Table, column, type, length, nullable, description | A schema source for § 42, like DDL |
| `reference_data` | A code list or lookup table | Valueset tuples |
| `examples` | Source values and expected target values | Example files for transforms and tests |
| `other` | Anything else | Readable by agents; no automatic use |

Formats: `.xlsx`, `.xlsm` (macros are never run and are stripped from the stored
copy) and `.csv`. Older `.xls` files are refused with a request to save as `.xlsx`.
The kind is detected from headers and content and shown for the user to confirm.

**Upload rules.** Size limits (default 20 MB per file); the § 42.9 file safety rules
apply. Each file is **scanned for sensitive values** using the semantic validators
of § 20.2 (PAN, account and card numbers, IBAN, phone, email, dates of birth next to
names). Matching cells are replaced with format-preserving masks (§ 25.3), only the
masked copy is stored, the original is discarded, and the uploader is told which
cells were masked. A deployment setting can reject such files instead. The control
plane still never stores real rows.

### 43.2 Reading workbooks (`files/workbook.py`)

`files.read_workbook` returns a structured, deterministic reading, so agents never
parse spreadsheet bytes themselves:

```jsonc
{"attachment": "a-17…", "sheets": [
  {"name": "Customer", "hidden": false, "dimensions": "A1:J214",
   "tables": [{"range": "A3:J214",
               "header_rows": [2, 3],                       // two-row header flattened
               "columns": [{"letter": "A", "header": "Source › Table"},
                           {"letter": "F", "header": "Transformation rule",
                            "dropdown": null}],
               "rows": [{"row": 37, "cells": {"A": "CUST_MASTER", "B": "CUST_NAME",
                         "D": "PERSON", "E": "FIRST_NM / LAST_NM",
                         "F": "Split on first space"},
                         "formulas": {}, "comments": {"F": "<<untrusted …>>"},
                         "fill": {"G": "amber"}}]}],
   "merged_ranges": ["A1:J1"]},
  {"name": "Old", "hidden": true, "note": "hidden sheet"}],
 "masked_cells": ["Customer!H41"]}
```

It resolves merged cells, detects header rows (including two-row headers), reads
formulas as both cached value and formula text, includes comments and notes,
dropdown validation lists (often the allowed codes), cell fill colour (teams often
encode status in colour) and hidden rows, columns and sheets. Large sheets are read
in pages with `files.read_range`. All cell text is marked untrusted (§ 39.1).

### 43.3 Mapping-sheet interpretation (`mapping_sheet/`)

`mapping_sheet.interpret` runs five steps; the modeller agent reviews and completes
the result.

**1. Layout.** Each column is given a role: source system, table, column, type;
target system, table, column, type; rule; default; condition; comment; status;
owner; sample value. Header synonyms are matched deterministically ("Src Col",
"Legacy Attribute", "Source Field"…), and the LLM labels the rest. The user confirms
the layout once with a single `sheet_layout` question showing the column-role
strip. A confirmed layout can be saved for the team (`sheet_layout`), and later
sheets with the same header fingerprint use it without asking.

**2. Normalise.** Each row becomes a `MappingRow`: source references, target
references, rule text, rule kind, status, and its exact location (file, sheet,
row). Rows continuing across merged cells, or one source spread over several
target rows, are grouped.

**3. Resolve.** References are matched to nodes in the system models of § 42.
Exact names first, then fuzzy matching (`rapidfuzz`) with the score kept as
evidence. Below a threshold the row is `unresolved` and reported with its location;
two equally good matches raise a `sheet_row` question.

**4. Classify and translate the rule.**

| Rule text examples | Kind | Becomes |
|---|---|---|
| "Direct", "1:1", "As is", blank | `direct` | Copy with cast |
| "Default 'INR'", "Hardcode N" | `constant` | `default("INR")` |
| "As per Code Mapping tab", "A→ACTIVE, D→DORMANT" | `code_translation` | A valueset from the referenced tab or the inline pairs |
| `TRIM(FIRST_NM) \|\| ' ' \|\| LAST_NM`, "Concat first and last name" | `expression` | MDL expression; SQL-like text parsed with `sqlglot`, plain English translated by the LLM into the MDL expression subset |
| "Split name on first space" | `split` | A lossy transform; the compiler requires examples (§ 19.2), which the sheet's sample values or the user can supply |
| "IF STATUS = 'D' THEN 'DORMANT' ELSE 'ACTIVE'" | `conditional` | `case when` expression |
| "Sum of transactions per day" | `aggregation` | A grain change (§ 21.4), always shown to a reviewer |
| "Derived in target", "System generated" | `derived` | A `derived … : recompute` decision proposal |
| "Not required", "N/A", "Not migrated" | `not_migrated` | An `unmapped_source` decision proposal |
| "TBD", "Check with BA", empty rule with a comment | `open` | An open decision, with the comment as context |

**5. Validate and record.** Each translated row becomes MDL on the branch and a
proposed `REALISES` or `MAPS_TO` claim with `mapping_sheet` evidence pointing to the
row. The row is then checked like any other mapping: fit against target types,
grain and cardinality, and the sandbox tests. Its outcome is one of `translated`,
`conflict`, `unresolved`, `decision` or `not_migrated`.

**Conflict policy (D18).** When a row disagrees with the models or with other
evidence, such as incompatible types, a missing column, two rows filling the same
target field differently, or discovery strongly suggesting another source, the row
becomes a `conflict` showing both positions. DataForge never silently prefers the
sheet or its own evidence.

**Bands.** A sheet row is human-authored evidence, so unlike schema-only inference
it can reach the high band, once it resolves cleanly, fits, and passes the sandbox
tests. High-band rows can be bulk-approved; conflicts and decisions cannot.

**Coverage report.** For the sheet as a whole: mandatory target fields no row
fills, source fields no row consumes, duplicate targets, unresolved references,
conflicts and open rows, each with sheet and row.

**Export.** `mapping_sheet.export` writes the reviewed mapping back to Excel in the
original layout, adding columns for DataForge status, confidence, issues and the
MDL reference. Analysts keep working in Excel; re-importing the export changes
nothing unless they edit it.

**Worked example.** Row 37 of the Customer tab reads `CUST_MASTER · CUST_NAME →
PERSON · FIRST_NM / LAST_NM · "Split on first space"`, with sample values in
column H. The layout is the saved team layout, so no question is asked. Both sides
resolve exactly. The rule is classified `split`, which is lossy, so the agent turns
the masked sample values into an example file, and the transform is learned from
examples (§ 21.9). It passes the sandbox tests, and the row reaches the high band
with evidence from the sheet, the examples and the tests. A reviewer approves it
in bulk with the other high-band rows.

### 43.4 Other spreadsheet kinds

- **Code-mapping tabs and reference data** become valuesets: the code column(s)
  and description column(s) become tuple fields, dropdown lists seed allowed codes,
  and rows that reference the tab bind to the valueset. Codes present in profiles
  but missing from the tab are reported as coverage gaps.
- **Data-dictionary sheets** are a schema source for § 42 alongside DDL and JSON
  Schema: the same layout detection maps columns to table, column, type, length,
  nullability, key and description, and the result enters the Schema IR with the
  sheet and row as its source span. Where both a dictionary and DDL exist, they are
  compared and differences become drift items.
- **Examples sheets** become example files (`examples/*.csv`) used by
  example-driven transforms and as permanent tests.

### 43.5 Scripts and commands (authoring tier)

Model authoring happens only in the authoring tier on development machines
(§ 44), which holds no real data and has no route to runtime tiers. Agents
therefore work like a coding assistant: they write scripts, in Python or any other
installed language, run them and shell commands, and keep or discard them, under a
permission policy the developer controls.

**What scripts are for.** Reading and reshaping unusual sheets, cross-checking
tabs, bulk fuzzy matching, statistics over a Schema IR, experiments on synthetic
samples in a local DuckDB or the developer's database, and **generating MDL in
bulk**, for example turning 400 sheet rows into realisation blocks. MDL produced by
a script enters the branch only through `mdl.write`, which compiles it and runs
coverage and sandbox tests. Scripts never write to the branch, the graph or any
table directly, and scripts never travel up: only MDL is promoted (§ 44).

**Tools.**

- `code.run` writes a script to the task's scratch folder and runs it: Python 3.11
  in the workspace virtual environment by default, other interpreters if installed.
  It returns the exit code, output tails and an optional JSON result.
- `shell.run` runs a command with the workspace as working directory.
- `scratch.keep` moves a scratch script into the workspace's `tools/` folder so
  people and later tasks can reuse it.

**Permission policy** (`.dataforge/permissions.yaml`): shipped with defaults,
tightened by teams, never edited by agents (the tools refuse writes to
`.dataforge/`).

```yaml
filesystem:
  allow:     ["${workspace}/**"]                       # read and write
  read_only: ["${dataforge_cache}/packs/**"]           # imported intelligence packs
  deny:      ["~/.ssh/**", "~/.aws/**", "~/.kube/**", "**/*.pem", "**/.env"]
network:
  allow: ["pypi-mirror.bank.internal"]                 # internal package mirror
  deny:  ["*.sit.bank.internal", "*.uat.bank.internal", "*.prod.bank.internal"]
  ask:   ["*"]                                         # anything else: ask the developer
commands:
  allow: ["python *", "duckdb *", "pip install --index-url https://pypi-mirror.bank.internal/* *",
          "ls *", "cat *", "grep *", "git status", "git diff *"]
  deny:  ["sudo *", "ssh *", "scp *", "kubectl *"]
  ask:   ["git push *", "docker *", "curl *", "*"]     # unlisted commands ask
limits: {wall_seconds: 600, memory_mb: 4096, runs_per_task: 50}
```

Deny rules win over allow and ask rules. The tool layer evaluates every call; an
`ask` match pauses the task and shows the developer a permission card (allow once,
allow for this workspace, deny), like a coding assistant. Processes also run inside
an OS-level sandbox built from the same policy (bubblewrap on Linux, Seatbelt on
macOS, a container elsewhere), so the policy holds even for code the tool layer
cannot inspect.

**Lifecycle.** Each task gets `scratch/<task-id>/`. When the task ends, its scratch
folder is deleted, unless an agent or person kept a script with `scratch.keep`.
Kept scripts live under `tools/` on the workspace branch for reuse and review, and
are excluded from promotion bundles (§ 44.4).

**Log.** Every script and command is recorded in `tool_run` with its code or command
line, hash, purpose, permission decision, exit code, output tails and resource use,
and shown in the Scripts tab, where people can re-run, keep or download it. The log
stays with the workspace in the authoring tier; a promotion bundle carries only the
hashes of scripts whose results became evidence.

**Still untrusted.** Script and command output reaches the agent wrapped in
untrusted markers (§ 39.1), because scripts read attachments and can echo them.
The main protection against a manipulated agent is the tier boundary: no real data
and no runtime credentials in the authoring tier, runtime hosts denied, and nothing
but reviewed, signed and recompiled MDL crossing the promotion gate.

**Switching off.** `code.run` and `shell.run` can be disabled per deployment or per
workspace; mapping-sheet and schema capabilities still work through the
deterministic tools.

### 43.6 Tables

```sql
CREATE TABLE attachment (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspace(id) ON DELETE CASCADE,
  kind text NOT NULL,                        -- mapping_sheet | code_mapping | data_dictionary |
                                             -- reference_data | examples | other
  kind_confirmed boolean NOT NULL DEFAULT false,
  file_name text NOT NULL, sha256 text NOT NULL, bytes bigint NOT NULL,
  storage_ref text NOT NULL,                 -- the masked copy only
  scan jsonb NOT NULL DEFAULT '{}',          -- masked cells, hidden sheets, macros stripped
  status text NOT NULL DEFAULT 'uploaded',   -- uploaded | scanned | rejected | interpreted
  uploaded_by text NOT NULL, uploaded_at timestamptz NOT NULL DEFAULT now());

CREATE TABLE sheet_layout (                  -- reusable, confirmed column-role layouts
  id UUID PRIMARY KEY,
  name text NOT NULL, owner_team text,
  header_fingerprint text NOT NULL,          -- normalised headers, hashed
  roles jsonb NOT NULL,                      -- {"A": "source_table", "F": "rule", …}
  confirmed_by text NOT NULL, confirmed_at timestamptz NOT NULL);

CREATE TABLE mapping_row (
  id UUID PRIMARY KEY,
  attachment_id UUID NOT NULL REFERENCES attachment(id) ON DELETE CASCADE,
  sheet text NOT NULL, row_number int NOT NULL,
  source_refs jsonb NOT NULL, target_refs jsonb NOT NULL,
  rule_text text, rule_kind text NOT NULL,   -- § 43.3 kinds
  status_text text,                          -- the sheet's own status column, if any
  resolution jsonb NOT NULL DEFAULT '{}',    -- resolved node ids, fuzzy scores, issues
  outcome text NOT NULL,                     -- translated | conflict | unresolved | decision | not_migrated
  claim_id UUID REFERENCES kg_claim(id),
  decision_id UUID REFERENCES decision(id),
  UNIQUE (attachment_id, sheet, row_number));

CREATE TABLE tool_run (
  id UUID PRIMARY KEY,
  task_id UUID REFERENCES agent_task(id) ON DELETE CASCADE,   -- null when a person runs it
  step_id UUID REFERENCES agent_step(id),
  kind text NOT NULL,                        -- script | command
  purpose text NOT NULL,
  interpreter text,                          -- python3.11 | node | … (scripts only)
  code text NOT NULL,                        -- script source or command line
  code_sha256 text NOT NULL,
  scratch_path text, kept_path text,         -- kept_path set by scratch.keep
  permission jsonb NOT NULL,                 -- allowed | asked → allowed_once | allowed_workspace | denied
  result_ref text, stdout_tail text, stderr_tail text,
  exit_code int, cpu_ms bigint, max_rss_mb int, duration_ms int,
  run_by text NOT NULL,                      -- agent principal or user
  created_at timestamptz NOT NULL DEFAULT now());
```

`tool_run` is kept for the life of the workspace in the authoring tier.

### 43.7 Security summary

| Threat | Control |
|---|---|
| Real customer data in a spreadsheet | Sensitive-value scan; masked copy only; optional rejection |
| Instructions hidden in cells, comments or hidden sheets | Untrusted marking; instruction-like content flagged; canary tests (§ 43.8) |
| Macros or embedded objects | Never executed; stripped from the stored copy |
| A manipulated agent runs a harmful script or command | Authoring tier holds no real data or runtime credentials; runtime hosts denied; permission policy with OS sandbox; the developer is asked for anything outside the policy; every run logged; only reviewed, signed, recompiled MDL is promoted (§ 44) |
| A wrong or stale mapping sheet | Every row resolved, fitted and tested; conflicts and coverage gaps surfaced; export returns findings to the sheet's owners |

### 43.8 Fixtures (`samples/attachments/`)

Built by a fixture script with `openpyxl`, with expected results in
`expected_interpretation.json`:

- `mapping_legacy_v1_to_core_v2.xlsx`: Customer, Account and Code mapping tabs; a
  two-row header with merged cells; every rule kind of § 43.3; one misspelt column;
  one planted conflict (incompatible types); TBD rows; a sample-value column
  containing fake PAN- and account-shaped values for the masking test; a hidden
  "Old" sheet; and the CORE_V2 address mapping (primary plus `others[]`).
- `mapping_same_layout.xlsx`: a second sheet with the same headers, for layout reuse.
- `data_dictionary_cards.xlsx`: a data-dictionary sheet for the cards system.
- `canary.xlsx`: instructions hidden in a cell, a comment and a hidden sheet.

---

## 44. Deployment tiers and promotion

Model authoring happens on development machines; only final MDL moves to higher
environments. The design makes that split explicit, so the boundary that protects
real data is the **promotion gate**, not restrictions on what authoring agents may do.

### 44.1 Two kinds of environment

| | Authoring tier (development) | Runtime tiers (SIT, UAT, pre-production, production) |
|---|---|---|
| Purpose | Create and change models, migrations and mock-data designs | Generate, migrate, rehearse, reconcile and sign off |
| Runs | Studio (authoring screens), agents, LLM access, MCP server, schema import, attachments, scripts and commands, sandbox tests, local synthetic generation | Studio (runtime screens), compiler for verification only, generation engine, migration executors, adapters, reconciliation, sign-offs, the data-plane worker |
| Data | Schema files, masked attachments, synthetic data, intelligence packs (aggregates only) | Real data, in the data plane only (§ 25) |
| Agents and LLM | Yes | **None**; Part B discovery and LLM features are disabled |
| Can change MDL | Yes, on workspace branches | No; accepts promotion bundles only |
| Credentials | None for any runtime tier | Per tier, in the data plane's vault |

The control-plane and data-plane split of § 25 applies inside each runtime tier.
The authoring tier is a separate deployment with no data plane and no network route
to runtime tiers.

### 44.2 Authoring tier deployments

- **Workstation** (`deploy/authoring/`): Docker Compose with Postgres and pgvector,
  the API with agents, the Studio, a local worker for synthetic generation, and
  DuckDB. Workflows use `PostgresRunner` (§ 38.1). The MCP server runs on stdio, so a
  coding assistant on the same machine, such as Claude Code, can drive DataForge's
  tools directly under the same roles and permission policy.
- **Shared dev server**: the same services plus Temporal, for teams sharing
  workspaces.
- **Model store**: a git remote in the development network. Workspaces are
  branches; reviewed merges to `main` form the authoring tier's approved model.
- **Local generation**: any volume can be generated locally (files, DuckDB, a
  developer database) for development. Loading SIT systems and above happens only
  in runtime tiers, from a promoted bundle.

### 44.3 What flows down: intelligence packs

Authoring benefits from what runtime tiers learn from real data, without the data.
A human-approved data-plane job in a runtime tier exports a signed **intelligence
pack** per system version:

- column profiles above the minimum group size, with top values masked (§ 25.3);
- claims with data evidence (containment, uniqueness, dependencies) and their scores;
- the data-quality report (counts and categories, no rows);
- learned-model parameters that passed the privacy gate (§ 24.4);
- rehearsal summaries: ledgers, control-total results, reject counts by category.

The authoring tier verifies the signature and imports the pack read-only. Pack
evidence then raises or lowers bands like any other evidence (§ 20.8). A pack never
contains rows, crosswalk business keys of real customers, or quarantine payloads.

### 44.4 What flows up: promotion bundles

```
bundle-<model-label>-<git-commit>/
├── manifest.json        # bundle id, model label, git commit, compiler version,
│                        # spec hash per model and migration, file hashes, requested_by,
│                        # approved_by, mapping-spec sign-offs recorded in authoring
├── mdl/…                # the MDL files: systems, concepts, realisations, migrations,
│                        # valuesets, rules, scenarios
├── tests/               # coverage expectations, example files, critic fixtures,
│                        # scenario fixtures: everything the tests need, synthetic only
├── reports/             # the last TestReport and coverage result per model and migration
├── evidence.json        # claims and evidence summary, including hashes of scripts
│                        # whose results became evidence (never their code)
└── signature            # over manifest.json, which lists every file hash
```

Never included: scripts and kept tools, scratch, attachments (their example rows are
already in `tests/` as masked example files), transcripts, agent steps and
workspace history. Bundles are built deterministically (sorted paths, fixed
timestamps, normalised line endings), so the same commit always gives the same hash.

### 44.5 The promotion gate

1. **Request** (authoring tier): after a workspace is merged, a person requests a
   promotion of the approved model at a commit. The bundle is built and shown on the
   Promotion screen.
2. **Approve**: a different person with the approver role approves it (four-eyes).
   Agents can do neither.
3. **Sign**: the bank's build service signs the bundle with a key held in the bank's
   key management, never by a developer.
4. **Verify** (each runtime tier, `bundle.verify`):
   - the signature is valid and from the trusted build-service key;
   - the pinned compiler version is installed in the tier;
   - recompiling `mdl/` gives exactly the recorded spec hashes;
   - the bundle's tests pass on synthetic data in the tier's CI.
   Any failure rejects the bundle with a report.
5. **Accept**: the tier records the acceptance and registers the model version as
   approved. The data-plane worker accepts jobs only for spec hashes in bundles
   accepted by that tier, which extends the rule in § 25.1.
6. **Move on**: the same bundle, unchanged, is verified and accepted by the next
   tier (SIT, then UAT, then production). Nothing is rebuilt between tiers.

Sign-offs that need real data (data equivalence, behaviour equivalence, cutover
readiness, point of no return) happen in runtime tiers as before. The mapping-spec
sign-off happens in the authoring tier and travels in the manifest.

**Fixes go back through the gate.** A defect found in a runtime tier is fixed in the
authoring tier and promoted as a new bundle; runtime tiers never edit MDL.

### 44.6 What this simplifies

Runtime tiers run no agents, no LLM, no MCP server and no Temporal, so their
security review covers Parts A and B only. All agentic risk is contained in a tier
that holds no real data and cannot reach the tiers that do, and everything that
crosses into those tiers is reviewed, signed, recompiled and re-tested MDL.

### 44.7 Tables

```sql
-- authoring tier
CREATE TABLE promotion_bundle (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id),
  git_commit text NOT NULL,
  bundle_sha256 text NOT NULL UNIQUE,
  spec_hashes jsonb NOT NULL,                -- {"<model or migration>": "<spec hash>"}
  compiler_version text NOT NULL,
  requested_by text NOT NULL, approved_by text,
  signature_ref text,
  status text NOT NULL DEFAULT 'built',      -- built | approved | signed | rejected
  built_at timestamptz NOT NULL DEFAULT now(),
  CHECK (approved_by IS NULL OR approved_by <> requested_by));

CREATE TABLE intelligence_pack_import (
  id UUID PRIMARY KEY,
  source_tier text NOT NULL, system_version_id UUID NOT NULL REFERENCES system_version(id),
  pack_sha256 text NOT NULL, signature_ok boolean NOT NULL,
  contents jsonb NOT NULL,                   -- inventory of what the pack held
  imported_by text NOT NULL, imported_at timestamptz NOT NULL DEFAULT now());

-- each runtime tier
CREATE TABLE bundle_acceptance (
  id UUID PRIMARY KEY,
  bundle_sha256 text NOT NULL,
  tier text NOT NULL,                        -- sit | uat | preprod | prod
  signature_ok boolean NOT NULL,
  recompile_match boolean NOT NULL,
  tests_passed boolean NOT NULL,
  report jsonb NOT NULL,
  status text NOT NULL,                      -- accepted | rejected
  accepted_by text, at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (bundle_sha256, tier));
```
