# DataForge — Low-Level Design & Build Specification
### Cross-system mock data generation, learned generation and version-to-version migration for banking estates
**Version 2.0 · intended as direct input to an AI coding agent (Claude Sonnet / Claude Code)**

> **Part A (§ 0–14)** specifies the synthetic data generator (milestones M0–M7).
> **Part B (§ 15–29)** extends it into source intelligence, mapping and migration
> (milestones M8–M15). Part B requires Part A to be complete.

---

## 0. How to use this document

This is an implementation-ready specification. It is written to be executed
top-to-bottom by a coding agent, in the milestone order of § 13.

**Rules for the implementing agent**

1. Build in milestone order (M0 → M7, then M8 → M15). Each milestone has a Definition of Done
   with named tests. Do not begin a milestone until the previous one's tests pass.
2. Every file path in this document is authoritative. Create files exactly where
   specified so later milestones can find them.
3. Where this document gives a function signature, implement that signature
   exactly — later milestones call it.
4. The frontend must match the screen specs in § 10 (layout regions, component
   names, design tokens). The tokens in § 10.1 are exact hex values; do not
   substitute a UI library's defaults.
5. When something is ambiguous, prefer the simplest implementation that passes
   the stated acceptance test, and record the decision in `DECISIONS.md`.
6. Do not invent scope. Features not in this document are out of scope for v1.

**Companion artefacts referenced by this LLD** (delivered separately in the same
conversation; treat this document as authoritative if they disagree):

| Artefact | Role |
|---|---|
| `mock-data-platform-architecture.md` | High-level architecture and rationale (the "why") |
| `architecture-section-6.9-aggregate-constraints.md` | Deep design of the aggregate solver |
| `aggregate-constraint-engine.zip` | **Working, tested Python implementation of the aggregate solver — reuse it verbatim** |
| `dataforge-studio.zip` | React prototype of the UI — visual source of truth for § 10 |
| *DataForge — Intelligent Migration & Learned Generation Architecture* (Claude Doc, https://claude.ai/artifact/W8HMQPfonpSZuV49HbrSKY) | Design rationale for Part B, including the accepted findings in its *Independent review* tab |

---

## 1. Scope

### 1.1 What the system does

Users model the tables of several banking core systems, declare how those systems
and tables link to each other, describe what meaningful values look like, express
business rules, define test scenarios, then generate referentially-consistent
synthetic data across all systems and load it into target environments.

### 1.2 In scope for v1

Schema modelling with physical types; the MDL language and compiler; direct,
conditional and function-based links; system flow ordering with optional two-pass
back-references; value sets (correlated code/description tuples); rules with
conditional value domains; scenarios with weights and pairwise coverage;
aggregate constraints; seeded deterministic generation; validation and run
reports; CSV/JSON file output and JDBC + REST ingestion adapters; the Studio UI.

### 1.3 Out of scope for v1

Production data masking, mainframe integration, LLM copilot (stub the endpoint
and return canned suggestions), Kafka adapter, lifecycle state machines, fault
injection, RBAC/SSO (single trusted user), and the CP-SAT solver fallback
(forward-checking only — raise a clear error on genuinely interlocked rules).

---

## 2. Technology stack

**Decision: build v1 in Python.** The architecture document recommends the JVM
for the eventual production system, and that remains the long-term target. For
this build, Python is chosen because the aggregate-constraint solver is already
written and tested in Python (`aggregate-constraint-engine.zip`) and can be
dropped in unchanged, which removes the riskiest component from the critical
path. § 14 records the migration path.

| Layer | Choice | Version |
|---|---|---|
| Backend | Python + FastAPI | 3.11+, fastapi 0.115+ |
| ASGI server | uvicorn | 0.32+ |
| Validation | pydantic | v2 |
| ORM | SQLAlchemy 2.x + Alembic | 2.0+ |
| Database | PostgreSQL | 16 |
| MDL parser | Lark (earley/lalr) | 1.2+ |
| Data frames | polars | 1.x |
| Output format | Parquet + CSV | via polars |
| Target DB driver | psycopg[binary], plus SQLAlchemy for other targets | — |
| Testing | pytest, httpx | — |
| Frontend | React + Vite + TypeScript | React 18, Vite 5 |
| Canvas | reactflow | 11.x |
| Code editor | @monaco-editor/react + monaco-editor | latest |
| Frontend state | Zustand | 4.x |
| Package mgmt | uv or pip + requirements.txt; npm | — |

No CSS framework. Styling is plain CSS with the custom properties in § 10.1.

---

## 3. Repository layout

```
dataforge/
├── README.md
├── DECISIONS.md                    # agent records ambiguity resolutions here
├── docker-compose.yml              # postgres + api + web
├── backend/
│   ├── pyproject.toml
│   ├── alembic/
│   ├── app/
│   │   ├── main.py                 # FastAPI app factory, router registration
│   │   ├── config.py               # env settings (pydantic-settings)
│   │   ├── db.py                   # engine, session, Base
│   │   ├── models/                 # SQLAlchemy ORM models (§ 4)
│   │   │   ├── project.py  model.py  system.py  link.py
│   │   │   ├── valueset.py  scenario.py  run.py  drift.py
│   │   ├── schemas/                # pydantic request/response models (§ 9)
│   │   ├── api/                    # FastAPI routers, one file per resource
│   │   │   ├── models_api.py  tables_api.py  links_api.py  valuesets_api.py
│   │   │   ├── scenarios_api.py  runs_api.py  schema_import_api.py  copilot_api.py
│   │   ├── mdl/                    # § 5
│   │   │   ├── grammar.lark
│   │   │   ├── ast.py              # dataclasses for AST nodes
│   │   │   ├── parser.py           # text -> AST
│   │   │   ├── resolver.py         # name resolution against the model
│   │   │   ├── checker.py          # semantic checks -> Diagnostic[]
│   │   │   ├── compiler.py         # AST -> GenerationPlan IR
│   │   │   └── emitter.py          # model objects -> MDL text (round-trip)
│   │   ├── engine/                 # § 7
│   │   │   ├── plan.py             # GenerationPlan IR dataclasses
│   │   │   ├── planner.py          # flow + table topological ordering
│   │   │   ├── allocator.py        # scenario quotas + pairwise coverage
│   │   │   ├── rng.py              # deterministic per-cell RNG
│   │   │   ├── generators.py       # value generators registry
│   │   │   ├── valuesets.py        # tuple pick + binding
│   │   │   ├── rules.py            # domain narrowing / forward checking
│   │   │   ├── keyvault.py         # generated key store for link resolution
│   │   │   ├── links.py            # direct / conditional / function resolution
│   │   │   ├── aggregate/          # COPY OF aggregate-constraint-engine (§ 7.7)
│   │   │   ├── twopass.py          # deferred column patch sets
│   │   │   ├── validator.py        # post-generation assertions -> report
│   │   │   └── runner.py           # orchestrates stages, writes artefacts
│   │   ├── adapters/               # § 8
│   │   │   ├── base.py             # IngestionAdapter ABC
│   │   │   ├── file_adapter.py     # CSV / JSON / Parquet to disk
│   │   │   ├── jdbc_adapter.py     # SQLAlchemy bulk insert + patch UPDATEs
│   │   │   ├── rest_adapter.py     # HTTP POST/PATCH loader
│   │   │   └── registry.py
│   │   └── importers/              # schema import + drift (§ 7.9)
│   │       ├── sqlalchemy_importer.py  openapi_importer.py  drift.py
│   └── tests/                      # pytest, mirrors app/ structure
├── frontend/
│   ├── package.json  vite.config.ts  index.html
│   └── src/
│       ├── main.tsx  App.tsx  styles.css        # tokens in § 10.1
│       ├── api/client.ts                        # typed API client (§ 9)
│       ├── store/useStudio.ts                   # Zustand store
│       ├── components/                          # shared primitives
│       │   ├── TopBar.tsx  Tabs.tsx  StatusBar.tsx  Pill.tsx
│       │   ├── Panel.tsx  Segmented.tsx  AllocBar.tsx  ListRow.tsx
│       └── screens/
│           ├── CanvasScreen.tsx  TableNode.tsx  LinkInspector.tsx  ColumnInspector.tsx
│           ├── EditorScreen.tsx  mdlLanguage.ts
│           ├── ValuesetsScreen.tsx
│           ├── ScenariosScreen.tsx
│           ├── RunsScreen.tsx
│           └── SchemaImportScreen.tsx
└── samples/
    └── retail_bank/                # seed model used by tests and demos (§ 12.4)
        ├── core_banking.mdl  cards.mdl  payments.mdl
        ├── links.mdl  valuesets.mdl  scenarios.mdl
```

---

## 4. Data model (PostgreSQL)

All tables carry `id UUID PRIMARY KEY DEFAULT gen_random_uuid()`,
`created_at timestamptz NOT NULL DEFAULT now()`, `updated_at timestamptz`.

```sql
-- A project is one banking estate; a model_version is a snapshot of it.
CREATE TABLE project (
  id UUID PRIMARY KEY, name text NOT NULL UNIQUE, description text);

CREATE TABLE model_version (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  label text NOT NULL,                    -- 'release_2026_R3'
  content_hash text NOT NULL,             -- sha256 of compiled IR, e.g. 'a41f9c...'
  seed bigint NOT NULL DEFAULT 84921,
  as_of date,                             -- dataset clock
  is_draft boolean NOT NULL DEFAULT true,
  UNIQUE (project_id, label));

-- Systems form a DAG via system_flow. Order matters (§ 7.2).
CREATE TABLE system (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,                     -- 'CORE_BANKING'
  display_name text,                      -- 'Core banking'
  connection_profile text,                -- 'sit2-corebank'
  adapter_type text NOT NULL DEFAULT 'file',  -- file | jdbc | rest
  ui_lane int NOT NULL DEFAULT 0,         -- swimlane order on the canvas
  UNIQUE (model_version_id, name));

CREATE TABLE system_flow (                -- parent -> child edges
  id UUID PRIMARY KEY,
  parent_system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  child_system_id  UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  UNIQUE (parent_system_id, child_system_id));

CREATE TABLE table_def (
  id UUID PRIMARY KEY,
  system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  name text NOT NULL,                     -- 'CUSTOMER'
  ui_x int NOT NULL DEFAULT 0, ui_y int NOT NULL DEFAULT 0,
  UNIQUE (system_id, name));

CREATE TABLE column_def (
  id UUID PRIMARY KEY,
  table_id UUID NOT NULL REFERENCES table_def(id) ON DELETE CASCADE,
  name text NOT NULL,
  ordinal int NOT NULL,
  -- physical type
  dtype text NOT NULL,                    -- VARCHAR|CHAR|NUMBER|INTEGER|DATE|TIMESTAMP|BOOLEAN
  length int, precision int, scale int,
  nullable boolean NOT NULL DEFAULT true,
  is_pk boolean NOT NULL DEFAULT false,
  -- semantics: exactly one of generator_spec / valueset binding is used
  generator_spec jsonb,                   -- {"kind":"enum","values":[...],"weights":[...]}
  valueset_id UUID REFERENCES valueset(id) ON DELETE SET NULL,
  valueset_field text,                    -- which tuple field this column takes
  describe_text text,                     -- natural-language description (copilot)
  UNIQUE (table_id, name));

CREATE TABLE valueset (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,                     -- 'ENTITY_TYPES'
  fields text[] NOT NULL,                 -- ['code','description','category']
  source text NOT NULL DEFAULT 'inline',  -- inline | csv | reference_table
  UNIQUE (model_version_id, name));

CREATE TABLE valueset_row (
  id UUID PRIMARY KEY,
  valueset_id UUID NOT NULL REFERENCES valueset(id) ON DELETE CASCADE,
  ordinal int NOT NULL,
  values text[] NOT NULL,                 -- aligned with valueset.fields
  weight int NOT NULL DEFAULT 1);

CREATE TABLE link (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,
  source_column_id UUID NOT NULL REFERENCES column_def(id) ON DELETE CASCADE,
  target_column_id UUID NOT NULL REFERENCES column_def(id) ON DELETE CASCADE,
  kind text NOT NULL,                     -- direct | conditional | function
  condition jsonb,                        -- {"column":"CPTY_TYPE","op":"==","value":"ACCOUNT"}
  transform_fn text,                      -- registered plugin name for kind=function
  card_min int NOT NULL DEFAULT 1,
  card_max int NOT NULL DEFAULT 1,
  back_reference boolean NOT NULL DEFAULT false,
  two_pass boolean NOT NULL DEFAULT false,
  UNIQUE (model_version_id, name));

CREATE TABLE rule (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,
  table_id UUID NOT NULL REFERENCES table_def(id) ON DELETE CASCADE,
  strength text NOT NULL DEFAULT 'hard',  -- hard | soft
  probability numeric,                    -- for soft rules
  when_expr jsonb NOT NULL,               -- expression AST
  then_expr jsonb NOT NULL,
  UNIQUE (model_version_id, name));

CREATE TABLE aggregate_constraint (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,
  target_column_id UUID NOT NULL REFERENCES column_def(id),
  over_link_id UUID NOT NULL REFERENCES link(id),
  child_amount_column_id UUID NOT NULL REFERENCES column_def(id),
  opening_column_id UUID REFERENCES column_def(id),
  mode text NOT NULL DEFAULT 'allocate',  -- allocate | derive
  guard_floor_expr text,                  -- e.g. '0 - OD_LIMIT'
  row_classes jsonb NOT NULL);            -- [{case, lo, hi, quantum, absorber, mean}]

CREATE TABLE scenario (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL, weight numeric NOT NULL,
  overrides jsonb NOT NULL DEFAULT '{}',  -- {"CORE_BANKING.CUSTOMER":{"SEGMENT":"RETAIL"}}
  coverage jsonb,                         -- {"mode":"pairwise","dims":["A.B","C.D"]}
  ui_color text,
  UNIQUE (model_version_id, name));

CREATE TABLE run (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id),
  run_number serial,
  status text NOT NULL,                   -- queued|generating|ingesting|verified|failed
  seed bigint NOT NULL,
  volumes jsonb NOT NULL,                 -- {"CORE_BANKING.CUSTOMER": 5000}
  target_env text NOT NULL,
  started_at timestamptz, finished_at timestamptz,
  report jsonb,                           -- RunReport (§ 9.7)
  error text);

CREATE TABLE run_artifact (
  id UUID PRIMARY KEY,
  run_id UUID NOT NULL REFERENCES run(id) ON DELETE CASCADE,
  system_name text NOT NULL, table_name text NOT NULL,
  kind text NOT NULL,                     -- insert | patch
  path text NOT NULL, row_count bigint NOT NULL);

CREATE TABLE drift_item (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  kind text NOT NULL,                     -- added|changed|removed|breaking
  target text NOT NULL,                   -- 'CUSTOMER.PREF_LANG'
  detail text NOT NULL, suggestion text,
  breaking boolean NOT NULL DEFAULT false,
  state text NOT NULL DEFAULT 'pending',  -- pending|accepted|skipped
  scanned_at timestamptz NOT NULL DEFAULT now());
```

**Indexes:** FK columns; `run(model_version_id, run_number desc)`;
`drift_item(model_version_id, state)`.

---

## 5. MDL — language specification

### 5.1 Grammar (`app/mdl/grammar.lark`)

Implement this grammar. It is deliberately small; extend only if a § 12 test
requires it.

```lark
start: statement*
statement: system_def | flow_def | link_def | rule_def | valueset_def
         | scenario_def | dataset_def | aggregate_def | param_def

system_def: "system" NAME "{" system_body* "}"
system_body: conn_def | table_def
conn_def: "connection" "profile" STRING
table_def: "table" NAME "{" column_def* bind_def* "}"

column_def: "column" NAME ":" generator sqltype? flag*
generator: NAME ("." NAME)? ("(" arglist? ")")?
sqltype: "sqltype" NAME ("(" NUMBER ("," NUMBER)? ")")?
flag: "pk" | "not_null" | "nullable"
bind_def: "bind" "(" NAME ("," NAME)* ")" "<-" "pick" NAME "(" NAME ("," NAME)* ")"

flow_def: "flow" NAME ("->" NAME)+

link_def: "link" qname "->" qname link_opt*
link_opt: "when" expr
        | "cardinality" NAME "(" range ")"
        | "via" "fn" STRING
        | "via" "valueset" NAME "(" NAME "->" NAME ")"
        | "back_reference" ("(" "two_pass" ")")?

rule_def: "rule" NAME "on" qname "{" "when" expr ("then"|"prefer") expr probability? "}"
probability: "probability" NUMBER "%"

valueset_def: "valueset" NAME "{" "fields" "(" NAME ("," NAME)* ")"
              "values" tuple ("," tuple)* weights? "}"
tuple: "(" STRING ("," STRING)* ")"
weights: "weights" "(" NUMBER ("," NUMBER)* ")"

aggregate_def: "aggregate" NAME "on" qname "{" agg_opt* "}"
agg_opt: "target" NAME | "over" qname "via" "link" NAME
       | "define" expr | "mode" NAME | "guard" expr

scenario_def: "scenario" STRING "weight" NUMBER "%" coverage? "{" override* "}"
coverage: "coverage" "(" NAME "on" "[" qname ("," qname)* "]" ")"
override: qname "{" assign ("," assign)* "}"
assign: NAME "=" value

dataset_def: "dataset" NAME "{" ds_opt* "}"
ds_opt: "seed" NUMBER | "volume" qname "=" NUMBER | "target" "env" STRING
      | "as_of" STRING | "scenarios" NAME

param_def: "param" NAME ":" NAME "=" "input" "(" STRING ("," "default" "=" value)? ")"

expr: or_expr
or_expr: and_expr ("or" and_expr)*
and_expr: cmp ("and" cmp)*
cmp: operand (COMPARATOR operand)?
   | operand "in" "(" value ("," value)* ")"
operand: qname | value | func_call
func_call: NAME "(" (expr ("," expr)*)? ")"
COMPARATOR: "==" | "!=" | ">=" | "<=" | ">" | "<"
qname: NAME ("." NAME)*
range: NUMBER ".." NUMBER
value: STRING | NUMBER | "null"
arglist: arg ("," arg)*
arg: (NAME "=")? (value | NAME | func_call | range)

NAME: /[A-Za-z_][A-Za-z0-9_]*/
STRING: /"[^"]*"/
NUMBER: /-?\d[\d_]*(\.\d+)?/
%import common.WS
%ignore WS
%ignore /\/\/[^\n]*/
```

### 5.2 Compiler pipeline

`compile(model_version_id) -> (GenerationPlan, list[Diagnostic])`

Stages, in order, each producing diagnostics rather than raising:

1. **parse** — Lark → AST (`app/mdl/ast.py` dataclasses).
2. **resolve** — bind every `qname` to a system/table/column id. Unresolved name
   → `ERR_UNRESOLVED`.
3. **typecheck** — generator arguments match the generator's declared signature;
   comparison operand types are compatible.
4. **fit check** — every generator's possible output fits the column's physical
   type. Cases to implement: `id`/`regex` pattern length vs `VARCHAR(n)`;
   longest `enum` or valueset tuple value vs `VARCHAR(n)`; `decimal` range vs
   `NUMBER(p,s)`. → `ERR_FIT`.
5. **flow conformance** — every cross-system link must run parent→child along
   the `system_flow` DAG, unless `back_reference`. → `ERR_FLOW_DIRECTION`.
6. **link checks** — conditional links into the same target column must have
   pairwise-disjoint `when` conditions (compare literal equality sets;
   non-literal conditions produce `WARN_DISJOINT_UNPROVEN`). Cardinality
   `min <= max`, `min >= 0`.
7. **cycle check** — table-level dependency graph must be acyclic after removing
   `two_pass` edges. → `ERR_CYCLE`.
8. **rule satisfiability (shallow)** — for each table, if two hard rules with
   overlapping `when` conditions narrow one column's domain to the empty set,
   report `ERR_RULE_CONFLICT` naming both rules.
9. **aggregate feasibility** — call the solver's `check_feasible` with the
   scenario-implied target range and row-class specs (§ 7.7). → `ERR_AGG_INFEASIBLE`.
10. **emit IR** — build `GenerationPlan`; compute `content_hash` = sha256 of the
    canonical JSON of the IR.

### 5.3 Diagnostic model

```python
@dataclass
class Diagnostic:
    severity: Literal["error", "warning"]
    code: str                 # 'ERR_FIT'
    message: str              # human-readable, names the fix
    file: str | None          # 'cards.mdl'
    line: int | None; col: int | None
    length: int | None        # for editor squiggles
```

The `/api/models/{id}/compile` endpoint returns these; the Monaco editor renders
them as markers (§ 10.4).

### 5.4 Round-trip requirement

`emitter.py` must render model objects back to MDL text such that
`parse(emit(model)) == model` structurally. The UI edits objects; the editor
edits text; both must converge. **Acceptance test:** `test_mdl_roundtrip`.

---

## 6. Backend service design

FastAPI app with routers per resource. Each router is thin: validate → call a
service function → return a pydantic response. Business logic lives in
`app/engine/`, `app/mdl/`, `app/importers/` — never in routers.

**Session handling:** one SQLAlchemy session per request via dependency.
Long-running generation does **not** hold a request session; `runs_api.create_run`
persists a `run` row with status `queued`, schedules the job on a background
task, and returns immediately. The frontend polls `GET /api/runs`.

**Background execution:** FastAPI `BackgroundTasks` for v1 (single process).
Wrap the entry point so a crash marks the run `failed` with the traceback in
`run.error`. Interface must be swappable for Celery/Temporal later:

```python
# app/engine/runner.py
def execute_run(run_id: UUID) -> None: ...       # the only entry point
```

---

## 7. Generation engine

### 7.1 Plan IR (`app/engine/plan.py`)

```python
@dataclass(frozen=True)
class ColumnPlan:
    name: str; dtype: str; length: int | None
    precision: int | None; scale: int | None; nullable: bool
    generator: dict                     # {"kind": "...", ...}
    valueset: str | None; valueset_field: str | None
    is_pk: bool

@dataclass(frozen=True)
class TablePlan:
    system: str; name: str
    columns: tuple[ColumnPlan, ...]
    parent_links: tuple[str, ...]       # link names that populate this table
    volume_expr: str | None             # explicit volume, else derived

@dataclass(frozen=True)
class LinkPlan:
    name: str; kind: str
    src_system: str; src_table: str; src_column: str
    tgt_system: str; tgt_table: str; tgt_column: str
    condition: dict | None; transform_fn: str | None
    card_min: int; card_max: int
    back_reference: bool; two_pass: bool

@dataclass(frozen=True)
class GenerationPlan:
    content_hash: str; seed: int; as_of: date | None
    system_order: tuple[str, ...]                 # flow-topological
    waves: tuple[tuple[str, ...], ...]            # each wave: fully-qualified table names
    tables: dict[str, TablePlan]                  # keyed 'SYSTEM.TABLE'
    links: dict[str, LinkPlan]
    rules: tuple[dict, ...]
    aggregates: tuple[dict, ...]
    valuesets: dict[str, dict]                    # {"fields":[...], "rows":[{values,weight}]}
    scenarios: tuple[dict, ...]
    volumes: dict[str, int]
```

### 7.2 Planner (`planner.py`) — ordering is a hard requirement

```python
def system_order(flows: list[tuple[str, str]], systems: list[str]) -> list[str]
def build_waves(plan_tables, links, system_rank) -> list[list[str]]
```

Algorithm:
1. Topologically sort **systems** by `system_flow`. Cycle → `ERR_FLOW_CYCLE`.
2. Build a table dependency graph: edge `A → B` when a non-`two_pass` link has
   source in A and target in B, or when B has an FK generator referencing A.
3. Topologically sort tables, **using the system rank as the primary sort key**
   so no child-system table is ever scheduled before a parent-system table it
   depends on. Tables with equal rank and no mutual dependency share a wave.
4. `two_pass` links are excluded from the graph and recorded for § 7.8.

**Acceptance test `test_planner_respects_flow`:** with flow
`CORE → CARDS → PAYMENTS`, no PAYMENTS table may appear in a wave before every
CORE table it transitively depends on.

### 7.3 Deterministic RNG (`rng.py`)

```python
def cell_rng(seed: int, table: str, row_index: int, column: str) -> random.Random:
    h = hashlib.blake2b(f"{seed}|{table}|{row_index}|{column}".encode(), digest_size=8)
    return random.Random(int.from_bytes(h.digest(), "big"))
```

Every draw in the engine must come from `cell_rng`. No module-level `random`.
**Acceptance test `test_determinism`:** two runs with the same plan hash + seed
produce byte-identical Parquet output.

### 7.4 Scenario allocation (`allocator.py`)

```python
def allocate_scenarios(total_rows: int, scenarios: list[dict], rng) -> list[int]
def pairwise_matrix(dims: dict[str, list[str]]) -> list[dict[str, str]]
```

* Weights are normalised then apportioned with **largest remainder** so the
  quotas sum exactly to `total_rows`.
* `pairwise_matrix` implements IPOG: seed with the two largest dimensions'
  cartesian product, then for each remaining dimension extend horizontally
  (choose the value covering most uncovered pairs) and vertically (add rows for
  pairs still uncovered). Assert every value pair appears at least once.
* Boundary injection: unless a scenario sets `boundaries=false`, mark
  `ceil(0.02 * quota)` rows per table as boundary rows; § 7.5 then draws min/max
  values for eligible columns.

**Acceptance test `test_pairwise_covers_all_pairs`** over 3 dims of sizes 4,4,3.

### 7.5 Value generation (`generators.py`)

Registry `GENERATORS: dict[str, Generator]`, each:

```python
class Generator(Protocol):
    def domain(self, spec: dict, col: ColumnPlan) -> Domain: ...
    def draw(self, spec: dict, col: ColumnPlan, rng, ctx: RowContext) -> Any: ...
```

Implement for v1: `id(pattern)` (`#`=digit, `A`=letter, literals kept),
`enum(values, weights)`, `int(lo..hi)`, `decimal(lo..hi, distribution)`,
`date(range | after=expr)`, `string(n)`, `regex(pattern)` (use `exrex`-style
generation or a hand-rolled generator for the limited syntax `[]{}|.` — keep it
simple), `sequence(start, step)`, `persona.name(locale)`, `persona.email`,
`fk(qname)`, `derived(template)`, `lookup(ref)`, `describe(text)` (v1: resolve to
a canned list from the copilot stub).

`RowContext` gives access to already-generated sibling values, the parent row,
and the row's scenario overrides.

**Column generation order within a row:** discriminator columns (those named in
any rule's `when` or any conditional link's condition) first, then columns whose
domains are narrowed by rules, then the rest. Compute this order once per table
at plan time.

### 7.6 Rules (`rules.py`)

```python
def narrow_domain(col: str, base: Domain, rules: list[dict], ctx: RowContext) -> Domain
```

Forward checking only: evaluate each rule's `when` against the partially-built
row; if true, intersect the target column's domain with the rule's `then` set.
Empty intersection → raise `RuleConflict` naming the rules (this should have been
caught at compile time; treat it as a bug surfaced at runtime).
Soft rules (`prefer ... probability p`) bias the draw instead of restricting it.

### 7.7 Aggregate constraints (`engine/aggregate/`)

**Copy `aggregate_engine/` from `aggregate-constraint-engine.zip` into
`app/engine/aggregate/` unchanged**, including its tests (move them under
`backend/tests/aggregate/`). It is already tested; do not reimplement.

Public functions used by the engine: `RowSpec`, `allocate`, `check_feasible`,
`Infeasible`, `repair_running_balance`, `balance_journal`, `rollup`, `schedule`.

Integration in `runner.py`, after child rows exist as templates but before their
amount column is finalised:

```python
for agg in plan.aggregates:                    # mode == 'allocate'
    for parent_row in parent_rows:
        target_minor = to_minor(parent_row[agg.target]) - to_minor(parent_row[agg.opening])
        specs = [row_spec_for(child, agg.row_classes) for child in children_of(parent_row)]
        amounts = allocate(target_minor, specs, cell_rng(seed, table, i, "AMOUNT"))
        if agg.guard_floor is not None:
            amounts = repair_running_balance(amounts, opening_minor, floor_minor)
        assign(children, amounts)
```

`Infeasible` during a run is a bug (compile stage 9 should have caught it) —
fail the run with the solver's message verbatim, which already names the fix.

### 7.8 Links, key vault, two-pass (`keyvault.py`, `links.py`, `twopass.py`)

* As each table completes, publish `{'SYSTEM.TABLE.COLUMN': polars.Series}` of
  generated values to the key vault.
* **Direct link:** sample from the source series honouring cardinality; track
  per-parent child counts so `one_to_many(1..4)` yields 1–4 children per parent.
* **Conditional link:** first generate the discriminator column; rows matching
  the condition draw from the linked series, others fall through to their own
  generator or another disjoint conditional link.
* **Function link:** apply the registered transform to the drawn source value.
  v1 transform registry is a Python dict of pure functions in
  `app/engine/transforms.py` (ship `identity`, `strip_prefix`, `mod97_check`).
* **Two-pass:** columns targeted by a `two_pass` back-reference are left null in
  pass 1 and recorded in a deferred registry. After all waves complete, pass 2
  resolves them from the key vault and writes a **patch artifact**
  (`kind='patch'`, columns = target PK + the deferred columns). Patches never
  create rows.

### 7.9 Schema import & drift (`importers/`)

```python
def import_sqlalchemy(url: str, schema: str | None) -> ImportedSchema
def import_openapi(spec_url_or_path: str) -> ImportedSchema
def diff(existing: list[ColumnDef], imported: ImportedSchema) -> list[DriftItem]
```

Drift classification: column present in source only → `added`; in model only →
`removed`; type/length/nullability differs → `changed`; a change that
invalidates a rule, link or enum domain → `breaking` (set `breaking=true` and
name the impacted objects in `detail`). Accepting a drift item applies it to the
model; `breaking` items require an explicit accept and re-run of compile.

### 7.10 Validator & report (`validator.py`)

After generation, re-evaluate every hard rule, link cardinality, aggregate
identity and fit constraint against the produced frames and emit `RunReport`
(§ 9.7). Hard rule pass rate below 100 % fails the run.

---

## 8. Ingestion adapters

```python
# app/adapters/base.py
class IngestionAdapter(ABC):
    name: str
    supports_patch: bool

    @abstractmethod
    def validate_target(self, profile: dict) -> list[str]: ...
    @abstractmethod
    def load(self, system: str, table: str, frame: "pl.DataFrame", profile: dict) -> int: ...
    def apply_patch(self, system: str, table: str, frame: "pl.DataFrame",
                    pk_cols: list[str], profile: dict) -> int:
        raise NotImplementedError
    @abstractmethod
    def verify(self, system: str, table: str, expected_rows: int, profile: dict) -> dict: ...
```

v1 adapters: `file` (writes CSV + Parquet under `runs/{run_id}/{system}/{table}.csv`,
`supports_patch=True` by emitting a `*.patch.csv`), `jdbc` (SQLAlchemy
`insert().executemany`, patches via keyed `UPDATE`), `rest` (POST per row or
batch, `PATCH` for patches, honouring a per-system rate limit).

**Ingestion order is the declared system flow order.** A child system's load must
not start until every parent system's load has been verified. Patch artifacts are
applied only after all inserts across all systems have been verified.
If a system's adapter has `supports_patch=False` but the plan contains a two-pass
link targeting it, compile stage 5 emits `WARN_NO_PATCH_SUPPORT`.

---

## 9. REST API contract

Base path `/api`. All responses JSON. Errors:
`{"detail": "...", "code": "ERR_..."}` with appropriate 4xx/5xx.

### 9.1 Bootstrap
`GET /api/bootstrap?model_version_id=...` → everything the Studio needs on load.
```jsonc
{
  "model": {"id":"...","name":"release_2026_R3","seed":84921,"env":"SIT2",
            "hash":"a41f9c","flow":["Core banking","Cards","Payments"]},
  "systems": [{"id":"...","name":"CORE_BANKING","displayName":"Core banking","lane":0}],
  "tables":  [{"id":"...","system":"core","name":"CUSTOMER","x":30,"y":60,
               "cols":[{"id":"...","name":"CUST_ID","dtype":"VARCHAR","length":12,
                        "nullable":false,"isPk":true,"tags":"pk · id","link":"cust-card",
                        "pick":null,"generator":{"kind":"id","pattern":"CIF#########"}}]}],
  "links":   [{"id":"cust-card","label":"CUSTOMER.CUST_ID → CARD_MASTER.HOLDER_REF",
               "type":"Direct","condition":null,"cardinality":"one_to_many(1..4)",
               "source":{"node":"CUSTOMER","col":"CUST_ID"},
               "target":{"node":"CARD_MASTER","col":"HOLDER_REF"}}],
  "valuesets":[{"id":"ENTITY_TYPES","fields":["code","description","category"],
                "rows":[{"values":["BR","Branch","INTERNAL"],"weight":50}]}],
  "scenarios":[{"id":"s1","name":"Happy path retail","weight":55,"color":"var(--purple-400)"}],
  "runs":    [ /* § 9.7 RunSummary[] */ ],
  "drift":   [{"id":"d1","kind":"added","what":"CUSTOMER.PREF_LANG  varchar(5)",
               "note":"copilot suggests: enum(...)","state":"accepted","breaking":false}],
  "files":   {"cards.mdl":"system CARDS {...}"}
}
```

### 9.2 Model objects
| Method | Path | Body / notes |
|---|---|---|
| `PUT` | `/api/tables/{tableId}/columns/{name}` | `{name,dtype,length,precision,scale,nullable,isPk,generator,pick}` → column |
| `POST` | `/api/tables/{tableId}/columns` | create |
| `DELETE` | `/api/tables/{tableId}/columns/{name}` | |
| `PUT` | `/api/tables/{tableId}/position` | `{x,y}` (canvas drag persistence) |
| `POST` | `/api/links` | full link object → link |
| `PUT` | `/api/links/{id}` | update |
| `DELETE` | `/api/links/{id}` | |
| `PUT` | `/api/valuesets/{id}` | `{fields, rows}` |
| `POST` | `/api/valuesets/{id}/import-csv` | multipart file → parsed valueset |
| `PUT` | `/api/scenarios` | array of scenarios (replace) |
| `PUT` | `/api/files/{name}` | `{content}` — MDL source, triggers re-parse |

### 9.3 Compile
`POST /api/models/{id}/compile` →
```jsonc
{"ok": false, "contentHash": null,
 "diagnostics":[{"severity":"error","code":"ERR_FIT",
   "message":"CARD_MASTER.LIMIT_AMT: decimal range min > max",
   "file":"cards.mdl","line":16,"col":34,"length":22}]}
```

### 9.4 Runs
`POST /api/runs` `{"modelVersionId":"...","volumes":{"CORE_BANKING.CUSTOMER":5000},
"targetEnv":"SIT2","seed":84921,"dryRun":false}` → `{"runId":"...","runNumber":2482}`
`GET /api/runs?modelVersionId=...` → `RunSummary[]`
`GET /api/runs/{id}` → full run incl. report
`GET /api/runs/{id}/artifacts/{artifactId}` → file download

### 9.5 Schema import
`POST /api/systems/{id}/scan` → `DriftItem[]`
`PATCH /api/drift/{id}` `{"state":"accepted"|"skipped"|"pending"}`
`POST /api/drift/apply` `{"modelVersionId":"..."}` → applies all accepted items

### 9.6 Copilot (stubbed in v1)
`POST /api/copilot/suggest` `{"kind":"rule"|"generator"|"valueset","context":"..."}`
→ `{"mdl":"rule kyc_gate on ...","explanation":"..."}`
v1 returns canned suggestions keyed by `kind`; the interface must not change when
a real model is wired in.

### 9.7 RunReport shape
```jsonc
{"id":"...","runNumber":2481,"when":"09 Jul 2026, 14:12","status":"verified",
 "rows":54650,"rulePass":"100%","coverage":"96%","elapsed":"6m 41s",
 "systems":[{"name":"Core banking","detail":"16,400 rows · JDBC · 1m 12s","ok":true}],
 "rules":[{"name":"kyc_gate","result":"12050/12050","ok":true,"soft":false}],
 "coverageMatrix":{"dims":["SEGMENT","ACC_TYPE"],
   "rows":["RETAIL","PREMIUM","NRI","CORP"],"cols":["SAV","CUR","OD","FD"],
   "counts":[[8210,3100,900,2400],[...]],"excluded":[[false,false,false,false],[...]]},
 "crossChecks":[{"name":"card holders exist in core banking","passed":500,"total":500}]}
```

---

## 10. Frontend specification

The React prototype in `dataforge-studio.zip` is the **visual source of truth**.
This section restates it precisely so it can be rebuilt without the archive.

### 10.1 Design tokens — exact values (`styles.css`)

```css
:root{
  --bg:#fafaf8; --surface:#ffffff; --surface-2:#f4f4f1;
  --border:#e4e3de; --border-strong:#cfcec8;
  --text:#1c1c1a; --text-2:#5f5e5a; --text-3:#93928c;
  --purple-50:#eeedfe; --purple-400:#7f77dd; --purple-600:#534ab7; --purple-800:#3c3489;
  --teal-50:#e1f5ee; --teal-200:#5dcaa5; --teal-400:#1d9e75; --teal-600:#0f6e56; --teal-800:#085041;
  --coral-50:#faece7; --coral-200:#f0997b; --coral-400:#d85a30; --coral-600:#993c1d; --coral-800:#712b13;
  --amber-50:#faeeda; --amber-600:#854f0b;
  --red-50:#fcebeb; --red-600:#a32d2d; --red-800:#791f1f;
  --green-50:#eaf3de; --green-800:#27500a;
  --mono:"SFMono-Regular",ui-monospace,Menlo,Consolas,monospace;
  --sans:"Inter",-apple-system,"Segoe UI",Roboto,sans-serif;
  --radius:8px;
}
```

System colour assignment: core banking = purple, cards = teal, payments = coral;
further systems cycle through the same families.

### 10.2 App chrome (all screens)

* **Shell**: max-width 1180px, centred, `--surface` card with 1px `--border`,
  radius 14px, `overflow:hidden`.
* **TopBar** (height ~52px, bottom border): 30px rounded logo tile
  (`--purple-50` bg, `--purple-800` glyph `{}`) · title "DataForge studio" 14px/600
  · subtitle `{modelName} · seed {seed} · {env}` 11.5px `--text-3` mono ·
  right group: validity pill, `Validate` button, primary `Generate {volume}`
  button (dark `--text` bg, white text). **The Generate button is disabled while
  compile diagnostics contain any error**, with tooltip "Fix the compile error in
  the MDL editor first".
* **Tabs**: `Linkage canvas · MDL editor · Valuesets · Scenarios · Runs · Schema
  import`. Active tab: 600 weight, 2px bottom border `--text`. Right-aligned
  flow note in mono 11.5px: `flow: Core banking → Cards → Payments`.
* **StatusBar** (top border, mono 11.5px `--text-3`): `{n} systems · {n} tables ·
  {n} links · {n} valuesets · {n} rules` | `models/{label} · #{hash}` | right:
  API base or `mock adapter`.
* **Pills**: `.ok` teal-50/teal-800, `.warn` amber-50/amber-600,
  `.err` red-50/red-800; 11px, radius 999px, padding 3px 10px.

### 10.3 Screen — Linkage canvas

Layout: canvas region 420px tall, then a two-column panel row (1.15fr / 1fr)
separated by a 1px border.

**Canvas.** Absolutely-positioned swimlane backdrop (one equal-width lane per
system, dashed `--border-strong` separators, lane badge pill top-left in the
system's 50/600 colours), with React Flow rendered transparently on top
(`Background` gap 22 colour `--border`, `Controls` without the interactive lock).
Lane order = declared system flow order, left to right.

**TableNode** (custom node, width 224px, radius 9px, 1px `--border-strong`,
subtle shadow):
* header bar: table name 12px/600 on the system's 50-tint, 600-tint text
* one row per column: `name` (left) and computed **type label** (right, mono
  11.5px `--text-3`) where the label is `VARCHAR(12)`, `NUMBER(18,2)`, `DATE`…
* React Flow `Handle` target on the left edge (7px, `--border-strong`, id
  `t:{col}`) and source on the right edge (7px, `--purple-400`, id `s:{col}`)
* clicking a column selects it → opens the **Column** inspector; selected column
  row gets `--purple-50` background
* final row `+ add column`, centred, `--text-3`

**Edges** are derived from the link list, styled by kind: Direct = solid
`--purple-400`; Conditional = dashed `6 4` `--coral-400`; Function/back-reference
= dotted `2 4` `--border-strong`. Selected edge stroke 2.4 vs 1.7. Labels are
mono 10.5px on a `--surface` rounded chip (radius 8, padding 7×3): cardinality
range for direct (`1..4`), `when CPTY_TYPE = "ACCOUNT"` for conditional,
`two-pass` for back-references. Arrowheads `ArrowClosed` 16px `#888780`.

**Interactions:** drag nodes (persist via `PUT /position`, debounce 500 ms);
drag from a source handle to a target handle creates a link (`POST /api/links`,
default kind Direct, cardinality `one_to_many(1..1)`) and selects it; click an
edge to open the Link inspector.

**Left panel — inspector** with a Link/Column segmented toggle:
* *Link mode*: link label in mono; segmented `Direct | Conditional | Function`;
  when Conditional → row `when [column ▾] [op ▾] [value input]`; when Function →
  `via fn [select]` + hint "sandboxed plugin"; always `cardinality [text input]`;
  helper text about drag-to-link.
* *Column mode*: `name` text input (upper-cases, strips non `[A-Z0-9_]`);
  `data type` select (VARCHAR, CHAR, NUMBER, INTEGER, DATE, TIMESTAMP, BOOLEAN);
  conditional `length` input for VARCHAR/CHAR, `precision`+`scale` for NUMBER;
  `nullable` checkbox; **`value source` select** (generator (default) | each
  valueset) and, when a valueset is chosen, a `field` select; a live binding note
  — when ≥2 columns of the same table bind the same valueset, render
  `one draw per row fills: ENTITY_CODE (code) + ENTITY_DESC (description)`;
  a live fit warning in `--red-600` when the longest bound value exceeds the
  declared length; footer `sqltype varchar(12) not_null — fit check runs at
  compile time` in mono `--text-3`.

**Right panel — scenario allocation:** one row per scenario with
`name` / `weight% · rowcount`, a 6px track (`--surface-2`) and fill in the
scenario colour; footer `pairwise coverage 96% · est. N accounts · N txns`.

### 10.4 Screen — MDL editor

Two columns: 172px file tree, then editor.
* **File tree** on `--bg`, header `models/{label}` mono 11px `--text-3`, one row
  per `.mdl` file; active file `--surface` bg, 600 weight, 2px left border
  `--text`; trailing `plugins/` row.
* **Monaco**, height 340px, language id `mdl` registered with a Monarch tokenizer
  (keywords → `--purple-600`, generators/types → `--teal-600`, strings →
  `--coral-600`, numbers → `--text`, comments → `--text-3`) and theme `mdl-light`
  (`editor.background:#ffffff`, `lineHighlightBackground:#f4f4f1`). Options:
  fontSize 13, mono family, `minimap:false`, `scrollBeyondLastLine:false`,
  padding top 10.
* **Diagnostics**: on change (debounced 400 ms) `PUT /api/files/{name}` then
  `POST /compile`; render returned diagnostics via
  `monaco.editor.setModelMarkers`. The error count drives the TopBar pill and the
  Generate button's disabled state.
* **Copilot card** below the editor: 1px `--purple-400` border, `--purple-50` bg,
  radius 10; header `✦ Copilot · from your note "…"` 11.5px/600 `--purple-800`;
  a white `pre` block with the proposed MDL; actions `Insert rule` (applies the
  edit to the open file and re-compiles), `Edit`, `Dismiss`.

### 10.5 Screen — Valuesets

Two columns: 172px list of valuesets (plus `+ new valueset`), then the editor
panel.
* Header row: valueset name (h3), a pill `{n} tuples · total weight {w}`, right
  group `Import CSV` (real file input → `POST /import-csv`) and
  `Sync from reference table`.
* **Tuple grid**: CSS grid `repeat(nFields, minmax(120px,1fr)) 84px 40px`; header
  row of field names in mono 11px `--text-3`; each row = one text input per field
  (mono) + weight input + `×` remove button. Footer `+ add tuple`.
* **Bindings** section: one `ListRow` per table binding this valueset, reading
  `one draw per row fills ENTITY_CODE (code) + ENTITY_DESC (description)`.
* **Fit check** block: red lines listing any bound column whose declared length
  is shorter than the longest value in its field; otherwise a teal
  `✓ fit check: all bound columns hold the longest values`.

### 10.6 Screen — Scenarios

Two panels. Left: one range slider per scenario (0–100, accent `--purple-600`)
with name and `{weight}%`; a `total {n}%` pill (`ok` at 100, else `warn`) and a
`Normalize to 100%` button that apportions by largest remainder. Right: live
allocation preview identical in style to § 10.3's right panel, plus downstream
estimates and a note that coverage scenarios expand to a pairwise covering array.

### 10.7 Screen — Runs

* **Run bar**: `Run [select ▾]` listing `#{n} · {when} · {status}`, a status pill,
  right group `Download report`, `Regenerate`.
* **Metric grid**: 4 cards (`--surface-2`, radius 9) — Rows generated, Hard rule
  pass (value in `--teal-800`), Pairwise coverage, Elapsed. Value 21px/600.
* **Left panel — Ingestion by system · flow order**: one ListRow per system in
  declared flow order with a tick and `16,400 rows · JDBC · 1m 12s`; the two-pass
  phase appears as a final row `Pass-2 patches → Core banking`. Footer line with
  cross-system spot-check results.
* **Right panel — Rule assertions** (tick teal for hard, `~` amber for soft, right
  aligned counts) then **Coverage heat map**: CSS grid `70px repeat(nCols,1fr)`,
  17px cells; colour ramp by row count `--teal-50 → --teal-200 → --teal-400`;
  rule-excluded combinations render as `--surface-2` with a dashed
  `--border-strong` border. Legend: `dashed = excluded by rules · darker = more rows`.
* While `status==='running'`, poll `GET /api/runs` every 1.5 s; show `…` in place
  of ticks and `—` for metrics.

### 10.8 Screen — Schema import

* Bar: system select, scan summary text, right group `{n} pending review` pill,
  `Re-scan`, primary `Apply {n} accepted`.
* **Drift list** (1px border, radius 10, rows separated by 1px `--border`): each
  row = a fixed-width 68px kind chip (`added` green-50/green-800, `changed`
  amber-50/amber-600, `removed` and `breaking` red-50/red-800), a body with the
  target in mono 12px and a note in 11.5px `--text-3` (`--red-600` when
  breaking), and right-aligned actions. Breaking rows get a `--red-50` row
  background while pending, and their accept button reads `Review + accept`.
  Accepted/skipped rows show a pill and an `Undo` button.
* Footer note: accepted changes are committed to a branch for review before merge.

### 10.9 State management

Single Zustand store `useStudio` holding `model, systems, tables, links,
valuesets, scenarios, runs, drift, files, diagnostics, selection`. All mutations
call the API and update the store optimistically, rolling back on error. The
store must expose `errorCount` derived from `diagnostics` — the TopBar and the
Generate button read only that.

---

## 11. Non-functional requirements

**Determinism.** `(content_hash, seed, volumes)` fully determines the output.
Enforced by § 7.3 and `test_determinism`.

**Performance (v1 target).** 1 million total rows generated and validated in
under 3 minutes on 4 cores. Generate per table into polars frames; parallelise
across tables within a wave using a process pool sized to `cpu_count()`.

**Safety.** Environment profiles carry an `allow_write: bool`; a run against a
profile without it is rejected. Volume cap per environment (`max_rows`). `dryRun`
produces plan + report with no adapter writes. All target credentials come from
env vars, never the database.

**Observability.** Structured JSON logs with `run_id` on every line; a
`GET /api/runs/{id}/log` endpoint streaming the run log.

**Data safety.** The platform generates synthetic data only. There is no code
path that reads rows from a target system except metadata (`importers/`) and
verification counts.

---

## 12. Test plan

### 12.1 Layers
* **Unit** — `mdl/`, `engine/`, `adapters/` in isolation.
* **Integration** — FastAPI + Postgres via `httpx.AsyncClient` and a
  testcontainer/`pytest-postgresql`.
* **Golden** — the sample model in `samples/retail_bank/` generated at a fixed
  seed; a checked-in fingerprint of the output must not change.
* **Frontend** — Vitest + Testing Library for the inspector logic
  (fit-check warning, binding note, weight normalisation).

### 12.2 Named acceptance tests (referenced by the milestones)

| Test | Asserts |
|---|---|
| `test_mdl_parse_sample` | all six sample `.mdl` files parse |
| `test_mdl_roundtrip` | `parse(emit(model))` equals `model` structurally |
| `test_fit_check_flags_short_varchar` | `id("CIF#########")` into `VARCHAR(8)` → `ERR_FIT` |
| `test_flow_conformance_rejects_reverse_link` | PAYMENTS→CORE link without `back_reference` → `ERR_FLOW_DIRECTION` |
| `test_conditional_links_must_be_disjoint` | two `when` clauses on the same target with overlapping literals → error |
| `test_planner_respects_flow` | § 7.2 |
| `test_pairwise_covers_all_pairs` | § 7.4 |
| `test_scenario_quotas_sum_exactly` | largest-remainder apportionment |
| `test_determinism` | identical output for identical inputs; different for a different seed |
| `test_valueset_pick_is_correlated` | for every generated row, `(ENTITY_CODE, ENTITY_DESC)` is a tuple that exists in the valueset |
| `test_cardinality_respected` | every customer has 1–4 cards |
| `test_conditional_link_only_binds_matching_rows` | `CPTY_VALUE ∈ ACC_NO` exactly where `CPTY_TYPE='ACCOUNT'` |
| `test_two_pass_patch_produced` | pass-1 column null; patch artifact contains PK + resolved value |
| `test_rule_narrows_domain` | `SEGMENT='CORP'` ⇒ `ACC_TYPE ∈ {CURRENT,OD}` for all rows |
| `test_aggregate_balances_exactly` | Σ child amounts == parent target, to the minor unit |
| `test_running_balance_never_below_floor` | § 7.7 guard |
| `test_ingestion_order_follows_flow` | recorded adapter call order matches system flow |
| `test_validator_fails_on_broken_rule` | injected bad row ⇒ run status `failed` |
| `test_api_bootstrap_shape` | response matches § 9.1 keys |
| `test_run_end_to_end` | POST run → poll → status `verified`, artifacts exist |

### 12.3 Definition of Done (whole project)
`pytest` green; `npm run build` clean; `docker compose up` yields a working
Studio at `localhost:5173` against the API at `localhost:8000`; the golden
sample generates and ingests to the `file` adapter with a verified run report.

### 12.4 Sample model (`samples/retail_bank/`)
Three systems — `CORE_BANKING` (CUSTOMER, ACCOUNT), `CARDS` (CARD_MASTER),
`PAYMENTS` (TXN) — with: `flow CORE_BANKING -> CARDS -> PAYMENTS`; a direct link
CUSTOMER.CUST_ID→CARD_MASTER.HOLDER_REF `one_to_many(1..4)`; a conditional link
ACCOUNT.ACC_NO→TXN.CPTY_VALUE `when CPTY_TYPE == "ACCOUNT"` `one_to_many(0..50)`;
a two-pass back-reference CARD_MASTER.CARD_STATUS→CUSTOMER.LATEST_CARD_STATUS;
valueset `ENTITY_TYPES` bound to CUSTOMER.ENTITY_CODE/ENTITY_DESC; rules
`kyc_gate`, `corporate_products`, `dormant_no_txn`; an aggregate constraint
`ACCOUNT.BALANCE = OPENING_BAL + sum(TXN.AMOUNT)` with SALARY/ATM/NEFT/POS row
classes; five scenarios summing to 100 % including one pairwise coverage
scenario. This model is the fixture for most acceptance tests.

---

## 13. Build plan

Each milestone is independently demoable. Do not proceed until its tests pass.

### M0 — Skeleton (0.5 day)
Repo layout per § 3; `docker-compose.yml` (postgres 16, api, web); FastAPI app
with `/health`; Alembic initialised; Vite React TS app with tokens from § 10.1,
app shell (TopBar, Tabs, StatusBar) and six empty tab bodies.
**DoD:** `docker compose up` serves both; `/health` returns 200.

### M1 — Model & persistence
All § 4 tables + Alembic migration; ORM models; pydantic schemas; CRUD routers
for tables/columns/links/valuesets/scenarios; `GET /api/bootstrap`; seed script
loading `samples/retail_bank` **as objects** (not yet MDL).
**DoD:** `test_api_bootstrap_shape`; bootstrap returns the sample model.

### M2 — MDL compiler
Grammar, AST, parser, resolver, checker (all ten stages of § 5.2 except 9),
emitter, `POST /compile`.
**DoD:** `test_mdl_parse_sample`, `test_mdl_roundtrip`,
`test_fit_check_flags_short_varchar`, `test_flow_conformance_rejects_reverse_link`,
`test_conditional_links_must_be_disjoint`.

### M3 — Generation engine core
Plan IR, planner, RNG, generators, valuesets, key vault, direct + conditional +
function links, cardinality, file adapter, run orchestration, artifacts.
**DoD:** `test_planner_respects_flow`, `test_determinism`,
`test_valueset_pick_is_correlated`, `test_cardinality_respected`,
`test_conditional_link_only_binds_matching_rows`, `test_run_end_to_end`.

### M4 — Rules, scenarios, aggregates, two-pass
Rule narrowing; scenario quotas + IPOG pairwise + boundary injection; drop in the
aggregate engine and wire § 7.7; two-pass deferred columns and patch artifacts;
validator and `RunReport`.
**DoD:** `test_rule_narrows_domain`, `test_scenario_quotas_sum_exactly`,
`test_pairwise_covers_all_pairs`, `test_aggregate_balances_exactly`,
`test_running_balance_never_below_floor`, `test_two_pass_patch_produced`,
`test_validator_fails_on_broken_rule`.

### M5 — Studio: canvas, inspectors, valuesets
React Flow canvas per § 10.3 with drag-to-link and position persistence; link and
column inspectors including physical types and valueset binding; valuesets screen
per § 10.5 with CSV import and fit check; Zustand store.
**DoD:** manual walkthrough matches § 10.3/§ 10.5; Vitest covers fit-check and
binding-note logic.

### M6 — Studio: editor, scenarios, runs
Monaco with the `mdl` language + theme + live markers from `/compile`; copilot
card wired to the stub; scenarios screen with sliders and normalisation; runs
screen with polling, metrics, flow-ordered ingestion list, rule assertions and
coverage heat map.
**DoD:** editing MDL surfaces a real squiggle; Generate is gated by error count;
a run completes and renders a full report.

### M7 — Ingestion & schema import
JDBC and REST adapters with `verify()` and `apply_patch()`; flow-ordered
ingestion orchestration with checkpointing; schema import + drift detection +
apply; schema import screen per § 10.8.
**DoD:** `test_ingestion_order_follows_flow`; a JDBC round-trip into a scratch
Postgres schema verifies; drift on a changed column is detected and applied.

---

## 14. Decisions, risks, migration

**D1 — Python over JVM for v1.** Reuses the tested aggregate solver and shortens
the path to a working system. Migration path: the MDL grammar (Lark → ANTLR4),
the Plan IR (already language-neutral JSON) and the adapter SPI are the only
contracts that must be preserved; the engine is a pure function of
(plan, seed, volumes) and can be ported table-generator by table-generator.

**D2 — Forward checking only, no CP-SAT in v1.** Interlocked rules are rare and
detectable; the compiler reports them rather than solving them. If a real model
needs it, add OR-Tools behind `rules.narrow_domain` without changing callers.

**D3 — Background tasks, not a workflow engine.** Keeps v1 single-process. The
single entry point `execute_run(run_id)` is the seam for Temporal/Celery later.

**D4 — Copilot stubbed.** The endpoint shape is fixed now so the UI never
changes when a model is wired in.

**R1 — Grammar churn.** The DSL will evolve. Mitigate by keeping the Plan IR
stable and versioned (`ir_version` field) so the engine is insulated.

**R2 — Cardinality explosion.** `one_to_many(0..50)` over 5,000 accounts is up to
250,000 transactions. Enforce the per-environment `max_rows` cap at plan time and
show the estimate in the UI before the run starts.

**R3 — Fit checks vs generator expressiveness.** Regex generation can be hard to
bound. If a generator cannot prove its maximum length, emit
`WARN_FIT_UNPROVEN` rather than a false error.

---
---

# PART B — Source intelligence, mapping and migration (DataForge 2.0)

## 15. Part B scope

### 15.1 Goal

Connect to an existing system version, learn its structure and meaning into a
knowledge graph of claims, map it through a shared business model to another
version whose structure may be completely different, then migrate the data with
proof: every row accounted for, every control total exact, and every mapping
approved by a named person and tested on synthetic data before real data moves.
The same learned model also drives synthetic data generation for either version.

### 15.2 In scope

Traceability to the architecture doc's review findings is given in brackets.

- Evidence Graph as a Postgres-backed knowledge graph of claims, evidence and activities.
- Profiling, semantic typing, constraint discovery, application-SQL mining, entity clustering.
- A data-quality assessment report produced from profiles (finding 2).
- Concepts, realisations (`from` / `into`) and migrations in MDL, with blocking decisions.
- The 14 structural change patterns, including representation changes and the
  migrate-or-recompute decision for derived values (finding 4).
- The mapping discovery pipeline: retrieval, LLM rerank, global solve, transforms,
  examples on demand, confidence bands, impact-ordered review.
- A golden mapping set and evaluation harness; pinned model versions (finding 5).
- Two executors (reference interpreter and production executor), key crosswalk,
  row-conservation ledger, quarantine, partitioned and restartable loads.
- Cleansing rules, reject categories with owners, reject tracking (finding 2).
- Cutover-state inventory for in-flight business items (finding 3).
- Rehearsals (synthetic, masked-copy, dress), rehearsal-to-rehearsal diff with
  attribution (finding 9), sizing estimates (finding 11).
- Point-of-no-return recording and post-PONR policy (finding 10; reverse sync itself is not built).
- Behaviour-equivalence *support only*: output comparator, risk-segmented test pack,
  target-shaped synthetic data, behaviour sign-off as a gate (finding 1).
- Governance: role matrix, separation of duties, four-eyes production runs (finding 8).
- Control plane / data plane split as two deployables.
- Learned synthetic generation with a privacy gate.

### 15.3 Out of scope for Part B

- **Running v2 business processes** (end-of-day, interest, statements). Owned by the
  v2 application or UAT team; DataForge compares their outputs only (§ 23.8).
- **Reverse sync** after the point of no return (policy is recorded, not executed).
- **Pending decisions** from the review, built only as extension points (§ 29):
  downstream consumer analysis (finding 6), history scope tiers (finding 7),
  concept versioning (finding 12).
- A graph database, RDF/OWL reasoning, Ontop/virtual knowledge graphs, FIBO import,
  graph neural networks, and row-level deep generative models over raw customer data.

---

## 16. Additional technology

All Part A choices stand. Part B adds:

| Need | Choice | Notes |
|---|---|---|
| Sketches | `datasketch` | MinHash (containment), HyperLogLog (distinct counts) |
| SQL parsing and lineage | `sqlglot` | Parse views, procedures and application SQL; extract joins |
| Graph algorithms | `networkx` | Arborescence, shortest paths; in-memory per migration project |
| Assignment | `scipy.optimize.linear_sum_assignment` | Global attribute assignment |
| Calibration | `scikit-learn` `IsotonicRegression` | Per claim predicate, once enough labels exist |
| Embeddings | `pgvector` + `sentence-transformers` | Default model `all-MiniLM-L6-v2` (384 dims), pinned |
| LLM | Provider interface (`app/llm/provider.py`) | Any approved provider; model ID pinned in config and recorded on every activity |
| Worker queue | Postgres `job` table with `SELECT … FOR UPDATE SKIP LOCKED` | No broker needed for v2 |

No new database engine is introduced.

---

## 17. Repository additions

```
backend/app/
├── worker/                       # DATA PLANE deployable (separate process/image)
│   ├── main.py                   # polls `job`, runs only approved spec hashes
│   └── handlers.py               # profile | rehearse | migrate | compare | learn
├── kg/                           # Evidence Graph (knowledge graph of claims)
│   ├── models.py                 # ORM for kg_node, kg_claim, kg_evidence, kg_activity
│   ├── store.py                  # claim CRUD, supersede, bitemporal queries
│   ├── calibrate.py              # bands → isotonic per predicate
│   ├── structure.py              # global structure solve (arborescence)
│   ├── paths.py                  # in-memory graph load, k-shortest join paths
│   └── prov_export.py            # PROV-O JSON-LD export of approvals
├── intel/                        # source intelligence (runs in data plane)
│   ├── profiler.py  sketches.py  semtypes.py  constraints.py
│   ├── codemine.py               # sqlglot over views/procs/app SQL → JOINS_ON claims
│   ├── entities.py               # table clustering into entities
│   └── dq_report.py              # data-quality assessment from profiles
├── llm/                          # control plane only
│   ├── provider.py  stub_provider.py  api_provider.py
│   ├── grounding.py              # k-hop subgraph → compact prompt context
│   ├── masking.py                # format-preserving masking of samples
│   ├── contracts.py              # JSON schemas for every LLM output
│   ├── validate.py               # deterministic claim validator + one repair round
│   ├── prompts/                  # versioned templates: relationships, rerank, transform
│   └── golden.py                 # golden set evaluation harness
├── mapping/
│   ├── concepts.py               # compiled concept model
│   ├── patterns.py               # 14-pattern classifier
│   ├── retrieve.py  rerank.py  assign.py  impact.py
│   ├── pbe.py                    # transforms from examples
│   └── transforms/               # bank function library (see § 21.5)
├── migrate/
│   ├── plan.py                   # MappingPlan IR
│   ├── compose.py                # realise-from ∘ realise-into → MappingPlan
│   ├── interpreter.py            # reference interpreter (row by row)
│   ├── executor.py               # production executor (polars, partitioned)
│   ├── crosswalk.py  ledger.py  quarantine.py  cleanse.py
│   ├── cutover.py                # in-flight state inventory and rules
│   ├── delta.py                  # watermark-based delta catch-up
│   ├── sizing.py                 # throughput estimate
│   └── rehearsal.py              # rehearsal runs and run-to-run diff
├── verify/
│   ├── spec_checks.py  differential.py  metamorphic.py  mutation.py
│   ├── reconcile.py              # counts, control totals (aggregate engine), round trip
│   ├── comparator.py             # behaviour-output comparator (finding 1)
│   └── testpack.py               # risk-segmented test pack export
├── learn/
│   ├── degrees.py  marginals.py  constraints_learned.py
│   ├── privacy.py                # k-threshold, distance-to-closest-record, membership test
│   ├── fidelity.py               # fidelity report (§ 24.5)
│   ├── sequences.py              # transaction sequence models (§ 24.6)
│   ├── edge_patterns.py          # rare-but-valid pattern mining (§ 24.7)
│   ├── scale.py                  # volume scaling (§ 24.8)
│   └── relearn.py                # versioned models and drift per release (§ 24.9)
└── governance/
    ├── roles.py                  # role matrix and checks
    ├── signoff.py                # sign-off records and gates
    └── audit.py                  # OpenLineage emission, audit trail queries
samples/legacy_v1_to_core_v2/     # Part B fixture, see § 27.4
```

Frontend additions under `src/screens/`: `SourcesScreen`, `EvidenceScreen`,
`ConceptsScreen`, `MappingReviewScreen`, `MigrationScreen`, `ReconcileScreen`,
`SignoffScreen` (specified in § 26).

---

## 18. Data model additions (PostgreSQL)

Conventions from § 4 apply (UUID keys, `created_at`, `updated_at`).
Enable `CREATE EXTENSION IF NOT EXISTS vector;`.

### 18.1 Versions and the Evidence Graph

```sql
CREATE TABLE system_version (
  id UUID PRIMARY KEY,
  system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  label text NOT NULL,                       -- 'LEGACY_V1', 'CORE_V2'
  role text NOT NULL,                        -- source | target
  connection_profile text NOT NULL,
  code_location text,                        -- path/URL of application code, optional
  frozen_at timestamptz,                     -- snapshot is immutable once set
  UNIQUE (system_id, label));

CREATE TABLE kg_activity (                   -- PROV-O: Activity + Agent
  id UUID PRIMARY KEY,
  type text NOT NULL,                        -- profiling | constraint_discovery | code_mining |
                                             -- llm_proposal | llm_rerank | review | calibration
  agent_kind text NOT NULL,                  -- algorithm | model | human
  agent_id text NOT NULL,                    -- 'profiler', 'claude-…', user id
  agent_version text NOT NULL,               -- algorithm version or pinned model id
  started_at timestamptz NOT NULL, ended_at timestamptz,
  inputs jsonb NOT NULL DEFAULT '{}');

CREATE TABLE kg_node (
  id UUID PRIMARY KEY,
  kind text NOT NULL,                        -- system_version | container | field | concept |
                                             -- concept_attr | value_domain | query | agent
  system_version_id UUID REFERENCES system_version(id) ON DELETE CASCADE,
  qualified_name text NOT NULL,              -- 'LEGACY_V1.CUST_MASTER.CUST_NO'
  attrs jsonb NOT NULL DEFAULT '{}',         -- dtype, length, nullable, json_path, eav_key …
  valid_from timestamptz NOT NULL,           -- when it held in the source
  valid_to timestamptz,
  recorded_at timestamptz NOT NULL DEFAULT now(),   -- when DataForge learned it
  UNIQUE (system_version_id, qualified_name, valid_from));

CREATE TABLE kg_claim (
  id UUID PRIMARY KEY,
  predicate text NOT NULL,                   -- see § 18.2
  subject_id UUID NOT NULL REFERENCES kg_node(id) ON DELETE CASCADE,
  object_id UUID REFERENCES kg_node(id) ON DELETE CASCADE,   -- null for unary claims (UNIQUE)
  params jsonb NOT NULL DEFAULT '{}',        -- field sets, role/discriminator, transform, pattern
  status text NOT NULL DEFAULT 'proposed',   -- proposed | accepted | rejected | superseded
  confidence numeric,                        -- calibrated 0..1, null until scored
  band text,                                 -- high | medium | low (shown in UI)
  calibrator_version text,
  supersedes_id UUID REFERENCES kg_claim(id),
  valid_from timestamptz NOT NULL, valid_to timestamptz,
  recorded_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX ON kg_claim (predicate, status);
CREATE INDEX ON kg_claim (subject_id); CREATE INDEX ON kg_claim (object_id);

CREATE TABLE kg_evidence (                   -- PROV-O qualified influence
  id UUID PRIMARY KEY,
  claim_id UUID NOT NULL REFERENCES kg_claim(id) ON DELETE CASCADE,
  kind text NOT NULL,                        -- minhash | ind | ucc | fd | semtype | embedding |
                                             -- sql_parse | llm | probe | example | human
  score numeric,                             -- raw signal strength
  payload jsonb NOT NULL DEFAULT '{}',       -- e.g. {"containment":0.994,"checked_rows":120000}
  activity_id UUID NOT NULL REFERENCES kg_activity(id));

CREATE TABLE column_profile (                -- aggregates only; produced in the data plane
  node_id UUID PRIMARY KEY REFERENCES kg_node(id) ON DELETE CASCADE,
  row_count bigint, null_frac numeric, distinct_est bigint,
  min_text text, max_text text,              -- masked if the semantic type is sensitive
  length_hist jsonb, format_hist jsonb,      -- format = char-class shape, e.g. 'AAAA0AAAAAA'
  top_values jsonb,                          -- only values with count >= k_threshold, masked
  numeric_hist jsonb,
  minhash bytea, hll bytea,
  activity_id UUID NOT NULL REFERENCES kg_activity(id));

CREATE TABLE node_embedding (
  node_id UUID REFERENCES kg_node(id) ON DELETE CASCADE,
  model text NOT NULL,
  vec vector(384) NOT NULL,
  PRIMARY KEY (node_id, model));
```

### 18.2 Claim predicates (closed list)

| Predicate | Subject → object | `params` |
|---|---|---|
| `CONTAINS` | container → field | `{ordinal}` |
| `HAS_SEMANTIC_TYPE` | field → value_domain | `{validator, match_rate}` |
| `UNIQUE` | container → (none) | `{fields:[…]}` |
| `INCLUDED_IN` | field → field | `{containment, fields_src:[…], fields_tgt:[…]}` (FK candidate) |
| `DETERMINES` | field → field | `{lhs:[…], error_rate}` (functional dependency) |
| `SIMILAR_TO` | field → field | `{name_sim, content_sim}` |
| `JOINS_ON` | field → field | `{query_node_id, join_type}` |
| `MEMBER_OF_ENTITY` | container → concept | `{role}` |
| `REALISES` | field/container → concept_attr/concept | `{direction: from|into, expr, pattern, role, discriminator}` |
| `MAPS_TO` | field → field | `{composed_from:[claim ids], expr, pattern}` (derived, never edited) |
| `DERIVED_BY` | field → field | `{smo: rename|split|merge|partition|decompose|join}` |
| `ALIGNED_TO` | concept → (external IRI in params) | `{scheme: iso20022|bian|fibo, iri}` |

Any predicate outside this list is a validation error.

### 18.3 Migration, decisions and governance

```sql
CREATE TABLE migration (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id),
  name text NOT NULL,
  source_version_id UUID NOT NULL REFERENCES system_version(id),
  target_version_id UUID NOT NULL REFERENCES system_version(id),
  spec_hash text,                            -- hash of the compiled MappingPlan; set on approval
  status text NOT NULL DEFAULT 'draft',      -- draft | specified | proven | ready | cutover | live
  ponr_at timestamptz,                       -- point of no return, once declared
  post_ponr_policy text,                     -- forward_fix | reverse_sync (recorded only)
  UNIQUE (model_version_id, name));

CREATE TABLE decision (                      -- every open decision blocks compilation
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  kind text NOT NULL,                        -- unmapped_source | missing_target | derived_value |
                                             -- lossy_expression | cutover_state | history_scope
  subject text NOT NULL,                     -- 'LEGACY_V1.CUST_MASTER.FAX_NO'
  options text[] NOT NULL,                   -- e.g. {drop,archive,extension}
  choice text,                               -- null = open
  rationale text, decided_by text, decided_at timestamptz);

CREATE TABLE reject_category (
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  code text NOT NULL, description text NOT NULL, owner text NOT NULL,
  UNIQUE (migration_id, code));

CREATE TABLE cleanse_rule (                  -- separate from mapping rules (finding 2)
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  name text NOT NULL, target_field text NOT NULL,
  condition text NOT NULL,                   -- MDL expression
  action text NOT NULL,                      -- fix | reject
  fix_expr text,
  reject_code text,                          -- must exist in reject_category for this migration
  owner text NOT NULL, approved_by text);

CREATE TABLE cutover_item (                  -- finding 3
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  concept text NOT NULL,
  item_class text NOT NULL,                  -- pending_payment | future_dated | standing_instruction |
                                             -- accrued_interest | hold | lien | other
  selector text NOT NULL,                    -- MDL expression identifying the items in v1
  rule text NOT NULL,                        -- migrate | settle_before_freeze | recompute
  reconcile_check text NOT NULL);            -- MDL assertion reconciled separately

CREATE TABLE job (                           -- control plane → data plane handoff
  id UUID PRIMARY KEY,
  kind text NOT NULL,                        -- profile | rehearse | migrate | delta | compare | learn
  migration_id UUID REFERENCES migration(id),
  spec_hash text,                            -- worker refuses jobs whose hash is not approved
  params jsonb NOT NULL DEFAULT '{}',
  requested_by text NOT NULL, approved_by text,   -- four-eyes for migrate/delta on production
  status text NOT NULL DEFAULT 'queued',     -- queued | approved | running | done | failed
  claimed_by text, started_at timestamptz, finished_at timestamptz, error text);

CREATE TABLE rehearsal (
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  kind text NOT NULL,                        -- synthetic | masked | dress | production
  spec_hash text NOT NULL, seed bigint NOT NULL,
  job_id UUID REFERENCES job(id),
  report jsonb,                              -- § 23.9 ReconciliationReport
  previous_id UUID REFERENCES rehearsal(id));

CREATE TABLE crosswalk (                     -- partition by concept in production
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  concept text NOT NULL, business_key text NOT NULL,
  old_key jsonb NOT NULL, new_key jsonb NOT NULL,
  rehearsal_id UUID NOT NULL REFERENCES rehearsal(id),
  PRIMARY KEY (rehearsal_id, concept, business_key));

CREATE TABLE ledger (                        -- row-conservation ledger
  rehearsal_id UUID NOT NULL REFERENCES rehearsal(id) ON DELETE CASCADE,
  source_table text NOT NULL, source_key jsonb NOT NULL,
  outcome text NOT NULL,                     -- migrated | merged | filtered | rejected
  target_keys jsonb, rule text, reason text,
  PRIMARY KEY (rehearsal_id, source_table, source_key));

CREATE TABLE quarantine (
  rehearsal_id UUID NOT NULL REFERENCES rehearsal(id) ON DELETE CASCADE,
  source_table text NOT NULL, source_key jsonb NOT NULL,
  reject_code text NOT NULL, error text NOT NULL,
  payload_ref text,                          -- pointer into data-plane storage, never the row itself
  PRIMARY KEY (rehearsal_id, source_table, source_key));

CREATE TABLE golden_mapping (                -- finding 5
  id UUID PRIMARY KEY,
  source_field text NOT NULL, target text NOT NULL,   -- target field or concept attribute
  pattern text NOT NULL, correct boolean NOT NULL,
  from_migration_id UUID REFERENCES migration(id));

CREATE TABLE eval_run (
  id UUID PRIMARY KEY,
  model_id text NOT NULL, prompt_version text NOT NULL, thresholds jsonb NOT NULL,
  precision_at_1 numeric, recall_at_10 numeric, mrr numeric,
  accepted boolean NOT NULL DEFAULT false, run_at timestamptz NOT NULL DEFAULT now());

CREATE TABLE comparison (                    -- behaviour comparator (finding 1)
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  name text NOT NULL,                        -- 'EOD balances 2026-11-30'
  concept text NOT NULL,                     -- keys joined through the crosswalk of this concept
  v1_artifact text NOT NULL, v2_artifact text NOT NULL,   -- uploaded output files (data plane)
  tolerance jsonb NOT NULL DEFAULT '{}',     -- per column, minor units; default exact
  result jsonb);

CREATE TABLE signoff (
  id UUID PRIMARY KEY,
  migration_id UUID NOT NULL REFERENCES migration(id) ON DELETE CASCADE,
  rehearsal_id UUID REFERENCES rehearsal(id),
  kind text NOT NULL,                        -- mapping_spec | data_equivalence |
                                             -- behaviour_equivalence | cutover_readiness | ponr
  role text NOT NULL, user_id text NOT NULL,
  decision text NOT NULL,                    -- approve | reject
  note text, at timestamptz NOT NULL DEFAULT now());
```

`ledger` and `quarantine` hold keys, outcomes and pointers only. Row payloads stay
in data-plane storage (§ 25).

---

## 19. MDL additions

### 19.1 Grammar extension (`app/mdl/grammar.lark`)

Add to `statement` the alternatives `concept_def | realize_def | migration_def`, and:

```lark
concept_def: "concept" NAME "{" concept_item* "}"
concept_item: "identity" "business_key" "(" NAME ("," NAME)* ")"
            | "attr" NAME ("," NAME)*
            | "has_many" NAME ("roles" "(" NAME ("," NAME)* ")")?
            | "has_one"  NAME
            | "aligned_to" NAME STRING                    // scheme, IRI

realize_def: "realize" NAME ("from" | "into") NAME "{" realize_item* "}"
realize_item: ("table" | "tables") table_expr ("where" expr)?
            | "key" NAME "generated"?
            | NAME ("(" NAME ")")? ("<-" | "->") rexpr mapping_meta*
table_expr: NAME ("(" assign ("," assign)* ")")? ("+" NAME ("(" assign ("," assign)* ")")?)*
rexpr: expr ("," expr)*
     | "unpivot" "(" NAME ("," NAME)* ")" ("skip" "null")?
     | "pivot" "(" NAME "," NAME ")"                      // key column, value column
rexpr_tail: "via" "valueset" NAME "(" NAME "->" NAME ")"
          | "by_example" STRING
mapping_meta: rexpr_tail | "confidence" NAME | "approved_by" STRING

migration_def: "migration" NAME "->" NAME "{" migration_item* "}"
migration_item: "concepts" NAME ("," NAME)*
              | "crosswalk" NAME ":" NAME "->" NAME ("persist" STRING)?
              | "unmapped_source" qname ":" NAME                   // drop | archive | extension
              | "missing_target"  qname ":" target_fill
              | "derived" qname ":" ("migrate" | "recompute")
              | "represent" qname ":" repr_rule ("," repr_rule)*
              | "cleanse" qname "when" expr "->" cleanse_action "owner" STRING
              | "cutover" "{" cutover_rule* "}"
              | "reconcile" "{" reconcile_rule* "}"
              | "history" NAME ":" NAME                            // extension point, § 29
target_fill: "default" value | "derive" func_call | "flag"
repr_rule: "charset" STRING | "normalize" NAME | "timezone" STRING "->" STRING
         | "round" NAME NUMBER                                     // mode, scale
cleanse_action: "fix" expr | "reject" STRING
cutover_rule: NAME "select" expr "rule" NAME "check" expr
reconcile_rule: expr ("==" expr)?
              | "sum" "(" qname ")" "by" NAME ("," NAME)* ":" "exact"
              | "ledger" "every_source_row"
```

Extend this grammar only if a § 27 test requires it, and record the change in
`DECISIONS.md`.

### 19.2 Compiler additions (`app/mdl/checker.py`, `app/migrate/compose.py`)

New checks, run after the Part A stages:

1. **Concept resolution** — every `realize` names a known concept; every left/right
   side resolves to a field in its version or an attribute of the concept.
2. **Direction** — in a `from` block each expression must compute concept ← source;
   in an `into` block, target ← concept. An expression registered as lossy in the
   transform library (§ 21.5) in that direction requires `by_example` or a
   `lossy_expression` decision. → `ERR_LOSSY_UNRESOLVED`.
3. **Coverage** — every mandatory target field is filled by an `into` mapping or a
   `missing_target` rule; every source field is consumed by a `from` mapping or an
   `unmapped_source` rule. → `ERR_UNCOVERED_TARGET`, `ERR_UNCONSUMED_SOURCE`.
4. **Derived values** — a target field marked derived in the target profile or
   application code requires a `derived … : migrate|recompute` rule. → `ERR_DERIVED_UNDECIDED`.
5. **Open decisions** — any `decision` row with `choice IS NULL` for this
   migration. → `ERR_OPEN_DECISION` (blocks compilation; lists them all).
6. **Fit** — Part A fit checks applied to every `into` expression, including
   valueset translations and representation rules.
7. **Compose** — produce the `MappingPlan` (§ 22.1) and its `spec_hash`.

Each compiled realisation also writes `REALISES` claims, and each composed
mapping writes a derived `MAPS_TO` claim, so the graph always mirrors the spec.

---

## 20. Source intelligence (runs in the data plane, writes the graph)

### 20.1 Inventory and profiling (`intel/profiler.py`, `intel/sketches.py`)

```python
def inventory(version: SystemVersion) -> list[KgNode]            # tables, columns, views, procs
def profile_table(version, table: str, sample: int | None = None,
                  k_threshold: int = 20) -> list[ColumnProfile]
```

Per column: row count, null fraction, HLL distinct estimate, min/max (masked when
sensitive), length histogram, **format histogram** (each value reduced to its
character-class shape: digit → `0`, upper → `A`, lower → `a`, others kept),
top values with count ≥ `k_threshold` (masked by § 25.3), numeric histogram,
MinHash (128 permutations) over normalised distinct values.

Large tables: profile on a uniform sample (default 1,000,000 rows) and record the
sample size in the activity inputs. Exact checks in § 20.3 always use full data.

### 20.2 Semantic typing (`intel/semtypes.py`)

Deterministic validators first, each returning a match rate over non-null values:

| Domain | Rule |
|---|---|
| IBAN | ISO 13616 mod-97 |
| IFSC | `^[A-Z]{4}0[A-Z0-9]{6}$` |
| PAN (India) | `^[A-Z]{5}[0-9]{4}[A-Z]$` |
| Card number | 13–19 digits, Luhn |
| Currency code | ISO 4217 list |
| Country code | ISO 3166 alpha-2/3 |
| Date / timestamp | a configured list of formats; reports the winning format |
| Email, phone (E.164 or Indian 10-digit) | regex |
| Code set | values ⊆ a known valueset (from the model) |

Assign a type when match rate ≥ 0.98 (configurable). Residual columns get a
learned or LLM-assisted type with neighbouring columns as context, always as a
`proposed` claim. Write `HAS_SEMANTIC_TYPE` claims with `semtype` evidence.

### 20.3 Constraint discovery (`intel/constraints.py`)

```python
def discover_uccs(table, max_size: int = 3) -> list[Claim]        # UNIQUE
def discover_inds(version) -> list[Claim]                          # INCLUDED_IN
def discover_fds(table, max_lhs: int = 2, max_error: float = 0.01) -> list[Claim]
```

- **UCCs:** candidates by HLL distinct ≈ row count; confirm with exact `COUNT(DISTINCT …)`.
- **INDs:** candidate pairs by MinHash containment ≥ 0.9 and type compatibility; confirm
  with an exact anti-join (`child NOT IN parent` count) on full data. Record containment.
- **FDs:** on a sample, measure the g3 error (fraction of rows to remove for the FD to
  hold); keep FDs with error ≤ `max_error`.

### 20.4 Code mining (`intel/codemine.py`)

Parse view definitions, stored-procedure SQL and any application SQL found at
`code_location` with `sqlglot`. Each join predicate becomes a `JOINS_ON` claim with
`sql_parse` evidence and a `query` node. Unparseable statements are logged, never fatal.

### 20.5 LLM relationship proposals (`llm/…`, § 21.6 contract)

For each container, send the grounded context (§ 21.6) and ask for relationship
claims the statistics missed. Every proposal becomes a `proposed` claim with `llm`
evidence, then the validator (§ 21.7) tests it on data (containment, cardinality
shape, join success rate); evidence from those tests is attached either way.

### 20.6 Global structure solve (`kg/structure.py`)

```python
def solve_structure(version_id) -> list[ClaimDecision]
```

Build a directed graph child → parent from `INCLUDED_IN` candidates whose object is
on a `UNIQUE` field set, weighted by confidence. Take
`networkx.maximum_spanning_arborescence` per connected component so each foreign
key has one parent and the structure is consistent. Claims chosen become
`accepted` *only* in the high band; others stay `proposed` for review.

### 20.7 Entity clustering (`intel/entities.py`)

Cluster containers sharing a key (1:1 `INCLUDED_IN` both ways or a shared business
key), plus name stems. Each cluster yields a `MEMBER_OF_ENTITY` proposal against an
existing concept by embedding similarity, or a "new concept" suggestion for review.

### 20.8 Calibration (`kg/calibrate.py`)

Until a predicate has a configurable minimum of labelled outcomes (default 200, accept or reject), confidence is shown
as a band from fixed evidence rules (§ 21.8). After that, fit an
`IsotonicRegression` from evidence features to acceptance per predicate, store
`calibrator_version`, and show a reliability curve in the Evidence screen.

### 20.9 Data-quality assessment (`intel/dq_report.py`) — finding 2

Produced at the end of profiling, before any mapping work:
nulls in fields that are mandatory in the target, format violations against the
detected semantic type, orphans (`INCLUDED_IN` containment < 1), duplicate business
keys, out-of-range dates, and free text in coded fields. Each issue class is
proposed as a `reject_category` with an estimated count, for an owner to accept.

---

## 21. Mapping discovery (control plane)

### 21.1 Pipeline entry point

```python
# app/mapping/__init__.py
def discover(migration_id: UUID) -> DiscoveryResult
```

Stages, in order: align entities → retrieve candidates → LLM rerank → global
assignment → classify pattern and propose transform → band confidence → order for
review. Every stage writes claims and evidence; nothing is held only in memory.

### 21.2 Entity alignment (`mapping/retrieve.py`)

Align source entity clusters to concepts, and concepts to target clusters, before
any attribute. Score = weighted sum of: key-structure similarity, relationship-shape
similarity (degree and fan-out pattern), semantic-type overlap, name/description
embedding similarity, and LLM judgement over both applications' code summaries.
Weights live in config; record them in the activity inputs.

### 21.3 Candidate retrieval

```python
def candidates(concept_attr: KgNode, side: Literal["source","target"], k: int = 10) -> list[Candidate]
```

Rank fields within aligned entities by: embedding similarity (pgvector), semantic
type compatibility, format-histogram similarity, code-set overlap (only where both
sides have values or reference data), and key-shape compatibility. Never send whole
schemas to the LLM.

### 21.4 Pattern classification (`mapping/patterns.py`)

```python
class Pattern(StrEnum):
    RENAME_RETYPE = "rename_retype"; SPLIT_MERGE = "split_merge"
    CODE_TRANSLATION = "code_translation"; REPEATING_TO_CHILD = "repeating_to_child"
    TABLE_SPLIT_JOIN = "table_split_join"; ENTITY_MERGE = "entity_merge"
    KEY_REGENERATION = "key_regeneration"; GRAIN_CHANGE = "grain_change"
    TEMPORAL_CHANGE = "temporal_change"; KEY_VALUE = "key_value"
    DOCUMENT = "document"; NEW_MANDATORY = "new_mandatory"; DROPPED = "dropped"
    REPRESENTATION = "representation"      # finding 4: charset, normalisation, time zone, rounding

def classify(candidate_set) -> Pattern
```

`NEW_MANDATORY`, `DROPPED`, and any derived target field create `decision` rows
instead of transforms. `REPRESENTATION` is detected from charset metadata, the
presence of non-ASCII scripts in profiles, time-zone-bearing types, and differing
numeric precision or scale.

### 21.5 Transform library (`mapping/transforms/`)

Each function is pure, typed, registered with its direction properties:

```python
@transform(name="split_address", inverse=None, lossy_forward=False, lossy_inverse=True)
def split_address(s: str) -> dict[str, str]: ...
```

Ship: `to_date(fmt)`, `to_timestamp(fmt, tz)`, `tz_convert`, `round_money(mode, scale)`,
`normalize_unicode(form)` (NFC default), `transcode(charset)`, `concat`, `split_name`
(lossy inverse), `split_address` (lossy inverse), `iban_format`, `ifsc_upper`,
`valueset_lookup`, `unpivot`, `pivot`, `nest_json(path)`, `flatten_json(path)`,
`coalesce`, `default`. Money is always integer minor units (reuse `app/engine/aggregate/money.py`).

### 21.6 LLM contract (`llm/provider.py`, `llm/contracts.py`, `llm/grounding.py`)

```python
class LLMProvider(Protocol):
    model_id: str                                   # pinned; recorded on every activity
    def complete_json(self, prompt: str, schema: dict, max_tokens: int) -> dict: ...

def grounded_context(task: Task, hops: int = 2, budget_tokens: int = 6000) -> str
```

- **Context:** the subgraph within `hops` of the task's nodes: names, types,
  descriptions, profiles (aggregates), masked samples (§ 25.3), existing claims with
  bands, and relevant parsed SQL. Serialised as compact lines keyed by node id.
- **Output:** JSON validated against a schema. Every referenced entity must be an
  existing node id; `predicate` from the closed list (§ 18.2); `pattern` from § 21.4;
  a one-line `reason`. Invalid JSON or unknown ids → rejected, not repaired by guessing.
- **Prompts** live in `llm/prompts/` as versioned files; the version is recorded on
  the activity. A prompt change is a golden-set evaluation event (§ 21.9).
- `StubProvider` returns canned outputs keyed by task and is used in all tests.

### 21.7 Validator (`llm/validate.py`)

```python
def validate(claim: Claim) -> ValidationResult      # passes | fails(reasons)
```

Checks, against accepted claims and profiles: type and length compatibility (fit),
containment for relationship claims, cardinality consistency with `UNIQUE` and
`DETERMINES`, no conflict with an accepted claim on the same field, direction rules
for transforms. A failing LLM proposal gets one repair round with the reasons; if it
still fails it is stored as `rejected` with the reasons as evidence.

### 21.8 Assignment, bands and review order

- **Assignment** (`mapping/assign.py`): per aligned entity pair, build a score matrix
  of candidates and solve with `linear_sum_assignment`; then enforce grain and
  cardinality, dropping assignments that would break them.
- **Bands** (until calibrated): *high* = deterministic evidence agrees (type + format
  + containment or code-set overlap) and LLM agrees; *medium* = two independent
  signals agree; *low* = otherwise. Below *low*, the tool abstains and asks.
- **Review order** (`mapping/impact.py`): entity alignments and keys first, then
  claims by the number of downstream mappings that depend on them; plain renames in
  the high band are offered for bulk approval.

### 21.9 Examples on demand and golden set (`mapping/pbe.py`, `llm/golden.py`)

- **Examples:** the reviewer supplies 2–10 source → target examples (CSV). `pbe.py`
  searches the transform library and compositions up to depth 2 for a program
  consistent with all examples; failing that, asks the LLM for an expression in the
  MDL expression subset and tests it. Examples are stored and become tests.
- **Golden set** (finding 5): every reviewer decision on a mapping is appended to
  `golden_mapping`. `golden.py` replays discovery against the golden set and records
  precision@1, recall@10 and MRR in `eval_run`. A change of model, prompt or
  threshold may be deployed only if its `eval_run` does not fall below the last
  accepted run on any metric (thresholds configurable).

---

## 22. Migration execution

### 22.1 MappingPlan IR (`migrate/plan.py`)

```python
@dataclass(frozen=True)
class FieldMap:
    target: str                       # 'CORE_V2.PERSON.FIRST_NM'
    expr: dict                        # expression AST over concept attributes
    pattern: str
    lossy: bool

@dataclass(frozen=True)
class ConceptPlan:
    concept: str
    read: dict                        # source tables, joins, filters, unpivots → concept rows
    write: tuple[FieldMap, ...]       # concept rows → target tables
    identity: tuple[str, ...]         # business key attributes
    key_strategy: dict                # {"table":..., "column":..., "mode":"generated"|"carried"}
    depends_on: tuple[str, ...]       # concepts whose crosswalk this one needs

@dataclass(frozen=True)
class MappingPlan:
    spec_hash: str; seed: int
    order: tuple[str, ...]            # concepts in dependency order (flow ordering)
    concepts: dict[str, ConceptPlan]
    cleanse: tuple[dict, ...]; representation: tuple[dict, ...]
    derived: dict[str, str]           # target field → migrate | recompute
    cutover: tuple[dict, ...]; reconcile: tuple[dict, ...]
```

### 22.2 Two executors, one plan

```python
# migrate/interpreter.py — the oracle
def interpret(plan: MappingPlan, source_rows: Iterable[dict]) -> TargetRows
# migrate/executor.py — production
def execute(plan: MappingPlan, partition: Partition, ctx: RunContext) -> PartitionResult
```

- **Reference interpreter:** pure Python, row by row, straight from the IR, no
  optimisation, no shared code with the executor beyond the transform library and
  the IR. Used on fixtures only.
- **Production executor:** extracts each partition to Parquet in data-plane storage,
  transforms with polars (vectorised, compiled from the same IR), loads through the
  Part A adapter SPI. Cleanse rules run first; failures go to quarantine with a
  `reject_code`; every source row gets a ledger outcome.

The transform library is the only shared code, and it has its own unit tests.

### 22.3 Key crosswalk (`migrate/crosswalk.py`)

```python
def build(plan, concept, rehearsal_id) -> int        # rows written
def resolve(concept, old_key) -> new_key             # used by dependent concepts
```

Built for a concept before any dependent concept loads. Generated keys are
deterministic: sort by business key, allocate from a configured start offset per
target sequence, so two rehearsals with the same plan and seed produce identical keys.
Kept after go-live and exported for support and downstream teams.

### 22.4 Partitions, checkpoints, idempotency

Partition each concept by business-key range (configurable count). Each partition
is a unit of work: load is idempotent (delete rows tagged with the run and partition,
then insert; or MERGE where the adapter supports it), checkpointed in the `job`
params, and restartable. Load engineering per adapter: optional deferred index and
constraint creation, then a validation pass after load (finding 11).

### 22.5 Sizing (`migrate/sizing.py`) — finding 11

```python
def estimate(plan, profiles, sample_run: PartitionResult) -> SizingReport
```

Rows per concept from profiles × measured rows/second from a sampled partition →
estimated duration per concept and in total, with the critical path through the
dependency order. Shown before any dress rehearsal and compared afterwards.

### 22.6 Cutover state (`migrate/cutover.py`) — finding 3

Each `cutover_item` is evaluated against v1 at freeze: items with rule `migrate`
go through the plan; `settle_before_freeze` items must count zero at freeze or the
cutover gate fails; `recompute` items are excluded from load and listed for the v2
team. Each class has its own reconcile check in the report.

### 22.7 Delta catch-up (`migrate/delta.py`)

For bulk-then-delta cutover: each source table declares a watermark (timestamp or
monotonic id). The delta job selects rows changed since the bulk watermark and runs
them through the same plan, updating crosswalk and ledger. Deletes in v1 need a
soft-delete flag or a log source; if neither exists, the compiler emits
`WARN_DELTA_DELETES_UNTRACKED`.

### 22.8 Rehearsals and run-to-run diff (`migrate/rehearsal.py`) — finding 9

```python
def run(migration_id, kind: Literal["synthetic","masked","dress","production"]) -> Rehearsal
def diff(current: Rehearsal, previous: Rehearsal) -> RehearsalDiff
```

`diff` joins target rows of two rehearsals through deterministic keys and
attributes every difference to one cause: `spec_changed` (the field's `MAPS_TO`
claim or expression differs between the two `spec_hash`es), `data_changed` (the
source row differs), or `unexplained` (neither). Any `unexplained` difference fails
the rehearsal.

### 22.9 Point of no return — finding 10

`ponr` is a sign-off kind. When signed, `migration.ponr_at` is set and
`post_ponr_policy` is recorded (`forward_fix` or `reverse_sync`). Part B does not
build reverse sync; the cutover-readiness gate requires the policy to be recorded.

---

## 23. Verification

### 23.1 Spec checks
The § 19.2 compiler checks. A migration cannot reach `specified` status with any error.

### 23.2 Differential testing (`verify/differential.py`)

```python
def differential(plan, fixtures: SyntheticFixtures) -> DiffReport
```
Run `interpret` and `execute` on the same synthetic source fixtures; compare target
rows field by field through the crosswalk. Any difference fails.

### 23.3 Fixtures aimed at risk (`engine` scenario reuse)

Fixtures come from the Part A scenario engine with the source version's learned or
declared model, plus generated edge cases derived from the plan: each valueset code
including unmapped ones, null and empty in every join key, duplicate business keys,
maximum-length values for every target field, non-ASCII names, time-zone and
date boundaries, rounding boundaries (half-cent cases), and each cutover item class.

### 23.4 Metamorphic tests (`verify/metamorphic.py`)

| Relation | Check |
|---|---|
| Idempotence | Re-running a partition leaves the target unchanged |
| Partition independence | Different partition counts give identical output |
| Order independence | Shuffling source rows gives identical output |
| Filter neutrality | Adding a row the plan filters out changes nothing but the ledger |
| Money conservation | Control totals equal before and after, in minor units |

### 23.5 Row-conservation ledger (`migrate/ledger.py`)

```python
def check_conservation(rehearsal_id) -> ConservationResult
```
Per source table: `migrated + merged + filtered + rejected == source row count`, and
zero rows without an outcome. Where grain changes, the expected target count is
computed from the plan (for example child rows = filled repeating slots).

### 23.6 Control totals and round trip (`verify/reconcile.py`)

- Control totals: sums of every money field by the dimensions named in `reconcile`
  (product, currency, branch, GL account), computed with the Part A aggregate
  engine's integer arithmetic; must match exactly.
- Round trip: for a stratified sample (by segment and risk), read each entity from
  v1 into the concept and from v2 back into the concept through the inverse of the
  `into` realisation, then compare. Money fields are compared in full, not sampled.

### 23.7 Mutation testing of the suite (`verify/mutation.py`)

Apply mutations to a copy of the plan (swap two codes in a valueset, drop a filter,
off-by-one on a date, flip a rounding mode, drop a join condition) and run the
fixture suite. Report the kill rate; the target is that every mutation is killed.

### 23.8 Behaviour support — finding 1 (out of scope to run, in scope to enable)

- **Comparator** (`verify/comparator.py`): the v2 or UAT team uploads the outputs of
  a business process run on both versions (for example end-of-day balances, interest
  postings, statement lines) as CSV or Parquet. DataForge joins them through the
  concept's crosswalk and diffs them with per-column tolerances (default exact, in
  minor units). Results go to `comparison.result`.
- **Test pack** (`verify/testpack.py`): crosswalk extract plus migrated samples
  stratified by risk segment (dormant, overdraft, multi-currency, each cutover item
  class, each reject category that was fixed rather than rejected).
- **Synthetic v2 data**: § 24.3.
- **Gate**: the `behaviour_equivalence` sign-off is required for cutover readiness;
  DataForge records it but does not produce it.

### 23.9 ReconciliationReport (stored in `rehearsal.report`)

```jsonc
{"rehearsalId":"…","kind":"dress","specHash":"…","durationSec":5410,
 "ledger":{"CUST_MASTER":{"source":120430,"migrated":120102,"merged":211,
           "filtered":96,"rejected":21,"unexplained":0}},
 "controlTotals":[{"field":"ACCOUNT.balance","by":["product","currency"],
                   "mismatches":0}],
 "roundTrip":{"sampled":5000,"mismatches":0},
 "rejectsByCategory":{"BAD_DOB":14,"ORPHAN_ACCOUNT":7},
 "cutover":[{"class":"pending_payment","rule":"settle_before_freeze","remaining":0}],
 "diffVsPrevious":{"spec_changed":1840,"data_changed":12,"unexplained":0},
 "sizing":{"estimatedSec":5200,"actualSec":5410}}
```
(The numbers are illustrative of the shape only.)

---

## 24. Learned synthetic generation

### 24.1 What is learned (`learn/…`, data plane)

```python
def learn_degrees(version_id) -> dict[str, DegreeDist]           # children per parent per relation
def learn_marginals(version_id, k_threshold=20, epsilon: float | None = None) -> dict[str, Marginal]
def learn_constraints(version_id) -> list[Claim]                  # validated LLM + discovered rules
```

Degree distributions per accepted relationship; one- and two-way marginals of
attributes given parent context; code frequencies (become valueset weights); time
patterns (inter-event gaps, month-end and salary-day peaks). Counts below
`k_threshold` are suppressed. If `epsilon` is set, Laplace noise is added to counts.
Identities, keys, free text and rare exact combinations are never learned.

### 24.2 Use in generation

Learned distributions are emitted as MDL generator specs `learned("<model_id>")`
so Part A scenarios, rules and the aggregate solver apply on top. Structure (keys,
cardinalities, ordering) comes from the graph, never from a learned model.

### 24.3 Target-shaped data

Generate concept instances, then write them through the target version's `into`
realisation with the production executor's transform code. Output: synthetic v2
data for the v2 team, before any migration runs.

### 24.4 Privacy gate (`learn/privacy.py`)

Before a learned model is used outside the data plane: verify no released category
below `k_threshold`; compute distance-to-closest-record between a synthetic sample
and a real holdout versus real-to-real distances; run a simple membership test
(train/holdout distinguisher). Results are stored on the activity; failure blocks use.

### 24.5 Fidelity report (`learn/fidelity.py`)

```python
def fidelity(model_id: UUID, synthetic: SyntheticDataset) -> FidelityReport
```

Computed in the data plane against the real data the model was learned from; only
scores leave. The report is advisory until a project sets thresholds from its
first accepted baseline (`config/fidelity.yaml`); after that, it is a gate.

| Check | Measure |
|---|---|
| Column distributions | Total variation distance (categorical), Kolmogorov–Smirnov statistic (numeric), per column |
| Pairwise relationships | Mean absolute difference of association matrices: Cramér's V for categorical pairs, Spearman for numeric pairs |
| Children per parent | Kolmogorov–Smirnov statistic per accepted relationship |
| Time patterns | Inter-event gap distribution and day-of-month profile |
| Discriminator | Cross-validated AUC of a `HistGradientBoostingClassifier` separating real from synthetic parent rows enriched with child aggregates; 0.5 means indistinguishable |
| Utility | Part A rule pass rates and reject-category rates on synthetic versus real, within tolerance |

### 24.6 Transaction sequences (`learn/sequences.py`)

```python
def learn_sequences(version_id, segment_by: list[str], k_threshold=20) -> SequenceModel
def generate_sequences(model, accounts, as_of: date, seed: int) -> TransactionFrame
```

Per segment: a first-order Markov chain over transaction states (channel ×
direction × category), an inter-arrival gap distribution per state, an amount
distribution per state, and calendar factors (weekday, day of month, salary day,
month end) as intensity multipliers. Segments below `k_threshold` back off to their
parent segment. Generation runs each account from its open date, or its Part A
lifecycle `ACTIVE` intervals when a lifecycle is declared, to `as_of`. When a
scenario pins a balance, the sequence supplies the order and classes and the
aggregate solver supplies exact amounts, with the running-balance guard applied.

### 24.7 Edge-case pattern mining (`learn/edge_patterns.py`)

```python
def mine_patterns(version_id, k_threshold=20) -> list[EdgePattern]
```

From profiles and claims, find rare-but-valid patterns: low-frequency codes, long
dormancy, tail account ages, maximum-length values, accepted dependency exceptions,
and source codes absent from the target valueset. Each becomes a named scenario
template (`scenario "edge:<name>"`) with a count. Values are always generated to
satisfy the pattern, never copied. A pattern with fewer than `k_threshold` real
occurrences is described by structure only (for example "dormancy above 10 years
exists"), with no values. Patterns also feed the risk fixtures in § 23.3.

### 24.8 Volume scaling (`learn/scale.py`)

```python
def scale_plan(model, factor: float) -> GenerationPlan       # e.g. 0.01 to 10
```

Root-entity counts scale by `factor`; children-per-parent distributions and
per-account sequences keep their shape. Scenario-pinned totals stay pinned unless
the scenario marks them `scales`. Before generating, the compiler checks every
unique field's value space (from its pattern or generator) against the required
count → `ERR_VALUE_SPACE` if it cannot fit. Keys stay deterministic, so scaled runs
remain reproducible and collision-free.

### 24.9 Re-learning per release (`learn/relearn.py`)

```sql
CREATE TABLE learned_model (
  id UUID PRIMARY KEY,
  system_version_id UUID NOT NULL REFERENCES system_version(id),
  version int NOT NULL,                      -- 1, 2, 3 … per system version lineage
  learned_at timestamptz NOT NULL,
  k_threshold int NOT NULL, epsilon numeric,
  profile_activity_id UUID NOT NULL REFERENCES kg_activity(id),
  fidelity_report jsonb, privacy_report jsonb, drift_report jsonb,
  status text NOT NULL DEFAULT 'candidate',  -- candidate | approved | retired
  UNIQUE (system_version_id, version));
```

Re-learn on each release's profiling run, or when Part A schema import detects
drift. Every re-learn creates a new `learned_model` version with a drift report
against the previous one (per-column distribution shift, degree shift, sequence
shift). `learned("<model_id>")` references stay pinned to their version until a
modeller moves them, so generation never changes silently. A version is usable
only once its privacy gate passes and, where thresholds exist, its fidelity gate.

---

## 25. Planes, security and governance

### 25.1 Two deployables

| Plane | Process | Has | Never has |
|---|---|---|---|
| Control | `app.main` (API, UI, compiler, mapping, LLM) | Metadata, aggregates, masked samples, specs, synthetic data, reports | Source or target credentials; real rows |
| Data | `app.worker.main` | Connector credentials (from a vault), profiler, executor, crosswalk, quarantine payloads | Network access to any LLM provider |

The two share the Postgres metadata database only. The worker polls `job` with
`SELECT … FOR UPDATE SKIP LOCKED`, and refuses any `rehearse`, `migrate` or `delta`
job whose `spec_hash` does not match an approved `mapping_spec` sign-off.

### 25.2 Roles and separation of duties — finding 8

| Role | May | May not |
|---|---|---|
| Modeller | Edit MDL, concepts, cleanse rules; run discovery | Approve own mappings; approve production jobs |
| Reviewer | Approve or reject claims and mappings; supply examples | Run production jobs |
| Data owner | Own reject categories; approve cleanse rules for their data | — |
| Approver | Sign off `mapping_spec`, `data_equivalence`, `cutover_readiness`, `ponr` | Request the job they approve |
| Operator | Request rehearsal and migration jobs | Edit specs |
| Behaviour owner (v2/UAT team) | Upload comparator outputs; sign off `behaviour_equivalence` | — |
| Auditor | Read everything; export PROV-O and OpenLineage | Change anything |

Enforced in `governance/roles.py`: `job.requested_by != job.approved_by` for
`migrate` and `delta` against a production profile; a reviewer cannot approve a
claim whose latest evidence is their own edit.

### 25.3 What crosses from data plane to control plane

- Profiles above `k_threshold` only.
- Samples for the LLM through `llm/masking.py`: format-preserving masking with a
  per-project secret key (each digit → a keyed-pseudorandom digit, each letter →
  letter of the same case; separators and length preserved). Checksums are not
  preserved; semantic typing on real values happens in the data plane first.
- Never: row payloads, quarantine payloads, crosswalk business keys of real
  customers (the control plane shows counts and hashed keys).

### 25.4 Audit and lineage

- Every claim traces to evidence → activity → agent with version.
- `kg/prov_export.py` exports approvals and their evidence as PROV-O JSON-LD.
- The worker emits OpenLineage run events (start, complete, fail) per job, with
  column-level lineage from the plan's `MAPS_TO` claims.
- Sign-offs are append-only; corrections are new rows.

---

## 26. API and UI additions

### 26.1 API (base `/api`)

| Method | Path | Purpose |
|---|---|---|
| `POST` | `/systems/{id}/versions` | Register a system version (source or target) |
| `POST` | `/versions/{id}/profile` | Queue a profiling job |
| `GET` | `/versions/{id}/dq-report` | Data-quality assessment |
| `GET` | `/graph/nodes?version=&kind=&q=` | Search nodes |
| `GET` | `/graph/nodes/{id}/neighbourhood?hops=2` | Subgraph with claims and bands |
| `GET` | `/graph/claims?predicate=&status=&band=` | Claim list for review |
| `POST` | `/graph/claims/{id}/review` | `{decision: accept|reject, note}` → human evidence |
| `POST` | `/migrations` | Create a migration |
| `POST` | `/migrations/{id}/discover` | Run mapping discovery |
| `GET` | `/migrations/{id}/review-queue` | Impact-ordered review items |
| `POST` | `/migrations/{id}/examples` | Upload examples for a field (CSV) |
| `GET` / `PATCH` | `/migrations/{id}/decisions` | List and decide open decisions |
| `POST` | `/migrations/{id}/compile` | Compile; returns diagnostics and `spec_hash` |
| `POST` | `/migrations/{id}/rehearsals` | `{kind}` → queues a job |
| `GET` | `/rehearsals/{id}` | Report, ledger summary, diff vs previous |
| `GET` | `/rehearsals/{id}/rejects?category=` | Reject triage (hashed keys, codes, counts) |
| `POST` | `/migrations/{id}/comparisons` | Upload v1/v2 process outputs; run comparator |
| `GET` | `/migrations/{id}/testpack` | Download the test pack (data plane delivers the file) |
| `POST` | `/migrations/{id}/signoffs` | Record a sign-off |
| `POST` | `/jobs/{id}/approve` | Four-eyes approval |
| `GET` | `/eval/runs` · `POST /eval/runs` | Golden-set evaluations |
| `POST` | `/versions/{id}/learn` | Queue a learning job; creates a candidate `learned_model` |
| `GET` | `/learn/models?version=` | Model versions with status |
| `GET` | `/learn/models/{id}/reports` | Fidelity, privacy and drift reports |
| `POST` | `/learn/models/{id}/approve` | Approve a model version for use |

### 26.2 Screens (Part A design tokens and chrome apply)

- **Sources** — system versions, profiling status, the data-quality report as a list
  of issue classes with counts and proposed reject categories.
- **Evidence** — search box, node detail with its claims; each claim shows predicate,
  band pill (`ok` high, `warn` medium, `err` low), the evidence list (kind, score,
  agent, time) and accept/reject buttons. Reliability curve per predicate once calibrated.
- **Concepts** — concept list, attributes, identity, aligned-to links; the
  realisations per version shown side by side (from / into).
- **Mapping review** — the impact-ordered queue, built on the Part A drift-review
  pattern: pattern label, source → target, band, one-line reason, evidence
  breakdown, examples upload, bulk approve for high-band renames. Open decisions in
  a separate list that must reach zero.
- **Migration** — rehearsal list with kind, spec hash and status; per rehearsal the
  ledger table, reject categories with owners and counts across rehearsals (trend to
  zero), cutover item classes, sizing estimate versus actual, diff versus previous
  with the three causes.
- **Reconcile** — control totals table, round-trip results, comparator results
  uploaded by the behaviour owner.
- **Learned models** — model versions per system version with status; fidelity
  report as a check table (pass, fail or advisory per measure, discriminator AUC
  highlighted), privacy report, drift versus the previous version, and an approve
  action.
- **Sign-offs** — the gate checklist for the migration: mapping spec, data
  equivalence, behaviour equivalence, cutover readiness, point of no return; who
  signed, when, and which rehearsal.

---

## 27. Part B test plan

### 27.1 Principles
All Part B tests run against the fixture in § 27.4 with `StubProvider` as the LLM.
Tests that need a real model are marked `@pytest.mark.llm` and excluded from CI;
they run in the golden-set evaluation instead.

### 27.2 Named acceptance tests

| Milestone | Test | Asserts |
|---|---|---|
| M8 | `test_claim_requires_evidence` | A claim cannot be accepted without at least one evidence row |
| M8 | `test_bitemporal_query` | Graph "as known at T" returns what was recorded by T |
| M8 | `test_worker_refuses_unapproved_spec` | A `migrate` job with an unsigned `spec_hash` is refused |
| M8 | `test_prov_export_roundtrip` | Exported approvals parse as JSON-LD and keep agent and time |
| M9 | `test_profile_k_threshold` | Top values below `k_threshold` are never stored |
| M9 | `test_semtype_validators` | IFSC, PAN, IBAN, card Luhn, ISO 4217 typed correctly on the fixture |
| M9 | `test_ind_finds_undeclared_fk` | `ACCT_MASTER.CUST_NO` → `CUST_MASTER.CUST_NO` discovered with containment evidence |
| M9 | `test_codemine_joins` | The fixture view yields a `JOINS_ON` claim |
| M9 | `test_structure_one_parent` | Every FK has exactly one accepted parent after the structure solve |
| M9 | `test_dq_report_seeded_issues` | Bad dates, orphans and duplicates seeded in the fixture are all reported |
| M10 | `test_llm_unknown_ids_rejected` | LLM output naming a non-existent node is rejected |
| M10 | `test_validator_containment` | A proposed FK with containment below threshold is rejected with reasons |
| M10 | `test_masking_format_preserved` | Masked values keep length, case and separators; no original digit sequence survives |
| M10 | `test_golden_eval_gate` | A worse `eval_run` cannot be marked accepted |
| M11 | `test_mdl_concepts_parse` | Fixture concepts, realisations and migration parse and round-trip |
| M11 | `test_lossy_requires_examples` | `full_name -> FIRST_NM, LAST_NM` without examples → `ERR_LOSSY_UNRESOLVED` |
| M11 | `test_open_decision_blocks` | Any open decision → `ERR_OPEN_DECISION` listing it |
| M11 | `test_coverage_checks` | Uncovered `RISK_RATING` and unconsumed `FAX_NO` are reported |
| M11 | `test_derived_requires_rule` | `ACCRUED_INTEREST_MINOR` without `derived` rule → `ERR_DERIVED_UNDECIDED` |
| M11 | `test_graph_mirrors_spec` | Every compiled mapping has a matching `MAPS_TO` claim |
| M12 | `test_discovery_recall_fixture` | Every golden mapping appears in the top-10 candidates |
| M12 | `test_patterns_fixture` | PHONE1–3 → repeating_to_child; CUST_MASTER → table_split; names → representation |
| M12 | `test_review_order` | Entity alignments and keys precede attribute mappings in the queue |
| M12 | `test_pbe_name_split` | Name split learned from the fixture examples reproduces all examples |
| M13 | `test_interpreter_equals_executor` | Differential test passes on all fixtures |
| M13 | `test_crosswalk_deterministic` | Two rehearsals, same plan and seed → identical new keys |
| M13 | `test_ledger_conservation` | Outcomes sum to source counts; zero unexplained |
| M13 | `test_metamorphic` | All five relations in § 23.4 hold |
| M13 | `test_mutation_kill_rate` | Every listed mutation is killed by the suite |
| M13 | `test_grain_expected_counts` | CONTACT_POINT rows equal filled PHONE slots |
| M14 | `test_control_totals_exact` | Balance totals by product and currency match to the minor unit |
| M14 | `test_round_trip` | Sampled entities round-trip with zero mismatches |
| M14 | `test_cleanse_routes_rejects` | Seeded bad rows land in quarantine under the right `reject_code` |
| M14 | `test_cutover_settle_gate` | A non-zero `settle_before_freeze` class fails cutover readiness |
| M14 | `test_rehearsal_diff_attribution` | A spec change and a data change are attributed correctly; none unexplained |
| M14 | `test_comparator_crosswalk_join` | Uploaded v1/v2 outputs join through the crosswalk; a planted difference is found |
| M14 | `test_testpack_strata` | Every risk stratum and cutover class is present in the pack |
| M14 | `test_four_eyes` | Requester cannot approve their own production `migrate` job |
| M14 | `test_signoff_gates` | Cutover readiness requires all five sign-off kinds |
| M14 | `test_sizing_report` | Estimate is produced and compared with actual after a rehearsal |
| M15 | `test_learned_k_threshold` | No learned category below `k_threshold` |
| M15 | `test_target_shaped_valid` | Synthetic v2 data passes v2 constraints and fit checks |
| M15 | `test_privacy_gate` | A deliberately leaky model is blocked |
| M15 | `test_fidelity_report_complete` | All six check families are reported, including discriminator AUC |
| M15 | `test_fidelity_detects_bad_generator` | A generator with independently shuffled columns fails the relationship and discriminator checks |
| M15 | `test_sequences_match_learned` | Synthetic inter-arrival gaps per segment match the learned distribution; month-end and salary-day peaks are present |
| M15 | `test_sequences_with_solver` | With pinned balances, sequences reconcile exactly and never breach the running-balance floor |
| M15 | `test_edge_patterns_not_copied` | Every mined pattern is reproduced; no synthetic value equals a real value seen fewer than `k_threshold` times |
| M15 | `test_scale_preserves_shape` | At 10× volume, distribution and degree measures stay within thresholds; no key collisions |
| M15 | `test_value_space_check` | A unique field too small for the requested volume → `ERR_VALUE_SPACE` |
| M15 | `test_relearn_pinned` | Re-learning creates a new version with a drift report; existing references are unchanged until moved |

### 27.3 Definition of Done (Part B)
All Part A and Part B tests green; the fixture migration runs synthetic, masked
(using the fixture as "real") and dress rehearsals with zero differential diffs,
zero unexplained ledger rows and exact control totals; every sign-off recorded.

### 27.4 Fixture `samples/legacy_v1_to_core_v2/`

Two Postgres schemas plus seed data, deliberately different in structure:

**LEGACY_V1** (flat, coded, partly undeclared):
- `CUST_MASTER(CUST_NO varchar(10) PK, CUST_NAME varchar(80), DOB_TXT varchar(10) 'DD/MM/YYYY', CUST_TYPE char(1) {I,C,N}, KYC_FLG char(1) {Y,N,E}, ADDR varchar(200), PHONE1, PHONE2, PHONE3 varchar(15), FAX_NO varchar(15), REC_STATUS char(1) {A,P}, BRANCH_IFSC char(11))`
- `ACCT_MASTER(ACCT_NO varchar(12) PK, CUST_NO varchar(10)` *(no declared FK)*`, PROD_CD varchar(4), CCY char(3), BAL_AMT numeric(15,2), ACCR_INT numeric(15,2), STATUS char(1) {A,D,C}, OPEN_DT date)`
- `TXN_HIST(TXN_ID bigint PK, ACCT_NO varchar(12), TXN_DT date, AMT numeric(15,2), DR_CR char(1), NARRATION varchar(100))`
- `STANDING_INSTR(SI_ID bigint PK, ACCT_NO varchar(12), AMT numeric(15,2), NEXT_DT date, FREQ char(1))`
- `PENDING_PMT(PMT_ID bigint PK, ACCT_NO varchar(12), AMT numeric(15,2), VALUE_DT date)`
- view `V_CUST_ACCT` joining `ACCT_MASTER.CUST_NO = CUST_MASTER.CUST_NO` (for code mining)

**CORE_V2** (party-role, minor units, generated keys):
- `PARTY(PARTY_ID bigint generated PK, EXTERNAL_REF varchar(20) UNIQUE, PARTY_TYPE varchar(12))`
- `PERSON(PARTY_ID bigint PK FK, FIRST_NM varchar(60), LAST_NM varchar(60), BIRTH_DT date, RISK_RATING varchar(10) NOT NULL)`
- `PARTY_ROLE(PARTY_ID bigint FK, ROLE_TYPE varchar(12), SEGMENT_CD varchar(8))`
- `CONTACT_POINT(PARTY_ID bigint FK, TYPE varchar(8), VALUE varchar(20), SEQ smallint)`
- `ADDRESS(PARTY_ID bigint FK, ROLE varchar(12), LINE1 varchar(80), LINE2 varchar(80), CITY varchar(40), PIN char(6))`
- `ACCOUNT(ACCOUNT_ID bigint generated PK, PARTY_ID bigint FK, PRODUCT_CODE varchar(8), CURRENCY char(3), BALANCE_MINOR bigint, STATUS_CD varchar(10), OPENED_ON date, ACCRUED_INTEREST_MINOR bigint)` *(derived in v2)*
- `POSTING(POSTING_ID bigint generated PK, ACCOUNT_ID bigint FK, VALUE_DT date, AMOUNT_MINOR bigint, DIRECTION char(2), DESCRIPTION varchar(140))`
- `STANDING_ORDER(SO_ID bigint generated PK, ACCOUNT_ID bigint FK, AMOUNT_MINOR bigint, NEXT_DT date, FREQUENCY varchar(10))`
- Reference table `SEGMENT_REF(SEGMENT_CD, NAME)`; a small application code folder with
  one entity class showing `RISK_RATING` validation and `ACCRUED_INTEREST_MINOR` as computed.

**Seeded issues** (generated with Part A, seed 84921): about 2% unparseable `DOB_TXT`;
orphan accounts; duplicate customers by name and date of birth; names in Tamil and
Devanagari scripts; empty and partially filled phone slots; one `PROD_CD` with no
v2 equivalent; pending payments and standing instructions at the freeze date.

**`golden.csv`**: the correct field mappings with patterns, plus the expected
decisions: `FAX_NO` → archive; `RISK_RATING` → derive from segment; `ACCRUED_INTEREST_MINOR`
→ recompute; `PENDING_PMT` → settle before freeze; `STANDING_INSTR` → migrate.

---

## 28. Part B build plan

Milestones map to the architecture roadmap's phases. Do not begin a milestone until
its tests pass; each phase gate is recorded as a sign-off or a recorded check.

| Milestone | Builds | Tests (§ 27.2) | Roadmap phase |
|---|---|---|---|
| **M8 — Graph and planes** | § 18 DDL + migrations; `kg/` store, bitemporal queries, PROV-O export; worker process and `job` handoff; role checks skeleton | M8 tests | Phase 1 |
| **M9 — Source intelligence** | § 20: inventory, profiling, sketches, semantic types, UCC/IND/FD, code mining, structure solve, entities, DQ report; Sources and Evidence screens | M9 tests | Phase 1 · gate: known keys and links recovered on one real system |
| **M10 — Grounded LLM** | § 21.6–21.7, § 21.9 golden harness, § 25.3 masking, § 20.8 calibration bands; provider interface with stub and real provider | M10 tests | Phase 1–2 |
| **M11 — Concepts and specs** | § 19 grammar and checks, decisions, compose to `MappingPlan`, `REALISES`/`MAPS_TO` claims; Concepts screen | M11 tests | Phase 2 |
| **M12 — Discovery and review** | § 21.1–21.5, 21.8: alignment, retrieval, patterns, transforms, assignment, bands, review order, examples; Mapping review screen | M12 tests | Phase 2 · gate: one version change fully specified, no open decisions |
| **M13 — Prove on synthetic data** | § 22.1–22.4: interpreter, executor, crosswalk, partitions; § 23.2–23.5, 23.7: differential, fixtures, metamorphic, ledger, mutation | M13 tests | Phase 3 · gate: zero diffs, zero unexplained rows |
| **M14 — Migrate** | § 22.5–22.9: sizing, cutover, delta, rehearsals and diff, PONR; § 23.6, 23.8: reconciliation, comparator, test pack; cleanse rules and reject triage; four-eyes; Migration, Reconcile and Sign-offs screens | M14 tests | Phase 4 · gate: dress rehearsal reconciles, fits the window, behaviour signed off |
| **M15 — Learn** | § 24: learned degrees and marginals, `learned()` generators, target-shaped data, privacy gate, fidelity report, transaction sequences, edge-pattern mining, volume scaling, versioned re-learning; Learned models screen | M15 tests | Phase 5 · gate: privacy audit passes; fidelity within thresholds once set |

---

## 29. Pending decisions, open questions and risks

### 29.1 Review findings not yet decided (built only as extension points)

| Finding | Extension point left in Part B | To build when decided |
|---|---|---|
| 6 — Downstream consumers | `JOINS_ON`/`READS` claims from code mining already record consumers | A consumer-impact report per changed field, with cutover action and test |
| 7 — History scope | `history <concept>: <scope>` parses; compiler records it as a `history_scope` decision | Archive target, tiered extraction, retention checks |
| 12 — Concept versioning | Concepts carry the model version they were compiled in | Concept change impact across realisations and migrations |
| 13 — Document gaps | — | Sponsor summary, effort and team sizing in the architecture doc |

### 29.2 Open questions from the architecture doc (answers change configuration, not design)

Typical table and row counts per version change; whether both codebases are
available (`code_location`); allowed freeze window; whether v1 has watermarks or
logs for delta; approved LLM deployment (in-perimeter or zero-retention API); who
owns concept definitions.

### 29.3 Part B decisions log (seed entries for `DECISIONS.md`)

- **D5 — Knowledge graph in Postgres, not a graph database.** Claims as rows give
  edge properties, competing hypotheses, provenance and bitemporal history. Revisit
  above about 10 million edges with open-ended interactive traversals.
- **D6 — Two executors, shared transform library only.** Independence of the oracle
  matters more than code reuse.
- **D7 — LLM proposes, data verifies.** No LLM output becomes an accepted claim
  without deterministic validation and, for mappings, human approval.
- **D8 — Behaviour equivalence is enabled, not executed.** DataForge compares
  outputs and gates on the sign-off; the v2 or UAT team runs the processes.
- **D9 — Masking before any LLM call.** Format-preserving, keyed, irreversible from
  the control plane.

### 29.4 Part B risks

| Risk | Mitigation in this design |
|---|---|
| A wrong spec passes differential tests (both paths read the spec) | Round trip, control totals, behaviour comparator, reviewer examples |
| Reviewer fatigue | Impact ordering, bulk approval only for high band, sign-off audit |
| Concept model sprawl | Concepts created only from aligned clusters in an active migration |
| LLM drift after a provider update | Pinned model ids; golden-set gate before any change |
| Data-plane approvals delay the programme | M8–M13 run on fixtures and synthetic rehearsals without production access |
