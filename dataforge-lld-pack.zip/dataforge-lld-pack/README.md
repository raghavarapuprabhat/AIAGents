# DataForge LLD package — v3.4

| File | Use |
|---|---|
| `LLD.md` | The specification. Part A (§ 0–14, M0–M7): synthetic generator. Part B (§ 15–29, M8–M15): source intelligence, mapping and migration. Part C (§ 30–44, M16–M24): agentic layer — system models from DDL or JSON Schema (§ 42); attachments, mapping sheets, scripts and commands (§ 43); authoring and runtime tiers with MDL-only promotion (§ 44). |
| `BUILD-PROMPTS.md` | Sequenced prompts: P0–P8 Part A, P9–P16 Part B, P17–P25 Part C, each with a verifiable check. |
| `aggregate-constraint-engine.zip` | Tested solver reused in Part A and for control totals in Part B. |

Design rationale lives in the Claude Doc "DataForge — Intelligent Migration &
Learned Generation Architecture" and its Independent review tab.

Suggested run: Claude Code in an empty repo → attach `LLD.md` and the solver zip →
session opener from `BUILD-PROMPTS.md` → one prompt per session, verify its check,
commit, continue. Part C needs M8–M13; build P17 and P18 first and prove the schema
agent loop. P25 (promotion) can be built any time after P18 and must be done before
an agent-authored model is used in SIT.
