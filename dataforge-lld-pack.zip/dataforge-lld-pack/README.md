# DataForge LLD package — v2.0

| File | Use |
|---|---|
| `LLD.md` | The specification. Part A (§ 0–14, M0–M7): synthetic generator. Part B (§ 15–29, M8–M15): source intelligence, mapping and migration. |
| `BUILD-PROMPTS.md` | Sequenced prompts: P0–P8 for Part A, P9–P16 for Part B, each with a verifiable check. |

Also needed: `aggregate-constraint-engine.zip` (reused in Part A and for control
totals in Part B). Design rationale for Part B lives in the Claude Doc
"DataForge — Intelligent Migration & Learned Generation Architecture" and its
Independent review tab.

Suggested run: Claude Code in an empty repo → attach `LLD.md` and the solver zip →
session opener from `BUILD-PROMPTS.md` → one prompt per session, verify its check,
commit, continue. If Part A is already built, start at P9.
