# WalkMe → Compass Migration Plan

**Document status:** Draft v1.1 — Migration Working Group (v1.1 adds §6A Automation toolkit and tooling-adjusted durations)
**Companion documents:** Compass Architecture v1.0 (HLD), Architecture v2.0 (AI edition), Compass LLD (PoC edition)
**Prerequisite:** This plan executes against the **production-hardened** Compass build (post-PoC: authentication, containerized deployment, ClickHouse, edge delivery restored per the HLD). The PoC informs it but does not gate it.
**Scope:** Migration of all WalkMe deployments — StraightBank web (primary, ~60,000 licensed users) and any WalkMe usage on internal portals — to Compass, followed by WalkMe decommission and license termination.

---

## 1. Objectives & success definition

| Objective | Measure |
|---|---|
| Zero end-user disruption | No period without guidance on migrated journeys; support-ticket rate for "help/guidance" topics does not rise >10% above baseline during migration |
| Functional parity or better on what matters | Top-20 journeys achieve flow-completion rates ≥ WalkMe baseline within 4 weeks of cutover |
| Content estate rationalized, not copied | ≤70% of WalkMe items migrated; the remainder consciously retired with owner sign-off |
| Clean financial exit | WalkMe license not renewed at the next anniversary; no overlap beyond one contracted renewal cycle |
| Sovereignty goals realized | Middle East restricted markets served from Compass edge delivery on day one of their cutover |

**Definition of done:** all tenants live on Compass for ≥60 days with KPIs green, WalkMe snippet removed from every property, WalkMe contract terminated, export archive vaulted, and the migration working group dissolved.

## 2. Guiding principles

1. **Migrate journeys, not items.** The unit of migration is a user journey (e.g., "first international transfer"), not a WalkMe object. Items are triaged in journey context — this is what prevents mechanical porting of dead content.
2. **Never co-render.** WalkMe and the Compass agent must never both be active on the same page for the same user (double overlays, conflicting z-index/focus behavior). Enforced technically (§7.2), not by convention.
3. **Re-author, don't transliterate — but automate the re-authoring.** WalkMe exports are the *brief*, not the artifact. Structure, copy, translations, and metadata are machine-converted into Compass **drafts** (§6A); anchors are always freshly captured — tool-assisted via migration mode, never imported — because auto-converting WalkMe selectors would import their fragility. Automation raises throughput; it never bypasses maker-checker.
4. **Baseline before you move.** No journey cuts over without a recorded WalkMe performance baseline (completion, drop-off, engagement) to compare against.
5. **Cohort-based, reversible.** Cutover proceeds by user cohorts with a same-day rollback path (flip the cohort flag back) until the tenant-level decommission gate.

## 3. Phase plan overview

| Phase | Name | Duration | Exit gate |
|---|---|---|---|
| M-1 | **Toolkit build** (`compass-migrate`, §6A) | 3–4 wks (before/overlapping M0) | Converter + migration mode pass their fixture suites |
| M0 | Mobilize & license posture | 2 wks | Working group chartered; WalkMe renewal date and export entitlements confirmed |
| M1 | Inventory & export | **~1 wk** (was 3) | Register auto-generated from exports; raw export archived |
| M2 | Triage & journey mapping | **1–2 wks** (was 3) | Auto-triage recommendations batch-confirmed by owners; backlog journey-grouped, owner-signed |
| M3 | Re-authoring & translation | **2–3 wks** (was 6–8) | Converted drafts anchor-confirmed via migration mode; top journeys in Compass UAT; Arabic parity for ME-scoped content |
| M4 | Parallel run (UAT + prod shadow) | 3 wks | Compass KPIs ≥ baseline in pilot cohort; coexistence controls proven; nightly readiness report green |
| M5 | Cohort cutover | 4–6 wks | 100% users on Compass per tenant; 2-week bake per cohort |
| M6 | Decommission & exit | 3 wks + contractual notice | Snippets removed, data archived, contract terminated |

Validation phases (M4–M5) deliberately keep their original durations — automation compresses *production* of content, not the observation windows that prove it works.

Total elapsed: roughly one quarter of active migration after Compass production readiness, deliberately timed so M6 completes ≥60 days before the WalkMe renewal date — that date is the single hardest constraint in this plan and should be pinned to the top of the program board.

## 4. M0 — Mobilize & license posture

- Charter the working group: migration lead, Compass platform owner, one content owner per business area, WalkMe admin, app-team liaison per host application, analytics lead, comms/training lead. RACI in §12.
- **Contract actions now:** confirm renewal/notice dates and required notice period; confirm data-export entitlements (Insights data, content export/API) survive until termination; do **not** signal non-renewal until M4 exit is green — losing vendor support mid-migration is a self-inflicted risk.
- Freeze the WalkMe estate: from M1 onward, new WalkMe content requires migration-lead approval (build it in Compass instead unless it's urgent production support).
- Pin the environment plan: which host apps, which Compass tenants, cohort mechanism per app (see §7.1).

## 5. M1 — Inventory & export

**5.1 What to extract from WalkMe (while fully licensed):**

| Artifact | Method | Notes |
|---|---|---|
| Smart Walk-Thrus, SmartTips, Launchers, ShoutOuts, Shuttles, Surveys | Editor export / admin API | Full definitions incl. steps, conditions, segments |
| Segmentation rules & user attributes in use | Admin console review | Needed to map onto Compass claims (role, dept, country, locale, tenure) |
| Multi-language variants | Text & translation export | Feeds Compass translation tables — this is reusable as-is (§6.3) |
| Insights analytics (≥12 months) | Reports/API export | Baselines (§8) + usage ranking for triage |
| Element selectors per item | From exports | Reference only — never imported (Principle 3); useful to locate the intended element during re-capture |
| Media assets | Asset export | Re-uploaded through Compass media pipeline (validation + sanitization apply) |

**5.2 Inventory register (automated).** Generated by `compass-migrate ingest` (§6A.1) directly from the WalkMe content and Insights exports into the Content Service's import-staging tables: one row per item — id, type, host app/page, locales, 12-month usage (views, completion), last-modified, segment(s) — with business owner and journey assignment as the only human-entered columns. The staging tables are the authority; a console Migration screen surfaces them for triage.

**5.3 Archive.** The raw export bundle is vaulted (immutable storage, retention per records policy) before any triage — this is the insurance policy and the audit artifact for the decommission gate.

## 6. M2–M3 — Triage, mapping, and re-authoring

**6.1 Triage rules (applied per item, decided per journey):**

| Disposition | Criteria | Expected share (typical) |
|---|---|---|
| **Retire** | Zero/near-zero usage in 12 months; refers to removed UI; duplicate; obsolete process | 30–50% |
| **Merge** | Overlapping items covering one journey → single Compass flow | 10–15% |
| **Migrate** | Active, accurate, journey-relevant | 30–40% |
| **Rebuild** | High-value journey where the WalkMe version was a workaround (e.g., long tooltip chains standing in for a proper branched flow, or missing Arabic) — design fresh in Compass | 10–15% |

Every Retire decision needs the business owner's sign-off recorded in the register. The 12-month usage export makes these conversations short.

**6.2 Capability mapping (authoring reference):**

| WalkMe | Compass | Migration notes |
|---|---|---|
| Smart Walk-Thru | Flow | Branch/auto-advance logic re-expressed in step `advance`/`branch`; WalkMe "peer steps" → branch targets |
| SmartTip (guidance/validation) | Tip (hover/focus/always; validation on form fields) | Validation sets map to per-field Tips |
| Launcher | Launcher (overlay or inline placement) | Inline placement needs tenant flag + app-team sign-off |
| ShoutOut | Announcement (modal/banner/toast, scheduled) | Scheduling windows carried over |
| Shuttle | Deep Link | URL pattern re-verified per environment |
| Survey / NPS | Survey (nps/scale/single/multi/text) | Historic responses stay in the archive; new responses accrue in Compass |
| Segments / audience rules | Segments (rule tree → bytecode) | Attribute-by-attribute mapping to identity claims; any WalkMe attribute without a Compass claim goes to the identity backlog **before** the dependent items are scheduled |
| Onboarding tasks / permalinks | Flow sequences + Deep Links | Composite — treat as Rebuild |

**6.3 Re-authoring workflow per journey (tool-assisted):** open the converted draft (6A.3) in the extension's **migration mode** (6A.4) → confirm/auto-accept anchors step-by-step (data-guide requests auto-queued for sub-0.60 steps, batched per app release train) → polish copy to current tone standards (pre-filled from the converter) → review pre-filled translations, gap-fill via the workflow, Arabic RTL preview mandatory for ME-scoped items → maker-checker review → publish to UAT.

**6.4 Throughput planning (tooling-adjusted).** With migration mode, assume **1–2 author-hours per Migrate item** (anchor confirmation + copy polish) and 1–2 author-days per Rebuild journey; Rebuilds are unaffected by the converter and dominate the residual effort. For a typical 300-item estate triaged to ~180, that's roughly 2 authors for **2–3 weeks** per major tenant. Track two velocities from week one — auto-accept rate and confirmations/hour — and re-forecast M5 at each weekly review; a low auto-accept rate is the early signal to accelerate data-guide batches.

## 6A. Automation toolkit — `compass-migrate`

A purpose-built toolkit (est. 3–4 engineer-weeks AI-assisted, built as phase M-1) automates every mechanical part of the migration. Governance is untouched by design: **all automated output lands as drafts in maker-checker; nothing auto-publishes.**

**6A.1 `ingest` — inventory automation (drives M1).** Parses the WalkMe content export/API and the Insights usage export; loads the register into import-staging tables; flags export gaps (items present in Insights but missing from content export, and vice versa) for the WalkMe admin to chase while the license is live.

**6A.2 `triage` — recommendation engine (drives M2).** Deterministic, explainable rules over the register — no ML needed: zero/near-zero 12-month usage → *Retire-recommended*; ≥80% step overlap with a same-page item → *Merge-recommended* (pairs listed); references to URLs/pages that 404 on current UAT → *Retire-recommended (dead UI)*; remainder → *Migrate* / *Rebuild* per the §6.1 criteria signals. Owners confirm **in batches** from the console Migration screen; every confirmation is the §6.1 sign-off, audit-logged. Human authority preserved, human analysis eliminated.

**6A.3 `convert` — draft generation (drives M3).** Transforms WalkMe definitions into Compass `guide.schema.json` drafts:

| WalkMe input | Automated output | Fidelity |
|---|---|---|
| Walk-Thru steps, titles, balloon text | Flow steps; text mapped into the rich-text AST (unsupported markup stripped, logged per step) | High |
| ShoutOut content + schedule | Announcement + schedule window | High |
| Survey/NPS definitions | Survey schema (question types mapped) | High |
| Language/translation exports | Pre-filled Compass translation tables (status `machine`) | High |
| Segments/audience rules | Compass rule trees via the attribute-mapping table; unmappable clauses attached as **draft warnings**, never silently dropped | Medium |
| Media assets | Re-upload through the Compass media pipeline (validation + SVG sanitization apply) | High |
| Element selectors | **Not converted** — carried as per-step *hints* for migration mode (6A.4) | By design |

Converter correctness is proven by a fixture suite: representative WalkMe export samples with expected Compass drafts, run in CI — the M-1 exit gate.

**6A.4 Migration mode — tool-assisted anchor recapture (the throughput multiplier).** A mode in the Studio extension that walks the author through a converted draft step-by-step on the live UAT page. Per step it evaluates the old selector hint plus text/attribute heuristics, highlights its best-guess element, and computes the fresh Compass fingerprint and strength. Author action per step: **one keystroke to confirm**, or click the correct element if the guess is wrong. **Auto-accept policy:** where the old selector resolves to exactly one element *and* the fresh fingerprint scores ≥0.85, the anchor is accepted without a keystroke and marked `auto-matched` (visible in review); guesses scoring 0.60–0.84 require explicit confirmation; below 0.60 the step is queued with a "request data-guide" task. Effect: anchor recapture drops from the dominant cost (0.5–1 author-day/item) to minutes per item — the source of the M3 compression. With the v2 AI tier enabled, capability B1 (semantic DOM matching) raises the auto-match rate further, and A2/A3 conform imported copy to tone standards and gap-fill translations — still as drafts.

**6A.5 `verify` — continuous readiness (drives M4–M5).** Nightly Playwright job walks every migrated flow on UAT asserting all anchors resolve above threshold and each flow's happy path completes; output is the **migration readiness report** (per journey: green/amber/red with failing steps). The coexistence scanner probes every host property for simultaneous WalkMe+Compass emission. The migration scorecard (§8) is generated on schedule from both analytics sources.

**6A.6 What is deliberately not automated.** Retire/merge confirmations (audit authority), copy quality judgment, checker approvals, translation linguistic review, phase-gate go/no-go. These are cheap in time and expensive in accountability to automate.

## 7. M4–M5 — Parallel run and cohort cutover

**7.1 Cohort mechanism.** The provider decision is made **server-side per user** by the host application: at page render it includes either the WalkMe snippet or the Compass snippet, driven by a cohort flag (host app's feature-flag system, or a simple attribute pushed from the identity claim, e.g., `guidance_provider`). Cohort granularity: department or branch cluster, sized so the first cohort is ~5% of the tenant, then 25% → 60% → 100%.

**7.2 Coexistence controls (Principle 2, enforced):**
- Primary control: the server-side either/or above — the two snippets are never emitted together.
- Backstop: the Compass agent no-ops (with a diagnostic beacon) if it detects a live WalkMe global on the page; a synthetic gallery case covers this.
- Freeze rule: once a cohort is on Compass, WalkMe content changes no longer apply to them — comms must set that expectation with content owners.

**7.3 Parallel-run validation (M4, pilot cohort only).**
- Two weeks minimum on real production traffic for the pilot cohort.
- Watch: flow completion vs. WalkMe baseline per journey, anchor-fail/low-confidence rate (<0.5% of step views), agent error rate (<0.1% of sessions), page-performance deltas on the host app (no LCP/INP regression), guidance-related support tickets.
- Author feedback loop: daily triage of anchor-drift and low-confidence beacons during the pilot; heal or re-capture same-day.
- Nightly `compass-migrate verify` readiness report (6A.5) must be fully green for a cohort's journeys before that cohort's flag flips — this replaces manual pre-cutover walkthroughs.

**7.4 Cutover rhythm per cohort:** flip flag Monday → daily KPI check → Friday review → proceed/hold. Rollback = flip the flag back (minutes); rollback triggers are pre-agreed (completion drop >10 pts on a top journey, error rate breach, or a Sev-2 host-app incident attributable to guidance).

**7.5 Restricted-market cohorts (ME).** These cohorts cut over only after their in-region Compass edge delivery node passes its readiness check (bundle latency, beacon buffering, kill-switch propagation). Because WalkMe access was constrained in these markets anyway, they typically experience the migration as a net-new capability — sequence them early enough to bank that win, late enough to benefit from pilot learnings (recommended: cohort 2 or 3).

## 8. Analytics: baseline, comparison, and continuity

- **Baseline capture (M1):** per top-20 journey — starts, completion %, step drop-off, engagement per tip/launcher, survey response rates; 12-month history exported and summarized into a baseline sheet frozen at M2.
- **Comparison method:** Compass funnel metrics per journey vs. baseline, same-cohort-before/after where possible (cleanest signal), plus pilot-vs-control across cohorts during M4/M5. Expect a settling dip in week one post-cutover (novelty + re-learned launchers); judge at the 4-week mark.
- **Continuity:** WalkMe Insights history does not import into Compass (different identity and event models). The vaulted export is the historical record; Compass Insights starts fresh per cohort. Dashboards during migration show both sources side by side from the baseline sheet — the analytics lead owns this "migration scorecard."

## 9. M6 — Decommission & exit checklist

1. All cohorts at 100% Compass, ≥60-day tenant bake complete, KPIs green, open Sev tickets zero.
2. Remove WalkMe snippet from every host application (app-team change tickets; verify via synthetic scan of all properties for WalkMe artifacts).
3. Disable WalkMe editor accounts; revoke SSO app registration; remove desktop editor from software catalog and endpoints.
4. Final Insights/content export; verify archive completeness against the M1 register; vault.
5. Serve contractual non-renewal notice per the notice period confirmed in M0; obtain vendor confirmation of data deletion per contract/DPA.
6. Network controls: remove WalkMe domains from proxy allow-lists (this is also the technical backstop proving nothing still calls it).
7. Update the application inventory/CMDB, DR docs, and the bank's third-party register; close the vendor-risk file.
8. Retrospective + handover: migration working group dissolves; steady-state ownership per the Compass operating model (platform team + tenant content owners).

## 10. Communications & enablement

- **Authors/content owners:** hands-on Compass Studio training in M3 week 1 (the LLD's authoring UAT script doubles as the course lab); office hours through M5; the WalkMe→Compass capability mapping (§6.2) issued as a one-pager.
- **End users:** deliberately minimal — guidance should feel continuous. A short "your in-app help has a new look" announcement (delivered as a Compass Announcement, fittingly) at each cohort's cutover; branch champions briefed for the pilot cohort.
- **Service desk:** knowledge article set (what changed, known differences, how to report a guidance issue) live before the pilot; guidance issues tagged distinctly so §7.3's ticket metric is measurable.

## 11. Risks & mitigations

| Risk | L | I | Mitigation |
|---|---|---|---|
| Renewal date arrives before M5 completes | M | H | Renewal date pinned at M0 with ≥60-day buffer; monthly re-forecast from authoring velocity; worst case: negotiate short extension or reduced-seat bridge — decision point at M4 exit |
| Re-authoring throughput below plan | L | M | Migration mode compresses the dominant cost; auto-accept rate + confirmations/hour tracked from M3 week 1; levers: data-guide batches, added authors, more aggressive retirement — never compress M4 validation |
| Toolkit defects convert content subtly wrong (dropped markup, mangled rules) | M | M | Fixture suite as M-1 exit gate; converter logs every stripped/unmapped element as a draft warning; maker-checker remains the human backstop for all converted content |
| Over-trust in auto-accepted anchors | L | M | `auto-matched` flag visible in review; nightly verify job exercises every anchor on UAT; auto-accept threshold (≥0.85 + unique old-selector match) tunable downward if drift appears |
| Segment attributes missing from identity claims | M | M | Attribute gap analysis in M2; identity backlog items scheduled before dependent journeys |
| Anchor quality poor on legacy screens | M | M | `data-guide` batch requests riding app release trains from M2; picker strength thresholds enforced at authoring |
| Double-render incident | L | H | Server-side either/or + agent-side WalkMe-detection no-op + gallery case |
| Baseline dispute ("Compass is worse") without data | L | M | Frozen baseline sheet + migration scorecard; 4-week judgment rule agreed up front |
| Vendor support degrades after non-renewal signal | M | M | Non-renewal notice only after M4 exit; export archive completed in M1, not at the end |
| ME edge node not ready for its cohort | L | M | Edge readiness check is a named gate; those cohorts re-sequence rather than block the program |

## 12. Governance & RACI (summary)

| Activity | R | A | C | I |
|---|---|---|---|---|
| Inventory & export | WalkMe admin | Migration lead | Content owners | Platform team |
| Triage decisions | Content owners | Business-area heads | Migration lead | Analytics lead |
| Re-authoring | Compass authors | Content owners | App teams (data-guide) | Platform team |
| Cohort cutover | Migration lead | Program sponsor | App teams, service desk | All users (comms) |
| Decommission & contract exit | Migration lead | CIO office / vendor mgmt | Legal, security | Finance |

Weekly working-group review through M5 (scorecard, velocity, risk log); gate reviews at each phase exit chaired by the program sponsor.

## 13. Financial view

- Avoided cost: ~USD 200K/yr license from the first non-renewed anniversary, plus avoided expansion licensing (HR/Ops tenants, >60K growth).
- Migration cost (indicative, tooling-adjusted): toolkit build ~3–4 engineer-weeks (one-time, reused for every tenant) + 2 authors × ~3 weeks per major tenant + working-group overhead + app-team tickets (snippet swap, data-guide batches) — order of one-time USD 40–70K equivalent internal effort for the StraightBank tenant, with each subsequent tenant cheaper since the toolkit and playbook already exist.
- The plan's financial rule: **one renewal cycle of overlap maximum**; if migration slips past that, the M4-exit decision point chooses between a negotiated bridge and descoping the tail — never an unplanned full-price renewal.
