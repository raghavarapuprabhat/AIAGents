# Compass — 4-Minute Pitch Video Script

**Target length:** ~590 spoken words ≈ 4:00 at a natural 145 wpm. Timestamps are cues, not shackles.
**Format suggestion:** you on camera for the hook and the close; screen-share / visuals for the middle. Judges remember faces at the start and end, and evidence in the middle.

---

## [0:00–0:25] THE HOOK — open with the money and the risk

**On camera, no slides.**

> "Every year, our bank pays two hundred thousand dollars to rent tooltips. That's WalkMe — the third-party tool that guides our users through our own applications. And the price is the *smallest* problem. It's cloud-hosted outside our control, it's had publicly reported vulnerabilities, it can't even be served in some of our Middle East markets, and when it breaks — our banking experience breaks with it. I'm here to pitch Compass: our own digital adoption platform. Built in-house. Owned forever. And better than the product it replaces."

*Why this works: judges hear a number, a risk, and a claim in 25 seconds. The word "rent" frames the whole pitch.*

## [0:25–0:55] THE PROBLEM — make the dependency visceral

**Visual: one slide — four icons: 💰 $200K/yr · 🌍 geo-blocked markets · 🐛 vendor-paced fixes · ⚡ third-party scripts in banking pages.**

> "Today, sixty thousand users depend on guidance we don't control. Every enhancement waits in a vendor queue. Every WalkMe outage is *our* outage. Every user we add raises the bill — and we want this same capability on our HR and operations portals, which under per-user pricing means the cost compounds. And we inject their code into our banking screens. In a bank, that last sentence should make everyone uncomfortable."

## [0:55–1:50] THE SOLUTION — Compass in one breath, then the technical spine

**Visual: the architecture diagram (simplified 4-box version: Agent → Signed Content → Studio → Insights).**

> "Compass is one lightweight script — written entirely by us, zero third-party code — that delivers walk-throughs, smart tips, launchers, announcements, and surveys across any of our web applications, in any language including full Arabic right-to-left.
>
> Three engineering decisions make it bank-grade. First: **guidance is data, not code.** Authors create declarative content — no scripts ever execute in our apps, which eliminates the entire class of injection risk WalkMe-style tools carry. Every published bundle is cryptographically signed; the agent verifies before it renders.
>
> Second: **self-healing anchors.** Instead of fragile selectors, Compass fingerprints each element with multiple signals — and when an app release changes the UI, it detects the drift, proposes the fix, and an approver accepts it in one click. That's the problem that kills these tools in production. We engineered for it on day one.
>
> Third: **fail-open by design.** If Compass ever fails, the banking screen works perfectly — guidance just quietly steps aside. It is architecturally incapable of breaking the user experience."

## [1:50–2:30] SHOW, DON'T TELL — the demo beat

**Visual: 30–40 seconds of screen recording — the two mockups. Extension: click an element, anchor strength appears, step created. Console: review diff → publish checklist.**

> "And here's the part that makes it real: business teams author this themselves — no developers. Watch: our author clicks the Submit button on the live screen… Compass captures it, scores the anchor at 0.97, and the step is created. Copy is written right on the page, translated to Arabic in the console, and then — because we're a bank — every change goes through maker-checker approval and a signed, one-click-rollback publish. WalkMe's editor is a desktop app with a pairing bridge. Ours lives where the work lives: the browser."

## [2:30–3:15] BUSINESS VALUE — the numbers slide

**Visual: three big figures: $200K/yr saved · break-even <24 months · $0 marginal cost per new app/user.**

> "The business case is unusually clean. Two hundred thousand a year saved on StraightBank alone — and that's the floor, because HR and Ops portals onboard at *zero* marginal license cost, and growth past sixty thousand users costs nothing. Break-even inside twenty-four months; every year after is pure savings. But the strategic value is bigger than the invoice: full data sovereignty, no vendor on our critical path, day-one service to restricted markets through our own edge delivery — turning our biggest WalkMe limitation into a Compass strength — and analytics we own, showing exactly where users struggle in every journey. We stop renting a capability and start owning an asset."

## [3:15–3:40] CREDIBILITY & FUTURE — de-risk, then excite

**Visual: roadmap strip: PoC → Pilot tenant → StraightBank migration → AI layer (optional).**

> "This isn't a napkin. We have the full architecture, a developer-ready specification, working UI prototypes, and an automated migration toolkit that converts our WalkMe estate into Compass drafts — cutting migration from months to weeks. And the platform is AI-ready by design: an optional layer adds draft-generation from our SOPs, AI-assisted translation, and a conversational 'how do I…?' assistant grounded only in our approved content — on-premise models, enabled only when the bank chooses."

## [3:40–4:00] THE CLOSE — the ask

**On camera again.**

> "The ask is simple: greenlight a proof of concept. Small team, weeks not months, and the plan is already written. A year from now, we can be negotiating another renewal for someone else's product — or running our own platform, serving every market, every portal, every user, at zero license cost. Let's build Compass. Thank you."

---

# How to impress the judges — beyond the words

**Structure logic (why this order wins):** money-hook → pain → *three* technical proofs → live demo → ROI → de-risk → ask. Judges scoring "technical value" get named engineering decisions (declarative content, signed bundles, self-healing anchors, fail-open) — not buzzwords. Judges scoring "business value" get a floor-not-ceiling ROI and a strategic sovereignty story.

**The five impressions to land:**
1. **Say a number in the first ten seconds.** $200K anchors everything.
2. **The demo beat is your differentiator.** Most pitches only have slides. Screen-record the two mockups (they're interactive HTML — capture real cursor movement). Thirty seconds of "watch the author click" beats three minutes of claims.
3. **One security sentence, delivered slowly:** *"No third-party code will ever again execute inside our banking screens."* Pause after it. For bank judges this is the line they'll repeat to others.
4. **Pre-empt the obvious challenge.** Judges will think "build vs buy always overruns." Your inoculation is in 3:15 — architecture done, spec developer-ready, migration automated. You're not asking them to imagine; you're asking them to greenlight something already designed.
5. **The closing choice frame** ("negotiating someone else's renewal — or running our own platform") gives judges the sentence *they* will use when advocating for you in deliberation. Always arm your advocates.

**Production tips for a 4-minute video:**
- Talking-head segments: eye-level camera, clean background, look into the lens for the hook and close.
- Rehearse to 3:45, not 4:00 — recordings always run long; under time reads as discipline.
- Captions on (judges often review with sound low), and put the three money figures on screen as text when spoken — dual-coding makes numbers stick.
- One visual per beat, never more. If a slide needs explaining, it's the wrong slide.
- End frame: "Compass — own the guidance." + your name/contact, held for 3 seconds.

**If Q&A follows, have three answers loaded:** (1) "Why not just negotiate WalkMe's price down?" → price is the smallest of four problems; sovereignty, geo-restrictions, and vendor-paced fixes don't negotiate. (2) "What's the biggest technical risk?" → anchor fragility; then explain multi-signal self-healing + the data-guide convention — showing you know your own hardest problem is itself impressive. (3) "Team and timeline?" → PoC: 2–3 engineers AI-assisted, ~8 weeks to a working pilot on an internal portal.
