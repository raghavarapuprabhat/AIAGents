# § 6.9 Aggregate constraints — financial arithmetic coherence

> Drop-in section for *DataForge — Cross-System Mock Data Generation Platform*.
> Insert after § 6.8 (negative datasets). A runnable reference implementation of
> everything described here ships in `agg-engine/`.

---

## The problem

Per-row realism is not enough in banking. Data can pass every column-level rule
and still be nonsense in aggregate: an account showing a balance of ₹52,000
whose transactions sum to something else, a journal whose debits and credits
don't net to zero, branch control totals that don't roll up to the GL, a loan
whose EMI schedule leaves ₹3.40 outstanding after the final instalment. These
break exactly the tests teams care most about — reconciliation, statement
generation, interest accrual, GL posting, regulatory reporting — and they are
invisible to row-by-row validation.

An aggregate constraint ties a parent value to an aggregate over linked child
rows. It runs in one of two modes:

* **derive** (bottom-up) — generate children freely, compute the parent. Trivial.
* **allocate** (top-down) — the parent value is *pinned* by a scenario ("premium
  dormant accounts hold ₹15–50 lakh"), so the children must be manufactured to
  sum to it exactly. This is the hard, interesting case, and it is the common
  one, because scenarios drive the test plan.

## MDL syntax

```mdl
aggregate ACCOUNT_BALANCE on CORE_BANKING.ACCOUNT {
  target  BALANCE
  over    PAYMENTS.TXN via link acc_txn
  define  BALANCE = OPENING_BAL + sum(TXN.AMOUNT)
  mode    allocate
  guard   running_balance >= 0 - OD_LIMIT      // prefix constraint, see below
}

// Row classes give the allocator its per-row freedom and lattice.
class PAYMENTS.TXN.AMOUNT {
  case CHANNEL == "SALARY"   -> range(20_000 .. 500_000)   quantum 100
  case CHANNEL == "ATM"      -> range(-50_000 .. -500)     quantum 500
  case CHANNEL == "NEFT_OUT" -> range(-200_000 .. -1_000)  quantum 1_000
  case default               -> range(-40_000 .. 60_000)   quantum 0.01  absorber
}

journal GL_POSTING {
  within  JOURNAL_ID
  drivers legs where ROLE == "DR"
  balance legs where ROLE == "CR"              // solved, not hand-written
  assert  sum(AMOUNT) == 0
}

rollup GL_CONTROL.TOTAL
  = sum(BRANCH_CONTROL.TOTAL)
  = sum(CORE_BANKING.ACCOUNT.BALANCE by BRANCH_CD)

schedule LOAN_SCHEDULE
  amortize(principal = LOAN.PRINCIPAL, rate = LOAN.RATE_BPS, tenor = LOAN.TENOR_M)
  closes_to zero absorbing rounding in final_row
```

## Why the obvious algorithms fail

Two approaches suggest themselves, and both produce unusable data.

**Sample then rescale** (draw *n* values, multiply each by `T / sum`) destroys
both bounds and meaning: a salary credit becomes ₹37,412.83, an ATM withdrawal
becomes ₹4,163.17, and rows silently escape their declared ranges.

**Sample n−1 and let the last row absorb the difference** concentrates all the
error in one row, which is then routinely out of bounds, negative when it should
be positive, or absurdly large. It also makes the last transaction of every
account statistically distinctive — a tell that testers and ML-based fraud
models will both notice.

## The solver

The engine works in **integer minor units (paise/cents) throughout**. No floats
appear anywhere in the allocation path, so "sums exactly" means exactly, not
within an epsilon — a decision that eliminates an entire class of reconciliation
bug by construction.

**Stage 1 — plan-time feasibility.** Each row class defines a lattice
(`value = quantum × k`) and bounds, so the reachable sums lie in
`[Σ min_i, Σ max_i]` intersected with the lattice. The engine checks this before
generating anything and fails with the *binding* constraint named, e.g.
`target 2,200,000 exceeds the maximum reachable sum 679,000 (6 rows at their
upper bounds) — lower the target, add rows, or raise the row maximums`. There is
also a lattice check with a genuinely non-obvious diagnostic: if every declared
class is a multiple of ₹100 but the target ends in ₹0.47, no allocation can
exist, and the engine says so and names the fix (declare an absorber class).
Catching this at compile time rather than three minutes into a 10-million-row
run is most of the practical value.

**Stage 2 — shape-preserving draw.** Each row is sampled from its declared
distribution (lognormal by default, which matches transaction-amount data far
better than uniform), clamped to its bounds, and snapped to its lattice.

**Stage 3 — residual apportionment.** The residual `T − Σ` is closed by spreading
it across rows *in proportion to each row's remaining slack in the needed
direction*, in whole quantum steps, using largest-remainder (Hamilton)
apportionment so the integer split is exact and unbiased. Rows that saturate drop
out and the pass repeats. Each pass either closes the residual or saturates at
least one row, so the loop terminates in at most *n* passes. Because the
correction is spread over many rows rather than dumped on one, the sampled
distribution survives: in the reference tests, no single row carries more than
25 % of gross movement.

**Stage 4 — absorber settlement.** Coarse lattices cannot express arbitrary
remainders, so a class may be declared `absorber` (quantum = 1 minor unit,
typically a POS/misc transaction class). Any final remainder settles there. This
is what makes mixed-lattice allocation solvable at all: salary credits stay round
hundreds and ATM withdrawals stay round five-hundreds while the account still
reconciles to the paise.

## The running-balance guard

An allocation can be arithmetically perfect and still absurd: if debits happen to
land before credits, a savings account dips to −₹80,000 mid-month. That both
fails target-system validation and changes the behaviour of dormancy, interest
and statement batch jobs.

The design decision here is that **repair is by permutation only**. Reordering
amounts across the (fixed) date slots leaves the multiset — and therefore the
sum — exactly unchanged, so the guard can never break the aggregate constraint
just solved. Rescaling or clamping amounts would.

This yields a clean feasibility result: **if the closing balance is ≥ the floor,
a valid ordering always exists** — place every credit before every debit and the
running minimum equals the closing balance. So the guard fails only when the
aggregate itself is infeasible against the floor, which is reported at plan time.
The implementation walks the slots in date order and, on a violation, promotes
the smallest future credit that fixes it (smallest, to disturb the sampled date
pattern as little as possible), falling back to the largest and finally to
deferring the offending debit.

## Composed forms

**Double entry.** A journal is the same primitive with target zero: driver legs
(the DR side) are generated freely, then the balancing legs are *solved* with the
allocator so they respect their own per-leg bounds instead of one leg absorbing
everything.

**Control-total rollups.** A GL hierarchy is nested allocation: allocate the GL
total across branches, then each branch subtotal across its accounts, then each
account balance across its transactions. Exactness at every level follows from
exactness of the primitive — the reference implementation reconciles a
₹2.15 crore GL total down to individual transactions with zero drift.

**Amortisation.** Not a solver problem but a *closure* problem. Computing an EMI
schedule in floats leaves several paise adrift over 240 months, producing loans
that never close. The engine walks the schedule in integer minor units,
recomputing interest on the live outstanding balance each period, and defines the
final row's principal component as whatever remains outstanding — so the loan
closes to exactly zero by construction.

## Engine integration

Aggregates are resolved inside Stage 3 of the generation engine (§ 4.3) as a
*column-group resolver*, after the child rows exist as row templates but before
values are finalised. The dependency planner already orders parents before
children; aggregates add a second, reverse-direction pass within the parent's
wave. Determinism is preserved because every draw derives from
`hash(seed, table, row_index, column)`, so re-running a dataset reproduces
identical allocations. Infeasible aggregates surface in the same plan-time
conflict report as unsatisfiable rules, alongside the minimal conflicting set.

## Reference implementation

`agg-engine/` contains a runnable Python implementation with a test suite
covering exactness over hundreds of randomised configurations, bound and lattice
compliance, determinism, distribution-shape preservation, all three
infeasibility diagnostics, running-balance repair (including its permutation and
sum-preservation invariants), journal balancing, nested rollups, and
amortisation closure. `demo.py` runs the full GL-to-transaction scenario end to
end.
