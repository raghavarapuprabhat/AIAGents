# DataForge — Low-Level Design & Build Specification
### Cross-system mock data generation platform for banking estates
**Version 1.0 · intended as direct input to an AI coding agent (Claude Sonnet)**

---

## 0. How to use this document

This is an implementation-ready specification. It is written to be executed
top-to-bottom by a coding agent, in the milestone order of § 13.

**Rules for the implementing agent**

1. Build in milestone order (M0 → M7). Each milestone has a Definition of Done
   with named tests. Do not begin a milestone until the previous one's tests pass.
2. Every file path in this document is authoritative. Create files exactly where
   specified so later milestones can find them.
3. Where this document gives a function signature, implement that signature
   exactly — later milestones call it.
4. The frontend must match the screen specs in § 10 (layout regions, component
   names, design tokens). The tokens in § 10.1 are exact hex values; do not
   substitute a UI library's defaults.
5. When something is ambiguous, prefer the simplest implementation that passes
   the stated acceptance test, and record the decision in `DECISIONS.md`.
6. Do not invent scope. Features not in this document are out of scope for v1.

**Companion artefacts referenced by this LLD** (delivered separately in the same
conversation; treat this document as authoritative if they disagree):

| Artefact | Role |
|---|---|
| `mock-data-platform-architecture.md` | High-level architecture and rationale (the "why") |
| `architecture-section-6.9-aggregate-constraints.md` | Deep design of the aggregate solver |
| `aggregate-constraint-engine.zip` | **Working, tested Python implementation of the aggregate solver — reuse it verbatim** |
| `dataforge-studio.zip` | React prototype of the UI — visual source of truth for § 10 |

---

## 1. Scope

### 1.1 What the system does

Users model the tables of several banking core systems, declare how those systems
and tables link to each other, describe what meaningful values look like, express
business rules, define test scenarios, then generate referentially-consistent
synthetic data across all systems and load it into target environments.

### 1.2 In scope for v1

Schema modelling with physical types; the MDL language and compiler; direct,
conditional and function-based links; system flow ordering with optional two-pass
back-references; value sets (correlated code/description tuples); rules with
conditional value domains; scenarios with weights and pairwise coverage;
aggregate constraints; seeded deterministic generation; validation and run
reports; CSV/JSON file output and JDBC + REST ingestion adapters; the Studio UI.

### 1.3 Out of scope for v1

Production data masking, mainframe integration, LLM copilot (stub the endpoint
and return canned suggestions), Kafka adapter, lifecycle state machines, fault
injection, RBAC/SSO (single trusted user), and the CP-SAT solver fallback
(forward-checking only — raise a clear error on genuinely interlocked rules).

---

## 2. Technology stack

**Decision: build v1 in Python.** The architecture document recommends the JVM
for the eventual production system, and that remains the long-term target. For
this build, Python is chosen because the aggregate-constraint solver is already
written and tested in Python (`aggregate-constraint-engine.zip`) and can be
dropped in unchanged, which removes the riskiest component from the critical
path. § 14 records the migration path.

| Layer | Choice | Version |
|---|---|---|
| Backend | Python + FastAPI | 3.11+, fastapi 0.115+ |
| ASGI server | uvicorn | 0.32+ |
| Validation | pydantic | v2 |
| ORM | SQLAlchemy 2.x + Alembic | 2.0+ |
| Database | PostgreSQL | 16 |
| MDL parser | Lark (earley/lalr) | 1.2+ |
| Data frames | polars | 1.x |
| Output format | Parquet + CSV | via polars |
| Target DB driver | psycopg[binary], plus SQLAlchemy for other targets | — |
| Testing | pytest, httpx | — |
| Frontend | React + Vite + TypeScript | React 18, Vite 5 |
| Canvas | reactflow | 11.x |
| Code editor | @monaco-editor/react + monaco-editor | latest |
| Frontend state | Zustand | 4.x |
| Package mgmt | uv or pip + requirements.txt; npm | — |

No CSS framework. Styling is plain CSS with the custom properties in § 10.1.

---

## 3. Repository layout

```
dataforge/
├── README.md
├── DECISIONS.md                    # agent records ambiguity resolutions here
├── docker-compose.yml              # postgres + api + web
├── backend/
│   ├── pyproject.toml
│   ├── alembic/
│   ├── app/
│   │   ├── main.py                 # FastAPI app factory, router registration
│   │   ├── config.py               # env settings (pydantic-settings)
│   │   ├── db.py                   # engine, session, Base
│   │   ├── models/                 # SQLAlchemy ORM models (§ 4)
│   │   │   ├── project.py  model.py  system.py  link.py
│   │   │   ├── valueset.py  scenario.py  run.py  drift.py
│   │   ├── schemas/                # pydantic request/response models (§ 9)
│   │   ├── api/                    # FastAPI routers, one file per resource
│   │   │   ├── models_api.py  tables_api.py  links_api.py  valuesets_api.py
│   │   │   ├── scenarios_api.py  runs_api.py  schema_import_api.py  copilot_api.py
│   │   ├── mdl/                    # § 5
│   │   │   ├── grammar.lark
│   │   │   ├── ast.py              # dataclasses for AST nodes
│   │   │   ├── parser.py           # text -> AST
│   │   │   ├── resolver.py         # name resolution against the model
│   │   │   ├── checker.py          # semantic checks -> Diagnostic[]
│   │   │   ├── compiler.py         # AST -> GenerationPlan IR
│   │   │   └── emitter.py          # model objects -> MDL text (round-trip)
│   │   ├── engine/                 # § 7
│   │   │   ├── plan.py             # GenerationPlan IR dataclasses
│   │   │   ├── planner.py          # flow + table topological ordering
│   │   │   ├── allocator.py        # scenario quotas + pairwise coverage
│   │   │   ├── rng.py              # deterministic per-cell RNG
│   │   │   ├── generators.py       # value generators registry
│   │   │   ├── valuesets.py        # tuple pick + binding
│   │   │   ├── rules.py            # domain narrowing / forward checking
│   │   │   ├── keyvault.py         # generated key store for link resolution
│   │   │   ├── links.py            # direct / conditional / function resolution
│   │   │   ├── aggregate/          # COPY OF aggregate-constraint-engine (§ 7.7)
│   │   │   ├── twopass.py          # deferred column patch sets
│   │   │   ├── validator.py        # post-generation assertions -> report
│   │   │   └── runner.py           # orchestrates stages, writes artefacts
│   │   ├── adapters/               # § 8
│   │   │   ├── base.py             # IngestionAdapter ABC
│   │   │   ├── file_adapter.py     # CSV / JSON / Parquet to disk
│   │   │   ├── jdbc_adapter.py     # SQLAlchemy bulk insert + patch UPDATEs
│   │   │   ├── rest_adapter.py     # HTTP POST/PATCH loader
│   │   │   └── registry.py
│   │   └── importers/              # schema import + drift (§ 7.9)
│   │       ├── sqlalchemy_importer.py  openapi_importer.py  drift.py
│   └── tests/                      # pytest, mirrors app/ structure
├── frontend/
│   ├── package.json  vite.config.ts  index.html
│   └── src/
│       ├── main.tsx  App.tsx  styles.css        # tokens in § 10.1
│       ├── api/client.ts                        # typed API client (§ 9)
│       ├── store/useStudio.ts                   # Zustand store
│       ├── components/                          # shared primitives
│       │   ├── TopBar.tsx  Tabs.tsx  StatusBar.tsx  Pill.tsx
│       │   ├── Panel.tsx  Segmented.tsx  AllocBar.tsx  ListRow.tsx
│       └── screens/
│           ├── CanvasScreen.tsx  TableNode.tsx  LinkInspector.tsx  ColumnInspector.tsx
│           ├── EditorScreen.tsx  mdlLanguage.ts
│           ├── ValuesetsScreen.tsx
│           ├── ScenariosScreen.tsx
│           ├── RunsScreen.tsx
│           └── SchemaImportScreen.tsx
└── samples/
    └── retail_bank/                # seed model used by tests and demos (§ 12.4)
        ├── core_banking.mdl  cards.mdl  payments.mdl
        ├── links.mdl  valuesets.mdl  scenarios.mdl
```

---

## 4. Data model (PostgreSQL)

All tables carry `id UUID PRIMARY KEY DEFAULT gen_random_uuid()`,
`created_at timestamptz NOT NULL DEFAULT now()`, `updated_at timestamptz`.

```sql
-- A project is one banking estate; a model_version is a snapshot of it.
CREATE TABLE project (
  id UUID PRIMARY KEY, name text NOT NULL UNIQUE, description text);

CREATE TABLE model_version (
  id UUID PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES project(id) ON DELETE CASCADE,
  label text NOT NULL,                    -- 'release_2026_R3'
  content_hash text NOT NULL,             -- sha256 of compiled IR, e.g. 'a41f9c...'
  seed bigint NOT NULL DEFAULT 84921,
  as_of date,                             -- dataset clock
  is_draft boolean NOT NULL DEFAULT true,
  UNIQUE (project_id, label));

-- Systems form a DAG via system_flow. Order matters (§ 7.2).
CREATE TABLE system (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,                     -- 'CORE_BANKING'
  display_name text,                      -- 'Core banking'
  connection_profile text,                -- 'sit2-corebank'
  adapter_type text NOT NULL DEFAULT 'file',  -- file | jdbc | rest
  ui_lane int NOT NULL DEFAULT 0,         -- swimlane order on the canvas
  UNIQUE (model_version_id, name));

CREATE TABLE system_flow (                -- parent -> child edges
  id UUID PRIMARY KEY,
  parent_system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  child_system_id  UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  UNIQUE (parent_system_id, child_system_id));

CREATE TABLE table_def (
  id UUID PRIMARY KEY,
  system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  name text NOT NULL,                     -- 'CUSTOMER'
  ui_x int NOT NULL DEFAULT 0, ui_y int NOT NULL DEFAULT 0,
  UNIQUE (system_id, name));

CREATE TABLE column_def (
  id UUID PRIMARY KEY,
  table_id UUID NOT NULL REFERENCES table_def(id) ON DELETE CASCADE,
  name text NOT NULL,
  ordinal int NOT NULL,
  -- physical type
  dtype text NOT NULL,                    -- VARCHAR|CHAR|NUMBER|INTEGER|DATE|TIMESTAMP|BOOLEAN
  length int, precision int, scale int,
  nullable boolean NOT NULL DEFAULT true,
  is_pk boolean NOT NULL DEFAULT false,
  -- semantics: exactly one of generator_spec / valueset binding is used
  generator_spec jsonb,                   -- {"kind":"enum","values":[...],"weights":[...]}
  valueset_id UUID REFERENCES valueset(id) ON DELETE SET NULL,
  valueset_field text,                    -- which tuple field this column takes
  describe_text text,                     -- natural-language description (copilot)
  UNIQUE (table_id, name));

CREATE TABLE valueset (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,                     -- 'ENTITY_TYPES'
  fields text[] NOT NULL,                 -- ['code','description','category']
  source text NOT NULL DEFAULT 'inline',  -- inline | csv | reference_table
  UNIQUE (model_version_id, name));

CREATE TABLE valueset_row (
  id UUID PRIMARY KEY,
  valueset_id UUID NOT NULL REFERENCES valueset(id) ON DELETE CASCADE,
  ordinal int NOT NULL,
  values text[] NOT NULL,                 -- aligned with valueset.fields
  weight int NOT NULL DEFAULT 1);

CREATE TABLE link (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,
  source_column_id UUID NOT NULL REFERENCES column_def(id) ON DELETE CASCADE,
  target_column_id UUID NOT NULL REFERENCES column_def(id) ON DELETE CASCADE,
  kind text NOT NULL,                     -- direct | conditional | function
  condition jsonb,                        -- {"column":"CPTY_TYPE","op":"==","value":"ACCOUNT"}
  transform_fn text,                      -- registered plugin name for kind=function
  card_min int NOT NULL DEFAULT 1,
  card_max int NOT NULL DEFAULT 1,
  back_reference boolean NOT NULL DEFAULT false,
  two_pass boolean NOT NULL DEFAULT false,
  UNIQUE (model_version_id, name));

CREATE TABLE rule (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,
  table_id UUID NOT NULL REFERENCES table_def(id) ON DELETE CASCADE,
  strength text NOT NULL DEFAULT 'hard',  -- hard | soft
  probability numeric,                    -- for soft rules
  when_expr jsonb NOT NULL,               -- expression AST
  then_expr jsonb NOT NULL,
  UNIQUE (model_version_id, name));

CREATE TABLE aggregate_constraint (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL,
  target_column_id UUID NOT NULL REFERENCES column_def(id),
  over_link_id UUID NOT NULL REFERENCES link(id),
  child_amount_column_id UUID NOT NULL REFERENCES column_def(id),
  opening_column_id UUID REFERENCES column_def(id),
  mode text NOT NULL DEFAULT 'allocate',  -- allocate | derive
  guard_floor_expr text,                  -- e.g. '0 - OD_LIMIT'
  row_classes jsonb NOT NULL);            -- [{case, lo, hi, quantum, absorber, mean}]

CREATE TABLE scenario (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  name text NOT NULL, weight numeric NOT NULL,
  overrides jsonb NOT NULL DEFAULT '{}',  -- {"CORE_BANKING.CUSTOMER":{"SEGMENT":"RETAIL"}}
  coverage jsonb,                         -- {"mode":"pairwise","dims":["A.B","C.D"]}
  ui_color text,
  UNIQUE (model_version_id, name));

CREATE TABLE run (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id),
  run_number serial,
  status text NOT NULL,                   -- queued|generating|ingesting|verified|failed
  seed bigint NOT NULL,
  volumes jsonb NOT NULL,                 -- {"CORE_BANKING.CUSTOMER": 5000}
  target_env text NOT NULL,
  started_at timestamptz, finished_at timestamptz,
  report jsonb,                           -- RunReport (§ 9.7)
  error text);

CREATE TABLE run_artifact (
  id UUID PRIMARY KEY,
  run_id UUID NOT NULL REFERENCES run(id) ON DELETE CASCADE,
  system_name text NOT NULL, table_name text NOT NULL,
  kind text NOT NULL,                     -- insert | patch
  path text NOT NULL, row_count bigint NOT NULL);

CREATE TABLE drift_item (
  id UUID PRIMARY KEY,
  model_version_id UUID NOT NULL REFERENCES model_version(id) ON DELETE CASCADE,
  system_id UUID NOT NULL REFERENCES system(id) ON DELETE CASCADE,
  kind text NOT NULL,                     -- added|changed|removed|breaking
  target text NOT NULL,                   -- 'CUSTOMER.PREF_LANG'
  detail text NOT NULL, suggestion text,
  breaking boolean NOT NULL DEFAULT false,
  state text NOT NULL DEFAULT 'pending',  -- pending|accepted|skipped
  scanned_at timestamptz NOT NULL DEFAULT now());
```

**Indexes:** FK columns; `run(model_version_id, run_number desc)`;
`drift_item(model_version_id, state)`.

---

## 5. MDL — language specification

### 5.1 Grammar (`app/mdl/grammar.lark`)

Implement this grammar. It is deliberately small; extend only if a § 12 test
requires it.

```lark
start: statement*
statement: system_def | flow_def | link_def | rule_def | valueset_def
         | scenario_def | dataset_def | aggregate_def | param_def

system_def: "system" NAME "{" system_body* "}"
system_body: conn_def | table_def
conn_def: "connection" "profile" STRING
table_def: "table" NAME "{" column_def* bind_def* "}"

column_def: "column" NAME ":" generator sqltype? flag*
generator: NAME ("." NAME)? ("(" arglist? ")")?
sqltype: "sqltype" NAME ("(" NUMBER ("," NUMBER)? ")")?
flag: "pk" | "not_null" | "nullable"
bind_def: "bind" "(" NAME ("," NAME)* ")" "<-" "pick" NAME "(" NAME ("," NAME)* ")"

flow_def: "flow" NAME ("->" NAME)+

link_def: "link" qname "->" qname link_opt*
link_opt: "when" expr
        | "cardinality" NAME "(" range ")"
        | "via" "fn" STRING
        | "via" "valueset" NAME "(" NAME "->" NAME ")"
        | "back_reference" ("(" "two_pass" ")")?

rule_def: "rule" NAME "on" qname "{" "when" expr ("then"|"prefer") expr probability? "}"
probability: "probability" NUMBER "%"

valueset_def: "valueset" NAME "{" "fields" "(" NAME ("," NAME)* ")"
              "values" tuple ("," tuple)* weights? "}"
tuple: "(" STRING ("," STRING)* ")"
weights: "weights" "(" NUMBER ("," NUMBER)* ")"

aggregate_def: "aggregate" NAME "on" qname "{" agg_opt* "}"
agg_opt: "target" NAME | "over" qname "via" "link" NAME
       | "define" expr | "mode" NAME | "guard" expr

scenario_def: "scenario" STRING "weight" NUMBER "%" coverage? "{" override* "}"
coverage: "coverage" "(" NAME "on" "[" qname ("," qname)* "]" ")"
override: qname "{" assign ("," assign)* "}"
assign: NAME "=" value

dataset_def: "dataset" NAME "{" ds_opt* "}"
ds_opt: "seed" NUMBER | "volume" qname "=" NUMBER | "target" "env" STRING
      | "as_of" STRING | "scenarios" NAME

param_def: "param" NAME ":" NAME "=" "input" "(" STRING ("," "default" "=" value)? ")"

expr: or_expr
or_expr: and_expr ("or" and_expr)*
and_expr: cmp ("and" cmp)*
cmp: operand (COMPARATOR operand)?
   | operand "in" "(" value ("," value)* ")"
operand: qname | value | func_call
func_call: NAME "(" (expr ("," expr)*)? ")"
COMPARATOR: "==" | "!=" | ">=" | "<=" | ">" | "<"
qname: NAME ("." NAME)*
range: NUMBER ".." NUMBER
value: STRING | NUMBER | "null"
arglist: arg ("," arg)*
arg: (NAME "=")? (value | NAME | func_call | range)

NAME: /[A-Za-z_][A-Za-z0-9_]*/
STRING: /"[^"]*"/
NUMBER: /-?\d[\d_]*(\.\d+)?/
%import common.WS
%ignore WS
%ignore /\/\/[^\n]*/
```

### 5.2 Compiler pipeline

`compile(model_version_id) -> (GenerationPlan, list[Diagnostic])`

Stages, in order, each producing diagnostics rather than raising:

1. **parse** — Lark → AST (`app/mdl/ast.py` dataclasses).
2. **resolve** — bind every `qname` to a system/table/column id. Unresolved name
   → `ERR_UNRESOLVED`.
3. **typecheck** — generator arguments match the generator's declared signature;
   comparison operand types are compatible.
4. **fit check** — every generator's possible output fits the column's physical
   type. Cases to implement: `id`/`regex` pattern length vs `VARCHAR(n)`;
   longest `enum` or valueset tuple value vs `VARCHAR(n)`; `decimal` range vs
   `NUMBER(p,s)`. → `ERR_FIT`.
5. **flow conformance** — every cross-system link must run parent→child along
   the `system_flow` DAG, unless `back_reference`. → `ERR_FLOW_DIRECTION`.
6. **link checks** — conditional links into the same target column must have
   pairwise-disjoint `when` conditions (compare literal equality sets;
   non-literal conditions produce `WARN_DISJOINT_UNPROVEN`). Cardinality
   `min <= max`, `min >= 0`.
7. **cycle check** — table-level dependency graph must be acyclic after removing
   `two_pass` edges. → `ERR_CYCLE`.
8. **rule satisfiability (shallow)** — for each table, if two hard rules with
   overlapping `when` conditions narrow one column's domain to the empty set,
   report `ERR_RULE_CONFLICT` naming both rules.
9. **aggregate feasibility** — call the solver's `check_feasible` with the
   scenario-implied target range and row-class specs (§ 7.7). → `ERR_AGG_INFEASIBLE`.
10. **emit IR** — build `GenerationPlan`; compute `content_hash` = sha256 of the
    canonical JSON of the IR.

### 5.3 Diagnostic model

```python
@dataclass
class Diagnostic:
    severity: Literal["error", "warning"]
    code: str                 # 'ERR_FIT'
    message: str              # human-readable, names the fix
    file: str | None          # 'cards.mdl'
    line: int | None; col: int | None
    length: int | None        # for editor squiggles
```

The `/api/models/{id}/compile` endpoint returns these; the Monaco editor renders
them as markers (§ 10.4).

### 5.4 Round-trip requirement

`emitter.py` must render model objects back to MDL text such that
`parse(emit(model)) == model` structurally. The UI edits objects; the editor
edits text; both must converge. **Acceptance test:** `test_mdl_roundtrip`.

---

## 6. Backend service design

FastAPI app with routers per resource. Each router is thin: validate → call a
service function → return a pydantic response. Business logic lives in
`app/engine/`, `app/mdl/`, `app/importers/` — never in routers.

**Session handling:** one SQLAlchemy session per request via dependency.
Long-running generation does **not** hold a request session; `runs_api.create_run`
persists a `run` row with status `queued`, schedules the job on a background
task, and returns immediately. The frontend polls `GET /api/runs`.

**Background execution:** FastAPI `BackgroundTasks` for v1 (single process).
Wrap the entry point so a crash marks the run `failed` with the traceback in
`run.error`. Interface must be swappable for Celery/Temporal later:

```python
# app/engine/runner.py
def execute_run(run_id: UUID) -> None: ...       # the only entry point
```

---

## 7. Generation engine

### 7.1 Plan IR (`app/engine/plan.py`)

```python
@dataclass(frozen=True)
class ColumnPlan:
    name: str; dtype: str; length: int | None
    precision: int | None; scale: int | None; nullable: bool
    generator: dict                     # {"kind": "...", ...}
    valueset: str | None; valueset_field: str | None
    is_pk: bool

@dataclass(frozen=True)
class TablePlan:
    system: str; name: str
    columns: tuple[ColumnPlan, ...]
    parent_links: tuple[str, ...]       # link names that populate this table
    volume_expr: str | None             # explicit volume, else derived

@dataclass(frozen=True)
class LinkPlan:
    name: str; kind: str
    src_system: str; src_table: str; src_column: str
    tgt_system: str; tgt_table: str; tgt_column: str
    condition: dict | None; transform_fn: str | None
    card_min: int; card_max: int
    back_reference: bool; two_pass: bool

@dataclass(frozen=True)
class GenerationPlan:
    content_hash: str; seed: int; as_of: date | None
    system_order: tuple[str, ...]                 # flow-topological
    waves: tuple[tuple[str, ...], ...]            # each wave: fully-qualified table names
    tables: dict[str, TablePlan]                  # keyed 'SYSTEM.TABLE'
    links: dict[str, LinkPlan]
    rules: tuple[dict, ...]
    aggregates: tuple[dict, ...]
    valuesets: dict[str, dict]                    # {"fields":[...], "rows":[{values,weight}]}
    scenarios: tuple[dict, ...]
    volumes: dict[str, int]
```

### 7.2 Planner (`planner.py`) — ordering is a hard requirement

```python
def system_order(flows: list[tuple[str, str]], systems: list[str]) -> list[str]
def build_waves(plan_tables, links, system_rank) -> list[list[str]]
```

Algorithm:
1. Topologically sort **systems** by `system_flow`. Cycle → `ERR_FLOW_CYCLE`.
2. Build a table dependency graph: edge `A → B` when a non-`two_pass` link has
   source in A and target in B, or when B has an FK generator referencing A.
3. Topologically sort tables, **using the system rank as the primary sort key**
   so no child-system table is ever scheduled before a parent-system table it
   depends on. Tables with equal rank and no mutual dependency share a wave.
4. `two_pass` links are excluded from the graph and recorded for § 7.8.

**Acceptance test `test_planner_respects_flow`:** with flow
`CORE → CARDS → PAYMENTS`, no PAYMENTS table may appear in a wave before every
CORE table it transitively depends on.

### 7.3 Deterministic RNG (`rng.py`)

```python
def cell_rng(seed: int, table: str, row_index: int, column: str) -> random.Random:
    h = hashlib.blake2b(f"{seed}|{table}|{row_index}|{column}".encode(), digest_size=8)
    return random.Random(int.from_bytes(h.digest(), "big"))
```

Every draw in the engine must come from `cell_rng`. No module-level `random`.
**Acceptance test `test_determinism`:** two runs with the same plan hash + seed
produce byte-identical Parquet output.

### 7.4 Scenario allocation (`allocator.py`)

```python
def allocate_scenarios(total_rows: int, scenarios: list[dict], rng) -> list[int]
def pairwise_matrix(dims: dict[str, list[str]]) -> list[dict[str, str]]
```

* Weights are normalised then apportioned with **largest remainder** so the
  quotas sum exactly to `total_rows`.
* `pairwise_matrix` implements IPOG: seed with the two largest dimensions'
  cartesian product, then for each remaining dimension extend horizontally
  (choose the value covering most uncovered pairs) and vertically (add rows for
  pairs still uncovered). Assert every value pair appears at least once.
* Boundary injection: unless a scenario sets `boundaries=false`, mark
  `ceil(0.02 * quota)` rows per table as boundary rows; § 7.5 then draws min/max
  values for eligible columns.

**Acceptance test `test_pairwise_covers_all_pairs`** over 3 dims of sizes 4,4,3.

### 7.5 Value generation (`generators.py`)

Registry `GENERATORS: dict[str, Generator]`, each:

```python
class Generator(Protocol):
    def domain(self, spec: dict, col: ColumnPlan) -> Domain: ...
    def draw(self, spec: dict, col: ColumnPlan, rng, ctx: RowContext) -> Any: ...
```

Implement for v1: `id(pattern)` (`#`=digit, `A`=letter, literals kept),
`enum(values, weights)`, `int(lo..hi)`, `decimal(lo..hi, distribution)`,
`date(range | after=expr)`, `string(n)`, `regex(pattern)` (use `exrex`-style
generation or a hand-rolled generator for the limited syntax `[]{}|.` — keep it
simple), `sequence(start, step)`, `persona.name(locale)`, `persona.email`,
`fk(qname)`, `derived(template)`, `lookup(ref)`, `describe(text)` (v1: resolve to
a canned list from the copilot stub).

`RowContext` gives access to already-generated sibling values, the parent row,
and the row's scenario overrides.

**Column generation order within a row:** discriminator columns (those named in
any rule's `when` or any conditional link's condition) first, then columns whose
domains are narrowed by rules, then the rest. Compute this order once per table
at plan time.

### 7.6 Rules (`rules.py`)

```python
def narrow_domain(col: str, base: Domain, rules: list[dict], ctx: RowContext) -> Domain
```

Forward checking only: evaluate each rule's `when` against the partially-built
row; if true, intersect the target column's domain with the rule's `then` set.
Empty intersection → raise `RuleConflict` naming the rules (this should have been
caught at compile time; treat it as a bug surfaced at runtime).
Soft rules (`prefer ... probability p`) bias the draw instead of restricting it.

### 7.7 Aggregate constraints (`engine/aggregate/`)

**Copy `aggregate_engine/` from `aggregate-constraint-engine.zip` into
`app/engine/aggregate/` unchanged**, including its tests (move them under
`backend/tests/aggregate/`). It is already tested; do not reimplement.

Public functions used by the engine: `RowSpec`, `allocate`, `check_feasible`,
`Infeasible`, `repair_running_balance`, `balance_journal`, `rollup`, `schedule`.

Integration in `runner.py`, after child rows exist as templates but before their
amount column is finalised:

```python
for agg in plan.aggregates:                    # mode == 'allocate'
    for parent_row in parent_rows:
        target_minor = to_minor(parent_row[agg.target]) - to_minor(parent_row[agg.opening])
        specs = [row_spec_for(child, agg.row_classes) for child in children_of(parent_row)]
        amounts = allocate(target_minor, specs, cell_rng(seed, table, i, "AMOUNT"))
        if agg.guard_floor is not None:
            amounts = repair_running_balance(amounts, opening_minor, floor_minor)
        assign(children, amounts)
```

`Infeasible` during a run is a bug (compile stage 9 should have caught it) —
fail the run with the solver's message verbatim, which already names the fix.

### 7.8 Links, key vault, two-pass (`keyvault.py`, `links.py`, `twopass.py`)

* As each table completes, publish `{'SYSTEM.TABLE.COLUMN': polars.Series}` of
  generated values to the key vault.
* **Direct link:** sample from the source series honouring cardinality; track
  per-parent child counts so `one_to_many(1..4)` yields 1–4 children per parent.
* **Conditional link:** first generate the discriminator column; rows matching
  the condition draw from the linked series, others fall through to their own
  generator or another disjoint conditional link.
* **Function link:** apply the registered transform to the drawn source value.
  v1 transform registry is a Python dict of pure functions in
  `app/engine/transforms.py` (ship `identity`, `strip_prefix`, `mod97_check`).
* **Two-pass:** columns targeted by a `two_pass` back-reference are left null in
  pass 1 and recorded in a deferred registry. After all waves complete, pass 2
  resolves them from the key vault and writes a **patch artifact**
  (`kind='patch'`, columns = target PK + the deferred columns). Patches never
  create rows.

### 7.9 Schema import & drift (`importers/`)

```python
def import_sqlalchemy(url: str, schema: str | None) -> ImportedSchema
def import_openapi(spec_url_or_path: str) -> ImportedSchema
def diff(existing: list[ColumnDef], imported: ImportedSchema) -> list[DriftItem]
```

Drift classification: column present in source only → `added`; in model only →
`removed`; type/length/nullability differs → `changed`; a change that
invalidates a rule, link or enum domain → `breaking` (set `breaking=true` and
name the impacted objects in `detail`). Accepting a drift item applies it to the
model; `breaking` items require an explicit accept and re-run of compile.

### 7.10 Validator & report (`validator.py`)

After generation, re-evaluate every hard rule, link cardinality, aggregate
identity and fit constraint against the produced frames and emit `RunReport`
(§ 9.7). Hard rule pass rate below 100 % fails the run.

---

## 8. Ingestion adapters

```python
# app/adapters/base.py
class IngestionAdapter(ABC):
    name: str
    supports_patch: bool

    @abstractmethod
    def validate_target(self, profile: dict) -> list[str]: ...
    @abstractmethod
    def load(self, system: str, table: str, frame: "pl.DataFrame", profile: dict) -> int: ...
    def apply_patch(self, system: str, table: str, frame: "pl.DataFrame",
                    pk_cols: list[str], profile: dict) -> int:
        raise NotImplementedError
    @abstractmethod
    def verify(self, system: str, table: str, expected_rows: int, profile: dict) -> dict: ...
```

v1 adapters: `file` (writes CSV + Parquet under `runs/{run_id}/{system}/{table}.csv`,
`supports_patch=True` by emitting a `*.patch.csv`), `jdbc` (SQLAlchemy
`insert().executemany`, patches via keyed `UPDATE`), `rest` (POST per row or
batch, `PATCH` for patches, honouring a per-system rate limit).

**Ingestion order is the declared system flow order.** A child system's load must
not start until every parent system's load has been verified. Patch artifacts are
applied only after all inserts across all systems have been verified.
If a system's adapter has `supports_patch=False` but the plan contains a two-pass
link targeting it, compile stage 5 emits `WARN_NO_PATCH_SUPPORT`.

---

## 9. REST API contract

Base path `/api`. All responses JSON. Errors:
`{"detail": "...", "code": "ERR_..."}` with appropriate 4xx/5xx.

### 9.1 Bootstrap
`GET /api/bootstrap?model_version_id=...` → everything the Studio needs on load.
```jsonc
{
  "model": {"id":"...","name":"release_2026_R3","seed":84921,"env":"SIT2",
            "hash":"a41f9c","flow":["Core banking","Cards","Payments"]},
  "systems": [{"id":"...","name":"CORE_BANKING","displayName":"Core banking","lane":0}],
  "tables":  [{"id":"...","system":"core","name":"CUSTOMER","x":30,"y":60,
               "cols":[{"id":"...","name":"CUST_ID","dtype":"VARCHAR","length":12,
                        "nullable":false,"isPk":true,"tags":"pk · id","link":"cust-card",
                        "pick":null,"generator":{"kind":"id","pattern":"CIF#########"}}]}],
  "links":   [{"id":"cust-card","label":"CUSTOMER.CUST_ID → CARD_MASTER.HOLDER_REF",
               "type":"Direct","condition":null,"cardinality":"one_to_many(1..4)",
               "source":{"node":"CUSTOMER","col":"CUST_ID"},
               "target":{"node":"CARD_MASTER","col":"HOLDER_REF"}}],
  "valuesets":[{"id":"ENTITY_TYPES","fields":["code","description","category"],
                "rows":[{"values":["BR","Branch","INTERNAL"],"weight":50}]}],
  "scenarios":[{"id":"s1","name":"Happy path retail","weight":55,"color":"var(--purple-400)"}],
  "runs":    [ /* § 9.7 RunSummary[] */ ],
  "drift":   [{"id":"d1","kind":"added","what":"CUSTOMER.PREF_LANG  varchar(5)",
               "note":"copilot suggests: enum(...)","state":"accepted","breaking":false}],
  "files":   {"cards.mdl":"system CARDS {...}"}
}
```

### 9.2 Model objects
| Method | Path | Body / notes |
|---|---|---|
| `PUT` | `/api/tables/{tableId}/columns/{name}` | `{name,dtype,length,precision,scale,nullable,isPk,generator,pick}` → column |
| `POST` | `/api/tables/{tableId}/columns` | create |
| `DELETE` | `/api/tables/{tableId}/columns/{name}` | |
| `PUT` | `/api/tables/{tableId}/position` | `{x,y}` (canvas drag persistence) |
| `POST` | `/api/links` | full link object → link |
| `PUT` | `/api/links/{id}` | update |
| `DELETE` | `/api/links/{id}` | |
| `PUT` | `/api/valuesets/{id}` | `{fields, rows}` |
| `POST` | `/api/valuesets/{id}/import-csv` | multipart file → parsed valueset |
| `PUT` | `/api/scenarios` | array of scenarios (replace) |
| `PUT` | `/api/files/{name}` | `{content}` — MDL source, triggers re-parse |

### 9.3 Compile
`POST /api/models/{id}/compile` →
```jsonc
{"ok": false, "contentHash": null,
 "diagnostics":[{"severity":"error","code":"ERR_FIT",
   "message":"CARD_MASTER.LIMIT_AMT: decimal range min > max",
   "file":"cards.mdl","line":16,"col":34,"length":22}]}
```

### 9.4 Runs
`POST /api/runs` `{"modelVersionId":"...","volumes":{"CORE_BANKING.CUSTOMER":5000},
"targetEnv":"SIT2","seed":84921,"dryRun":false}` → `{"runId":"...","runNumber":2482}`
`GET /api/runs?modelVersionId=...` → `RunSummary[]`
`GET /api/runs/{id}` → full run incl. report
`GET /api/runs/{id}/artifacts/{artifactId}` → file download

### 9.5 Schema import
`POST /api/systems/{id}/scan` → `DriftItem[]`
`PATCH /api/drift/{id}` `{"state":"accepted"|"skipped"|"pending"}`
`POST /api/drift/apply` `{"modelVersionId":"..."}` → applies all accepted items

### 9.6 Copilot (stubbed in v1)
`POST /api/copilot/suggest` `{"kind":"rule"|"generator"|"valueset","context":"..."}`
→ `{"mdl":"rule kyc_gate on ...","explanation":"..."}`
v1 returns canned suggestions keyed by `kind`; the interface must not change when
a real model is wired in.

### 9.7 RunReport shape
```jsonc
{"id":"...","runNumber":2481,"when":"09 Jul 2026, 14:12","status":"verified",
 "rows":54650,"rulePass":"100%","coverage":"96%","elapsed":"6m 41s",
 "systems":[{"name":"Core banking","detail":"16,400 rows · JDBC · 1m 12s","ok":true}],
 "rules":[{"name":"kyc_gate","result":"12050/12050","ok":true,"soft":false}],
 "coverageMatrix":{"dims":["SEGMENT","ACC_TYPE"],
   "rows":["RETAIL","PREMIUM","NRI","CORP"],"cols":["SAV","CUR","OD","FD"],
   "counts":[[8210,3100,900,2400],[...]],"excluded":[[false,false,false,false],[...]]},
 "crossChecks":[{"name":"card holders exist in core banking","passed":500,"total":500}]}
```

---

## 10. Frontend specification

The React prototype in `dataforge-studio.zip` is the **visual source of truth**.
This section restates it precisely so it can be rebuilt without the archive.

### 10.1 Design tokens — exact values (`styles.css`)

```css
:root{
  --bg:#fafaf8; --surface:#ffffff; --surface-2:#f4f4f1;
  --border:#e4e3de; --border-strong:#cfcec8;
  --text:#1c1c1a; --text-2:#5f5e5a; --text-3:#93928c;
  --purple-50:#eeedfe; --purple-400:#7f77dd; --purple-600:#534ab7; --purple-800:#3c3489;
  --teal-50:#e1f5ee; --teal-200:#5dcaa5; --teal-400:#1d9e75; --teal-600:#0f6e56; --teal-800:#085041;
  --coral-50:#faece7; --coral-200:#f0997b; --coral-400:#d85a30; --coral-600:#993c1d; --coral-800:#712b13;
  --amber-50:#faeeda; --amber-600:#854f0b;
  --red-50:#fcebeb; --red-600:#a32d2d; --red-800:#791f1f;
  --green-50:#eaf3de; --green-800:#27500a;
  --mono:"SFMono-Regular",ui-monospace,Menlo,Consolas,monospace;
  --sans:"Inter",-apple-system,"Segoe UI",Roboto,sans-serif;
  --radius:8px;
}
```

System colour assignment: core banking = purple, cards = teal, payments = coral;
further systems cycle through the same families.

### 10.2 App chrome (all screens)

* **Shell**: max-width 1180px, centred, `--surface` card with 1px `--border`,
  radius 14px, `overflow:hidden`.
* **TopBar** (height ~52px, bottom border): 30px rounded logo tile
  (`--purple-50` bg, `--purple-800` glyph `{}`) · title "DataForge studio" 14px/600
  · subtitle `{modelName} · seed {seed} · {env}` 11.5px `--text-3` mono ·
  right group: validity pill, `Validate` button, primary `Generate {volume}`
  button (dark `--text` bg, white text). **The Generate button is disabled while
  compile diagnostics contain any error**, with tooltip "Fix the compile error in
  the MDL editor first".
* **Tabs**: `Linkage canvas · MDL editor · Valuesets · Scenarios · Runs · Schema
  import`. Active tab: 600 weight, 2px bottom border `--text`. Right-aligned
  flow note in mono 11.5px: `flow: Core banking → Cards → Payments`.
* **StatusBar** (top border, mono 11.5px `--text-3`): `{n} systems · {n} tables ·
  {n} links · {n} valuesets · {n} rules` | `models/{label} · #{hash}` | right:
  API base or `mock adapter`.
* **Pills**: `.ok` teal-50/teal-800, `.warn` amber-50/amber-600,
  `.err` red-50/red-800; 11px, radius 999px, padding 3px 10px.

### 10.3 Screen — Linkage canvas

Layout: canvas region 420px tall, then a two-column panel row (1.15fr / 1fr)
separated by a 1px border.

**Canvas.** Absolutely-positioned swimlane backdrop (one equal-width lane per
system, dashed `--border-strong` separators, lane badge pill top-left in the
system's 50/600 colours), with React Flow rendered transparently on top
(`Background` gap 22 colour `--border`, `Controls` without the interactive lock).
Lane order = declared system flow order, left to right.

**TableNode** (custom node, width 224px, radius 9px, 1px `--border-strong`,
subtle shadow):
* header bar: table name 12px/600 on the system's 50-tint, 600-tint text
* one row per column: `name` (left) and computed **type label** (right, mono
  11.5px `--text-3`) where the label is `VARCHAR(12)`, `NUMBER(18,2)`, `DATE`…
* React Flow `Handle` target on the left edge (7px, `--border-strong`, id
  `t:{col}`) and source on the right edge (7px, `--purple-400`, id `s:{col}`)
* clicking a column selects it → opens the **Column** inspector; selected column
  row gets `--purple-50` background
* final row `+ add column`, centred, `--text-3`

**Edges** are derived from the link list, styled by kind: Direct = solid
`--purple-400`; Conditional = dashed `6 4` `--coral-400`; Function/back-reference
= dotted `2 4` `--border-strong`. Selected edge stroke 2.4 vs 1.7. Labels are
mono 10.5px on a `--surface` rounded chip (radius 8, padding 7×3): cardinality
range for direct (`1..4`), `when CPTY_TYPE = "ACCOUNT"` for conditional,
`two-pass` for back-references. Arrowheads `ArrowClosed` 16px `#888780`.

**Interactions:** drag nodes (persist via `PUT /position`, debounce 500 ms);
drag from a source handle to a target handle creates a link (`POST /api/links`,
default kind Direct, cardinality `one_to_many(1..1)`) and selects it; click an
edge to open the Link inspector.

**Left panel — inspector** with a Link/Column segmented toggle:
* *Link mode*: link label in mono; segmented `Direct | Conditional | Function`;
  when Conditional → row `when [column ▾] [op ▾] [value input]`; when Function →
  `via fn [select]` + hint "sandboxed plugin"; always `cardinality [text input]`;
  helper text about drag-to-link.
* *Column mode*: `name` text input (upper-cases, strips non `[A-Z0-9_]`);
  `data type` select (VARCHAR, CHAR, NUMBER, INTEGER, DATE, TIMESTAMP, BOOLEAN);
  conditional `length` input for VARCHAR/CHAR, `precision`+`scale` for NUMBER;
  `nullable` checkbox; **`value source` select** (generator (default) | each
  valueset) and, when a valueset is chosen, a `field` select; a live binding note
  — when ≥2 columns of the same table bind the same valueset, render
  `one draw per row fills: ENTITY_CODE (code) + ENTITY_DESC (description)`;
  a live fit warning in `--red-600` when the longest bound value exceeds the
  declared length; footer `sqltype varchar(12) not_null — fit check runs at
  compile time` in mono `--text-3`.

**Right panel — scenario allocation:** one row per scenario with
`name` / `weight% · rowcount`, a 6px track (`--surface-2`) and fill in the
scenario colour; footer `pairwise coverage 96% · est. N accounts · N txns`.

### 10.4 Screen — MDL editor

Two columns: 172px file tree, then editor.
* **File tree** on `--bg`, header `models/{label}` mono 11px `--text-3`, one row
  per `.mdl` file; active file `--surface` bg, 600 weight, 2px left border
  `--text`; trailing `plugins/` row.
* **Monaco**, height 340px, language id `mdl` registered with a Monarch tokenizer
  (keywords → `--purple-600`, generators/types → `--teal-600`, strings →
  `--coral-600`, numbers → `--text`, comments → `--text-3`) and theme `mdl-light`
  (`editor.background:#ffffff`, `lineHighlightBackground:#f4f4f1`). Options:
  fontSize 13, mono family, `minimap:false`, `scrollBeyondLastLine:false`,
  padding top 10.
* **Diagnostics**: on change (debounced 400 ms) `PUT /api/files/{name}` then
  `POST /compile`; render returned diagnostics via
  `monaco.editor.setModelMarkers`. The error count drives the TopBar pill and the
  Generate button's disabled state.
* **Copilot card** below the editor: 1px `--purple-400` border, `--purple-50` bg,
  radius 10; header `✦ Copilot · from your note "…"` 11.5px/600 `--purple-800`;
  a white `pre` block with the proposed MDL; actions `Insert rule` (applies the
  edit to the open file and re-compiles), `Edit`, `Dismiss`.

### 10.5 Screen — Valuesets

Two columns: 172px list of valuesets (plus `+ new valueset`), then the editor
panel.
* Header row: valueset name (h3), a pill `{n} tuples · total weight {w}`, right
  group `Import CSV` (real file input → `POST /import-csv`) and
  `Sync from reference table`.
* **Tuple grid**: CSS grid `repeat(nFields, minmax(120px,1fr)) 84px 40px`; header
  row of field names in mono 11px `--text-3`; each row = one text input per field
  (mono) + weight input + `×` remove button. Footer `+ add tuple`.
* **Bindings** section: one `ListRow` per table binding this valueset, reading
  `one draw per row fills ENTITY_CODE (code) + ENTITY_DESC (description)`.
* **Fit check** block: red lines listing any bound column whose declared length
  is shorter than the longest value in its field; otherwise a teal
  `✓ fit check: all bound columns hold the longest values`.

### 10.6 Screen — Scenarios

Two panels. Left: one range slider per scenario (0–100, accent `--purple-600`)
with name and `{weight}%`; a `total {n}%` pill (`ok` at 100, else `warn`) and a
`Normalize to 100%` button that apportions by largest remainder. Right: live
allocation preview identical in style to § 10.3's right panel, plus downstream
estimates and a note that coverage scenarios expand to a pairwise covering array.

### 10.7 Screen — Runs

* **Run bar**: `Run [select ▾]` listing `#{n} · {when} · {status}`, a status pill,
  right group `Download report`, `Regenerate`.
* **Metric grid**: 4 cards (`--surface-2`, radius 9) — Rows generated, Hard rule
  pass (value in `--teal-800`), Pairwise coverage, Elapsed. Value 21px/600.
* **Left panel — Ingestion by system · flow order**: one ListRow per system in
  declared flow order with a tick and `16,400 rows · JDBC · 1m 12s`; the two-pass
  phase appears as a final row `Pass-2 patches → Core banking`. Footer line with
  cross-system spot-check results.
* **Right panel — Rule assertions** (tick teal for hard, `~` amber for soft, right
  aligned counts) then **Coverage heat map**: CSS grid `70px repeat(nCols,1fr)`,
  17px cells; colour ramp by row count `--teal-50 → --teal-200 → --teal-400`;
  rule-excluded combinations render as `--surface-2` with a dashed
  `--border-strong` border. Legend: `dashed = excluded by rules · darker = more rows`.
* While `status==='running'`, poll `GET /api/runs` every 1.5 s; show `…` in place
  of ticks and `—` for metrics.

### 10.8 Screen — Schema import

* Bar: system select, scan summary text, right group `{n} pending review` pill,
  `Re-scan`, primary `Apply {n} accepted`.
* **Drift list** (1px border, radius 10, rows separated by 1px `--border`): each
  row = a fixed-width 68px kind chip (`added` green-50/green-800, `changed`
  amber-50/amber-600, `removed` and `breaking` red-50/red-800), a body with the
  target in mono 12px and a note in 11.5px `--text-3` (`--red-600` when
  breaking), and right-aligned actions. Breaking rows get a `--red-50` row
  background while pending, and their accept button reads `Review + accept`.
  Accepted/skipped rows show a pill and an `Undo` button.
* Footer note: accepted changes are committed to a branch for review before merge.

### 10.9 State management

Single Zustand store `useStudio` holding `model, systems, tables, links,
valuesets, scenarios, runs, drift, files, diagnostics, selection`. All mutations
call the API and update the store optimistically, rolling back on error. The
store must expose `errorCount` derived from `diagnostics` — the TopBar and the
Generate button read only that.

---

## 11. Non-functional requirements

**Determinism.** `(content_hash, seed, volumes)` fully determines the output.
Enforced by § 7.3 and `test_determinism`.

**Performance (v1 target).** 1 million total rows generated and validated in
under 3 minutes on 4 cores. Generate per table into polars frames; parallelise
across tables within a wave using a process pool sized to `cpu_count()`.

**Safety.** Environment profiles carry an `allow_write: bool`; a run against a
profile without it is rejected. Volume cap per environment (`max_rows`). `dryRun`
produces plan + report with no adapter writes. All target credentials come from
env vars, never the database.

**Observability.** Structured JSON logs with `run_id` on every line; a
`GET /api/runs/{id}/log` endpoint streaming the run log.

**Data safety.** The platform generates synthetic data only. There is no code
path that reads rows from a target system except metadata (`importers/`) and
verification counts.

---

## 12. Test plan

### 12.1 Layers
* **Unit** — `mdl/`, `engine/`, `adapters/` in isolation.
* **Integration** — FastAPI + Postgres via `httpx.AsyncClient` and a
  testcontainer/`pytest-postgresql`.
* **Golden** — the sample model in `samples/retail_bank/` generated at a fixed
  seed; a checked-in fingerprint of the output must not change.
* **Frontend** — Vitest + Testing Library for the inspector logic
  (fit-check warning, binding note, weight normalisation).

### 12.2 Named acceptance tests (referenced by the milestones)

| Test | Asserts |
|---|---|
| `test_mdl_parse_sample` | all six sample `.mdl` files parse |
| `test_mdl_roundtrip` | `parse(emit(model))` equals `model` structurally |
| `test_fit_check_flags_short_varchar` | `id("CIF#########")` into `VARCHAR(8)` → `ERR_FIT` |
| `test_flow_conformance_rejects_reverse_link` | PAYMENTS→CORE link without `back_reference` → `ERR_FLOW_DIRECTION` |
| `test_conditional_links_must_be_disjoint` | two `when` clauses on the same target with overlapping literals → error |
| `test_planner_respects_flow` | § 7.2 |
| `test_pairwise_covers_all_pairs` | § 7.4 |
| `test_scenario_quotas_sum_exactly` | largest-remainder apportionment |
| `test_determinism` | identical output for identical inputs; different for a different seed |
| `test_valueset_pick_is_correlated` | for every generated row, `(ENTITY_CODE, ENTITY_DESC)` is a tuple that exists in the valueset |
| `test_cardinality_respected` | every customer has 1–4 cards |
| `test_conditional_link_only_binds_matching_rows` | `CPTY_VALUE ∈ ACC_NO` exactly where `CPTY_TYPE='ACCOUNT'` |
| `test_two_pass_patch_produced` | pass-1 column null; patch artifact contains PK + resolved value |
| `test_rule_narrows_domain` | `SEGMENT='CORP'` ⇒ `ACC_TYPE ∈ {CURRENT,OD}` for all rows |
| `test_aggregate_balances_exactly` | Σ child amounts == parent target, to the minor unit |
| `test_running_balance_never_below_floor` | § 7.7 guard |
| `test_ingestion_order_follows_flow` | recorded adapter call order matches system flow |
| `test_validator_fails_on_broken_rule` | injected bad row ⇒ run status `failed` |
| `test_api_bootstrap_shape` | response matches § 9.1 keys |
| `test_run_end_to_end` | POST run → poll → status `verified`, artifacts exist |

### 12.3 Definition of Done (whole project)
`pytest` green; `npm run build` clean; `docker compose up` yields a working
Studio at `localhost:5173` against the API at `localhost:8000`; the golden
sample generates and ingests to the `file` adapter with a verified run report.

### 12.4 Sample model (`samples/retail_bank/`)
Three systems — `CORE_BANKING` (CUSTOMER, ACCOUNT), `CARDS` (CARD_MASTER),
`PAYMENTS` (TXN) — with: `flow CORE_BANKING -> CARDS -> PAYMENTS`; a direct link
CUSTOMER.CUST_ID→CARD_MASTER.HOLDER_REF `one_to_many(1..4)`; a conditional link
ACCOUNT.ACC_NO→TXN.CPTY_VALUE `when CPTY_TYPE == "ACCOUNT"` `one_to_many(0..50)`;
a two-pass back-reference CARD_MASTER.CARD_STATUS→CUSTOMER.LATEST_CARD_STATUS;
valueset `ENTITY_TYPES` bound to CUSTOMER.ENTITY_CODE/ENTITY_DESC; rules
`kyc_gate`, `corporate_products`, `dormant_no_txn`; an aggregate constraint
`ACCOUNT.BALANCE = OPENING_BAL + sum(TXN.AMOUNT)` with SALARY/ATM/NEFT/POS row
classes; five scenarios summing to 100 % including one pairwise coverage
scenario. This model is the fixture for most acceptance tests.

---

## 13. Build plan

Each milestone is independently demoable. Do not proceed until its tests pass.

### M0 — Skeleton (0.5 day)
Repo layout per § 3; `docker-compose.yml` (postgres 16, api, web); FastAPI app
with `/health`; Alembic initialised; Vite React TS app with tokens from § 10.1,
app shell (TopBar, Tabs, StatusBar) and six empty tab bodies.
**DoD:** `docker compose up` serves both; `/health` returns 200.

### M1 — Model & persistence
All § 4 tables + Alembic migration; ORM models; pydantic schemas; CRUD routers
for tables/columns/links/valuesets/scenarios; `GET /api/bootstrap`; seed script
loading `samples/retail_bank` **as objects** (not yet MDL).
**DoD:** `test_api_bootstrap_shape`; bootstrap returns the sample model.

### M2 — MDL compiler
Grammar, AST, parser, resolver, checker (all ten stages of § 5.2 except 9),
emitter, `POST /compile`.
**DoD:** `test_mdl_parse_sample`, `test_mdl_roundtrip`,
`test_fit_check_flags_short_varchar`, `test_flow_conformance_rejects_reverse_link`,
`test_conditional_links_must_be_disjoint`.

### M3 — Generation engine core
Plan IR, planner, RNG, generators, valuesets, key vault, direct + conditional +
function links, cardinality, file adapter, run orchestration, artifacts.
**DoD:** `test_planner_respects_flow`, `test_determinism`,
`test_valueset_pick_is_correlated`, `test_cardinality_respected`,
`test_conditional_link_only_binds_matching_rows`, `test_run_end_to_end`.

### M4 — Rules, scenarios, aggregates, two-pass
Rule narrowing; scenario quotas + IPOG pairwise + boundary injection; drop in the
aggregate engine and wire § 7.7; two-pass deferred columns and patch artifacts;
validator and `RunReport`.
**DoD:** `test_rule_narrows_domain`, `test_scenario_quotas_sum_exactly`,
`test_pairwise_covers_all_pairs`, `test_aggregate_balances_exactly`,
`test_running_balance_never_below_floor`, `test_two_pass_patch_produced`,
`test_validator_fails_on_broken_rule`.

### M5 — Studio: canvas, inspectors, valuesets
React Flow canvas per § 10.3 with drag-to-link and position persistence; link and
column inspectors including physical types and valueset binding; valuesets screen
per § 10.5 with CSV import and fit check; Zustand store.
**DoD:** manual walkthrough matches § 10.3/§ 10.5; Vitest covers fit-check and
binding-note logic.

### M6 — Studio: editor, scenarios, runs
Monaco with the `mdl` language + theme + live markers from `/compile`; copilot
card wired to the stub; scenarios screen with sliders and normalisation; runs
screen with polling, metrics, flow-ordered ingestion list, rule assertions and
coverage heat map.
**DoD:** editing MDL surfaces a real squiggle; Generate is gated by error count;
a run completes and renders a full report.

### M7 — Ingestion & schema import
JDBC and REST adapters with `verify()` and `apply_patch()`; flow-ordered
ingestion orchestration with checkpointing; schema import + drift detection +
apply; schema import screen per § 10.8.
**DoD:** `test_ingestion_order_follows_flow`; a JDBC round-trip into a scratch
Postgres schema verifies; drift on a changed column is detected and applied.

---

## 14. Decisions, risks, migration

**D1 — Python over JVM for v1.** Reuses the tested aggregate solver and shortens
the path to a working system. Migration path: the MDL grammar (Lark → ANTLR4),
the Plan IR (already language-neutral JSON) and the adapter SPI are the only
contracts that must be preserved; the engine is a pure function of
(plan, seed, volumes) and can be ported table-generator by table-generator.

**D2 — Forward checking only, no CP-SAT in v1.** Interlocked rules are rare and
detectable; the compiler reports them rather than solving them. If a real model
needs it, add OR-Tools behind `rules.narrow_domain` without changing callers.

**D3 — Background tasks, not a workflow engine.** Keeps v1 single-process. The
single entry point `execute_run(run_id)` is the seam for Temporal/Celery later.

**D4 — Copilot stubbed.** The endpoint shape is fixed now so the UI never
changes when a model is wired in.

**R1 — Grammar churn.** The DSL will evolve. Mitigate by keeping the Plan IR
stable and versioned (`ir_version` field) so the engine is insulated.

**R2 — Cardinality explosion.** `one_to_many(0..50)` over 5,000 accounts is up to
250,000 transactions. Enforce the per-environment `max_rows` cap at plan time and
show the estimate in the UI before the run starts.

**R3 — Fit checks vs generator expressiveness.** Regex generation can be hard to
bound. If a generator cannot prove its maximum length, emit
`WARN_FIT_UNPROVEN` rather than a false error.
